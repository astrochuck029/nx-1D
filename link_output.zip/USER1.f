C=======================================================================
C  USER1.f
C
C  Simcenter NX 11 / TMG 11
C  Native T700/M21 CFRP thermochemical coupling
C
C  DLL SOURCE
C
C  IMPORTANT:
C  This source is compiled into tmgopen_user.dll.
C
C  NX Include File remains the separate minimal USER1/USERF interface.
C
C=======================================================================

      SUBROUTINE USER1(GG,T,C,Q,QD,R,TIME,DT,IT,KODE,NOCON,MAXNO,
     + ICONV,DUM1,DUM2,DTP,TF)

      IMPLICIT NONE

C----- USER1 arguments
      DOUBLE PRECISION T(*),TIME,DT
      REAL GG(*),C(*),Q(*),QD(*),R(*)
      REAL DUM1,DUM2,DTP,TF
      INTEGER IT,KODE,NOCON,MAXNO,ICONV(*)

C----- TMG common blocks
      REAL TDMAX,PRTFLG,PARAMS(8000)
      REAL GRAV,GV(3),TABS,RGAS
      REAL PSTD,TSTD,SIGMA

      INTEGER IRUN,IR(1),MAXN1,MAXN2

      COMMON/TDMAX/TDMAX
      COMMON/PRTFLG/PRTFLG
      COMMON/IRUN/IRUN,IR
      COMMON/MAXNOQ/MAXN1,MAXN2
      COMMON/PARAMS/PARAMS
      COMMON/GRAV/GRAV,GV,TABS,RGAS,PSTD,TSTD,SIGMA

      SAVE

C----- Array limits
      INTEGER MAXELEM,MAXGROUP,MAXNODE
      PARAMETER (MAXELEM=25000)
      PARAMETER (MAXGROUP=5000)
      PARAMETER (MAXNODE=10000)

C----- Element data
      REAL PROP(10,MAXELEM)
      REAL GEOM(3,4,MAXELEM)
      REAL NODELIST(3,MAXNODE)
      INTEGER NODES(8,MAXELEM)

      INTEGER GNUMELEM
      INTEGER GLIST(MAXGROUP)

      COMMON/CFRPDATA/PROP,GEOM,NODELIST,NODES,GLIST,GNUMELEM

C----- Group name
      INTEGER GID,GLENGTH
      CHARACTER*7 SNAME

C----- First call
      LOGICAL FIRSTTIME
      DATA FIRSTTIME/.TRUE./

C----- Local variables
      INTEGER I,N,IERR,ERRCNT
      LOGICAL CHECKUNITS

      DOUBLE PRECISION A1OLD,A2OLD
      DOUBLE PRECISION A1NEW,A2NEW
      DOUBLE PRECISION ALPHA,RHO,CP
      DOUBLE PRECISION R1AVG,R2AVG
      DOUBLE PRECISION QDEC,QSTORE
      DOUBLE PRECISION TCE,TK
      DOUBLE PRECISION STEPDT,LASTTIME
      DOUBLE PRECISION INITFLAG
      DOUBLE PRECISION C0VAL,VOL

      DOUBLE PRECISION CFRP_CP
      DOUBLE PRECISION CFRP_CPV

C----- Constants
      DOUBLE PRECISION TIME_EPS

      PARAMETER (TIME_EPS=1.0D-10)

C=======================================================================
C  FIRST INITIALIZATION
C=======================================================================

      IF (FIRSTTIME) THEN

         ERRCNT=0

         IF (CHECKUNITS()) THEN
            PRINT *,'*** FATAL: USER1 REQUIRES SI UNITS ***'
            ERRCNT=ERRCNT+1
         ENDIF

         IF (MAXNO.GT.MAXELEM) THEN
            PRINT *,'*** FATAL: MAXNO TOO LARGE ***'
            PRINT *,'MAXNO = ',MAXNO
            ERRCNT=ERRCNT+1
         ENDIF

C-------- Physical group Plate_3D
         CALL LONGNAME(SNAME,'Plate_3D',GID,GLENGTH,2)

         CALL NAMAR(SNAME,GLIST,GNUMELEM)

         IF (GNUMELEM.GT.MAXGROUP) THEN
            PRINT *,'*** FATAL: CFRP GROUP TOO LARGE ***'
            PRINT *,'GROUP SIZE = ',GNUMELEM
            ERRCNT=ERRCNT+1
         ENDIF

C-------- Read TMG element properties
         CALL READPROP2(PROP,GEOM,NODES,NODELIST,
     +                  'Y','Y','Y','Y')

         PRINT *,'=============================================='
         PRINT *,' CFRP USER1 THERMOCHEMICAL MODEL ACTIVE'
         PRINT *,' Plate_3D elements = ',GNUMELEM
         PRINT *,' MAXNO             = ',MAXNO
         PRINT *,' Exact Python kinetics/math = ACTIVE'
         PRINT *,' Native continuous alpha = ACTIVE'
         PRINT *,' ICONV temperature mapping = ACTIVE'
         PRINT *,'=============================================='

         FIRSTTIME=.FALSE.

         IF (ERRCNT.GT.0) STOP

      ENDIF

C=======================================================================
C  KODE = 1
C
C  Before TMG temperature calculation.
C=======================================================================

      IF (KODE.EQ.1) THEN

         DO I=1,GNUMELEM

            N=GLIST(I)

C=======================================================================
C  CHECK WHETHER ELEMENT STATE EXISTS
C=======================================================================

            INITFLAG=0.0D0

            CALL USER_QUANTITY('GET','CFRP_INIT',
     +                         N,INITFLAG,IERR)

C=======================================================================
C  FIRST VISIT
C=======================================================================

            IF (IERR.NE.0) THEN

               A1OLD=0.0D0
               A2OLD=0.0D0

               LASTTIME=TIME

               INITFLAG=1.0D0

               CALL USER_QUANTITY('SET','CFRP_A1',
     +                            N,A1OLD,IERR)

               CALL USER_QUANTITY('SET','CFRP_A2',
     +                            N,A2OLD,IERR)

               CALL USER_QUANTITY('SET','CFRP_LAST',
     +                            N,LASTTIME,IERR)

               CALL USER_QUANTITY('SET','CFRP_QDEC',
     +                            N,0.0D0,IERR)

               CALL USER_QUANTITY('SET','CFRP_C0',
     +                            N,DBLE(C(N)),IERR)

               CALL USER_QUANTITY('SET','CFRP_INIT',
     +                            N,INITFLAG,IERR)

C=======================================================================
C  FIRST CHEMICAL INTERVAL
C
C  T is indexed by EXTERNAL element number.
C  N is INTERNAL element number.
C=======================================================================

               STEPDT=DT

               IF (STEPDT.GT.0.0D0) THEN

                  TCE=T(ICONV(N))

                  TK=TCE+273.15D0

                  IF (TK.LT.1.0D0) TK=1.0D0

                  CALL CFRP_RK4(TK,STEPDT,
     +                          A1OLD,A2OLD,
     +                          A1NEW,A2NEW)

                  R1AVG=(A1NEW-A1OLD)/STEPDT

                  R2AVG=(A2NEW-A2OLD)/STEPDT

                  IF (R1AVG.LT.0.0D0) R1AVG=0.0D0

                  IF (R2AVG.LT.0.0D0) R2AVG=0.0D0

                  CALL CFRP_QDECOMP(TCE,R1AVG,R2AVG,QDEC)

                  CALL USER_QUANTITY('SET','CFRP_A1',
     +                               N,A1NEW,IERR)

                  CALL USER_QUANTITY('SET','CFRP_A2',
     +                               N,A2NEW,IERR)

                  CALL USER_QUANTITY('SET','CFRP_LAST',
     +                               N,TIME,IERR)

                  CALL USER_QUANTITY('SET','CFRP_QDEC',
     +                               N,QDEC,IERR)

               ENDIF

C=======================================================================
C  ELEMENT ALREADY INITIALIZED
C=======================================================================

            ELSE

               CALL USER_QUANTITY('GET','CFRP_A1',
     +                            N,A1OLD,IERR)

               CALL USER_QUANTITY('GET','CFRP_A2',
     +                            N,A2OLD,IERR)

               CALL USER_QUANTITY('GET','CFRP_LAST',
     +                            N,LASTTIME,IERR)

               CALL USER_QUANTITY('GET','CFRP_QDEC',
     +                            N,QSTORE,IERR)

C=======================================================================
C  ADVANCE CHEMISTRY ONLY ONCE FOR A NEW TIME
C=======================================================================

               IF (TIME.GT.LASTTIME+TIME_EPS) THEN

                  STEPDT=TIME-LASTTIME

                  IF (STEPDT.LE.0.0D0) STEPDT=DT

                  TCE=T(ICONV(N))

                  TK=TCE+273.15D0

                  IF (TK.LT.1.0D0) TK=1.0D0

                  CALL CFRP_RK4(TK,STEPDT,
     +                          A1OLD,A2OLD,
     +                          A1NEW,A2NEW)

                  R1AVG=(A1NEW-A1OLD)/STEPDT

                  R2AVG=(A2NEW-A2OLD)/STEPDT

                  IF (R1AVG.LT.0.0D0) R1AVG=0.0D0

                  IF (R2AVG.LT.0.0D0) R2AVG=0.0D0

                  CALL CFRP_QDECOMP(TCE,R1AVG,R2AVG,QDEC)

                  CALL USER_QUANTITY('SET','CFRP_A1',
     +                               N,A1NEW,IERR)

                  CALL USER_QUANTITY('SET','CFRP_A2',
     +                               N,A2NEW,IERR)

                  CALL USER_QUANTITY('SET','CFRP_LAST',
     +                               N,TIME,IERR)

                  CALL USER_QUANTITY('SET','CFRP_QDEC',
     +                               N,QDEC,IERR)

                  QSTORE=QDEC

               ENDIF

               QDEC=QSTORE

            ENDIF

C=======================================================================
C  GET CURRENT CHEMISTRY
C=======================================================================

            CALL USER_QUANTITY('GET','CFRP_A1',
     +                         N,A1NEW,IERR)

            CALL USER_QUANTITY('GET','CFRP_A2',
     +                         N,A2NEW,IERR)

C=======================================================================
C  ALPHA
C=======================================================================

            ALPHA=0.5540D0*A1NEW
            ALPHA=ALPHA+0.9479D0*A2NEW

            IF (ALPHA.LT.0.0D0) ALPHA=0.0D0
            IF (ALPHA.GT.1.0D0) ALPHA=1.0D0

C=======================================================================
C  DENSITY
C=======================================================================

            RHO=1575.0D0-0.5540D0*410.0D0*A1NEW
            RHO=RHO-0.9479D0*410.0D0*A2NEW

            IF (RHO.LT.1165.0D0) RHO=1165.0D0
            IF (RHO.GT.1575.0D0) RHO=1575.0D0

C=======================================================================
C  CP
C=======================================================================

            TCE=T(ICONV(N))

            CP=CFRP_CP(TCE,ALPHA)

C=======================================================================
C  ELEMENT VOLUME
C=======================================================================

            VOL=DBLE(PROP(1,N))

C=======================================================================
C  DECOMPOSITION HEAT
C
C  QDEC = W/m^3
C  Q    = W
C=======================================================================

            Q(N)=REAL(QDEC*VOL)

C=======================================================================
C  CAPACITANCE
C
C  C0 = original TMG capacitance.
C
C  Current model ambient/reference = 30 C in the original coupling
C  formulation.
C=======================================================================

            CALL USER_QUANTITY('GET','CFRP_C0',
     +                         N,C0VAL,IERR)

            IF (C0VAL.GT.0.0D0) THEN

               C(N)=REAL(C0VAL*RHO*CP)

               C(N)=C(N)/(1575.0D0*CFRP_CPV(30.0D0))

            ENDIF

         END DO

C=======================================================================
C  UPDATE CONDUCTANCE NETWORK
C=======================================================================

         CALL CFRP_UPDATE_CONDUCTANCES(GG,T,R,Q,
     +                                 NOCON,MAXNO,ICONV)

      ENDIF

      RETURN
      END


C=======================================================================
C  RK4 INTEGRATOR
C=======================================================================

      SUBROUTINE CFRP_RK4(TK,DTIN,A1,A2,A1OUT,A2OUT)

      IMPLICIT NONE

      DOUBLE PRECISION TK,DTIN
      DOUBLE PRECISION A1,A2
      DOUBLE PRECISION A1OUT,A2OUT

      DOUBLE PRECISION K1A,K1B
      DOUBLE PRECISION K2A,K2B
      DOUBLE PRECISION K3A,K3B
      DOUBLE PRECISION K4A,K4B

      DOUBLE PRECISION XSUM

C----- k1
      CALL CFRP_RHS(TK,A1,A2,K1A,K1B)

C----- k2
      CALL CFRP_RHS(TK,
     +              A1+0.5D0*DTIN*K1A,
     +              A2+0.5D0*DTIN*K1B,
     +              K2A,K2B)

C----- k3
      CALL CFRP_RHS(TK,
     +              A1+0.5D0*DTIN*K2A,
     +              A2+0.5D0*DTIN*K2B,
     +              K3A,K3B)

C----- k4
      CALL CFRP_RHS(TK,
     +              A1+DTIN*K3A,
     +              A2+DTIN*K3B,
     +              K4A,K4B)

C----- RK4 update
      A1OUT=A1+(DTIN/6.0D0)*K1A

      A1OUT=A1OUT+(DTIN/3.0D0)*K2A

      A1OUT=A1OUT+(DTIN/3.0D0)*K3A

      A1OUT=A1OUT+(DTIN/6.0D0)*K4A


      A2OUT=A2+(DTIN/6.0D0)*K1B

      A2OUT=A2OUT+(DTIN/3.0D0)*K2B

      A2OUT=A2OUT+(DTIN/3.0D0)*K3B

      A2OUT=A2OUT+(DTIN/6.0D0)*K4B

C----- Individual bounds
      IF (A1OUT.LT.0.0D0) A1OUT=0.0D0
      IF (A1OUT.GT.1.0D0) A1OUT=1.0D0

      IF (A2OUT.LT.0.0D0) A2OUT=0.0D0
      IF (A2OUT.GT.1.0D0) A2OUT=1.0D0

C----- Original constraint
      XSUM=A1OUT+A2OUT

      IF (XSUM.GT.1.0D0) THEN
         A1OUT=A1OUT/XSUM
         A2OUT=A2OUT/XSUM
      ENDIF

      RETURN
      END


C=======================================================================
C  KINETIC RHS
C=======================================================================

      SUBROUTINE CFRP_RHS(TK,A1,A2,RATE1,RATE2)

      IMPLICIT NONE

      DOUBLE PRECISION TK,A1,A2
      DOUBLE PRECISION RATE1,RATE2

      DOUBLE PRECISION RGAS_D
      DOUBLE PRECISION REMAINING
      DOUBLE PRECISION EX1,EX2

      RGAS_D=8.31446261815324D0

      REMAINING=1.0D0-A1-A2

      IF (REMAINING.LT.0.0D0) REMAINING=0.0D0

      IF (REMAINING.GT.1.0D0) REMAINING=1.0D0

      IF (REMAINING.LE.0.0D0) THEN

         RATE1=0.0D0
         RATE2=0.0D0

         RETURN

      ENDIF

C----- Reaction 1 Arrhenius exponent
      EX1=-58710.7D0
      EX1=EX1/(RGAS_D*TK)

C----- Reaction 2 Arrhenius exponent
      EX2=-146674.0D0
      EX2=EX2/(RGAS_D*TK)

C----- Reaction 1
      RATE1=10.0D0**0.8585D0

      RATE1=RATE1*REMAINING**1.1125D0

      RATE1=RATE1*EXP(EX1)

C----- Reaction 2
      RATE2=10.0D0**8.7268D0

      RATE2=RATE2*REMAINING**2.0825D0

      RATE2=RATE2*EXP(EX2)

      RATE2=RATE2*(1.0D0+10.0D0**0.8744D0*A2)

      RETURN
      END


C=======================================================================
C  VIRGIN CP
C=======================================================================

      DOUBLE PRECISION FUNCTION CFRP_CPV(TC)

      IMPLICIT NONE

      DOUBLE PRECISION TC
      DOUBLE PRECISION TCC

      TCC=TC

      IF (TCC.GT.200.0D0) TCC=200.0D0

      CFRP_CPV=2.8773D0*TCC

      CFRP_CPV=CFRP_CPV+687.31D0

      RETURN
      END


C=======================================================================
C  CHAR CP
C=======================================================================

      DOUBLE PRECISION FUNCTION CFRP_CPE(TC)

      IMPLICIT NONE

      DOUBLE PRECISION TC
      DOUBLE PRECISION TERM1
      DOUBLE PRECISION TERM2
      DOUBLE PRECISION TERM3
      DOUBLE PRECISION TERM4

      TERM1=5.1327D-7*TC**3

      TERM2=-2.0761D-3*TC**2

      TERM3=2.599D0*TC

      TERM4=662.53D0

      CFRP_CPE=TERM1+TERM2+TERM3+TERM4

      RETURN
      END


C=======================================================================
C  MIXTURE CP
C=======================================================================

      DOUBLE PRECISION FUNCTION CFRP_CP(TC,ALPHA)

      IMPLICIT NONE

      DOUBLE PRECISION TC,ALPHA
      DOUBLE PRECISION CV,CE

      DOUBLE PRECISION CFRP_CPV
      DOUBLE PRECISION CFRP_CPE

      CV=CFRP_CPV(TC)

      CE=CFRP_CPE(TC)

      CFRP_CP=(1.0D0-ALPHA)*CV

      CFRP_CP=CFRP_CP+ALPHA*CE

      RETURN
      END


C=======================================================================
C  VIRGIN XY CONDUCTIVITY
C=======================================================================

      DOUBLE PRECISION FUNCTION CFRP_KVXY(TC)

      IMPLICIT NONE

      DOUBLE PRECISION TC
      DOUBLE PRECISION TCC

      TCC=TC

      IF (TCC.GT.150.0D0) TCC=150.0D0

      CFRP_KVXY=7.4675D-3*TCC

      CFRP_KVXY=CFRP_KVXY+2.7811D0

      RETURN
      END


C=======================================================================
C  VIRGIN Z CONDUCTIVITY
C=======================================================================

      DOUBLE PRECISION FUNCTION CFRP_KVZ(TC)

      IMPLICIT NONE

      DOUBLE PRECISION TC
      DOUBLE PRECISION TCC

      TCC=TC

      IF (TCC.GT.150.0D0) TCC=150.0D0

      CFRP_KVZ=1.1113D-3*TCC

      CFRP_KVZ=CFRP_KVZ+0.61391D0

      RETURN
      END


C=======================================================================
C  CHAR XY CONDUCTIVITY
C=======================================================================

      DOUBLE PRECISION FUNCTION CFRP_KEXY(TC)

      IMPLICIT NONE

      DOUBLE PRECISION TC
      DOUBLE PRECISION TERM1
      DOUBLE PRECISION TERM2
      DOUBLE PRECISION TERM3

      TERM1=-3.5481D-6*TC**2

      TERM2=6.4898D-3*TC

      TERM3=2.3005D0

      CFRP_KEXY=TERM1+TERM2+TERM3

      RETURN
      END


C=======================================================================
C  CHAR Z CONDUCTIVITY
C=======================================================================

      DOUBLE PRECISION FUNCTION CFRP_KEZ(TC)

      IMPLICIT NONE

      DOUBLE PRECISION TC
      DOUBLE PRECISION TERM1
      DOUBLE PRECISION TERM2
      DOUBLE PRECISION TERM3
      DOUBLE PRECISION TERM4

      TERM1=7.4228D-10*TC**3

      TERM2=-4.1903D-7*TC**2

      TERM3=2.3397D-4*TC

      TERM4=7.7211D-2

      CFRP_KEZ=TERM1+TERM2+TERM3+TERM4

      RETURN
      END


C=======================================================================
C  DECOMPOSITION HEAT
C=======================================================================

      SUBROUTINE CFRP_QDECOMP(TC,R1,R2,QDEC)

      IMPLICIT NONE

      DOUBLE PRECISION TC,R1,R2
      DOUBLE PRECISION QDEC
      DOUBLE PRECISION QCHEM
      DOUBLE PRECISION RHOGDOT
      DOUBLE PRECISION HNOW
      DOUBLE PRECISION H0
      DOUBLE PRECISION DELTAH

C----- Chemical heat
      QCHEM=0.5540D0*259540.0D0

      QCHEM=QCHEM*410.0D0*R1

      QCHEM=QCHEM
     +      +0.9479D0*(-152220.0D0)*410.0D0*R2

C----- Gas mass production rate
      RHOGDOT=0.5540D0*410.0D0*R1

      RHOGDOT=RHOGDOT+0.9479D0*410.0D0*R2

C----- H(T)
      HNOW=3.5977D-7*TC**4

      HNOW=HNOW/4.0D0

      HNOW=HNOW-(9.2485D-4*TC**3)/3.0D0

      HNOW=HNOW+(1.0610D0*TC**2)/2.0D0

      HNOW=HNOW+1256.6D0*TC

C----- H(30 C)
      H0=3.5977D-7*30.0D0**4

      H0=H0/4.0D0

      H0=H0-(9.2485D-4*30.0D0**3)/3.0D0

      H0=H0+(1.0610D0*30.0D0**2)/2.0D0

      H0=H0+1256.6D0*30.0D0

C----- Enthalpy difference
      DELTAH=HNOW-H0

C----- Final volumetric decomposition heat
      QDEC=QCHEM-RHOGDOT*DELTAH

      RETURN
      END


C=======================================================================
C  CONDUCTANCE UPDATE
C=======================================================================

      SUBROUTINE CFRP_UPDATE_CONDUCTANCES(GG,T,R,Q,
     +                                    NOCON,MAXNO,ICONV)

      IMPLICIT NONE

      REAL GG(*),R(*),Q(*)

      DOUBLE PRECISION T(*)

      INTEGER NOCON,MAXNO,ICONV(*)

      INTEGER KCONV
      INTEGER NOCOND

C----- Limits
      INTEGER MAXELEM,MAXGROUP,MAXNODE,MAXCOND
      PARAMETER (MAXELEM=25000)
      PARAMETER (MAXGROUP=5000)
      PARAMETER (MAXNODE=10000)
      PARAMETER (MAXCOND=64)

C----- Model data
      REAL PROP(10,MAXELEM)
      REAL GEOM(3,4,MAXELEM)
      REAL NODELIST(3,MAXNODE)
      INTEGER NODES(8,MAXELEM)

      INTEGER GNUMELEM
      INTEGER GLIST(MAXGROUP)

      COMMON/CFRPDATA/PROP,GEOM,NODELIST,NODES,GLIST,GNUMELEM

C----- CONDNOS output
      INTEGER ICOND(4,MAXCOND)
      INTEGER BELLIST(MAXCOND)

      INTEGER NC
      INTEGER NUMBEL

C----- Local
      INTEGER I,J,K,N
      INTEGER CONDNO
      INTEGER E1,E2,I2
      INTEGER CFRPFLAG1,CFRPFLAG2
      INTEGER IERR

      DOUBLE PRECISION A1,A2
      DOUBLE PRECISION ALPHA1,ALPHA2

      DOUBLE PRECISION TC1,TC2

      DOUBLE PRECISION KX1,KY1,KZ1
      DOUBLE PRECISION KX2,KY2,KZ2

      DOUBLE PRECISION KEFF
      DOUBLE PRECISION KEFF0

      DOUBLE PRECISION DX,DY,DZ
      DOUBLE PRECISION DLEN
      DOUBLE PRECISION LX,LY,LZ

      DOUBLE PRECISION SCALE

      DOUBLE PRECISION EPSNEW
      DOUBLE PRECISION EPSBASE

      DOUBLE PRECISION CFRP_KVXY
      DOUBLE PRECISION CFRP_KVZ
      DOUBLE PRECISION CFRP_KEXY
      DOUBLE PRECISION CFRP_KEZ

C=======================================================================
C  IMPORTANT:
C
C  Save original GG and R.
C
C  This prevents:
C
C       GG = GG * SCALE
C       GG = GG * SCALE
C       GG = GG * SCALE
C
C  from accumulating at every USER1 call.
C=======================================================================

      REAL GGBASE(100000)
      REAL RBASE(100000)

      SAVE GGBASE
      SAVE RBASE

      DATA GGBASE/100000*0.0/
      DATA RBASE/100000*0.0/

C=======================================================================
C  CONDUCTIVE CONNECTIONS
C=======================================================================

      DO I=1,GNUMELEM

         N=GLIST(I)

         CALL CONDNOS(N,ICOND,NC,BELLIST,NUMBEL)

         IF (NC.GT.MAXCOND) NC=MAXCOND

         DO J=1,NC

            CONDNO=ICOND(1,J)

C----------- CONDNOS gives external element labels.
            E1=KCONV(ICOND(2,J))

            E2=KCONV(ICOND(3,J))

            IF (E1.LE.0) GOTO 100

            IF (E2.LE.0) GOTO 100

C----------- Process connection once.
            IF (E1.GT.E2) GOTO 100

            IF (N.NE.E1) GOTO 100

C----------- Determine CFRP membership.
            CFRPFLAG1=0
            CFRPFLAG2=0

            DO K=1,GNUMELEM

               IF (GLIST(K).EQ.E1) CFRPFLAG1=1

               IF (GLIST(K).EQ.E2) CFRPFLAG2=1

            END DO

            IF (CFRPFLAG1.EQ.0 .AND.
     +          CFRPFLAG2.EQ.0) GOTO 100

C=======================================================================
C  ENDPOINT 1
C=======================================================================

            CALL USER_QUANTITY('GET','CFRP_A1',
     +                         E1,A1,IERR)

            IF (IERR.NE.0) A1=0.0D0

            CALL USER_QUANTITY('GET','CFRP_A2',
     +                         E1,A2,IERR)

            IF (IERR.NE.0) A2=0.0D0

            ALPHA1=0.5540D0*A1

            ALPHA1=ALPHA1+0.9479D0*A2

            IF (ALPHA1.LT.0.0D0) ALPHA1=0.0D0

            IF (ALPHA1.GT.1.0D0) ALPHA1=1.0D0

C----------- Correct external temperature lookup.
            TC1=T(ICONV(E1))

            KX1=(1.0D0-ALPHA1)*CFRP_KVXY(TC1)

            KX1=KX1+ALPHA1*CFRP_KEXY(TC1)

            KY1=KX1

            KZ1=(1.0D0-ALPHA1)*CFRP_KVZ(TC1)

            KZ1=KZ1+ALPHA1*CFRP_KEZ(TC1)

C=======================================================================
C  ENDPOINT 2
C=======================================================================

            IF (CFRPFLAG2.EQ.1) THEN

               CALL USER_QUANTITY('GET','CFRP_A1',
     +                            E2,A1,IERR)

               IF (IERR.NE.0) A1=0.0D0

               CALL USER_QUANTITY('GET','CFRP_A2',
     +                            E2,A2,IERR)

               IF (IERR.NE.0) A2=0.0D0

               ALPHA2=0.5540D0*A1

               ALPHA2=ALPHA2+0.9479D0*A2

               IF (ALPHA2.LT.0.0D0) ALPHA2=0.0D0

               IF (ALPHA2.GT.1.0D0) ALPHA2=1.0D0

               TC2=T(ICONV(E2))

               KX2=(1.0D0-ALPHA2)*CFRP_KVXY(TC2)

               KX2=KX2+ALPHA2*CFRP_KEXY(TC2)

               KY2=KX2

               KZ2=(1.0D0-ALPHA2)*CFRP_KVZ(TC2)

               KZ2=KZ2+ALPHA2*CFRP_KEZ(TC2)

            ELSE

               KX2=KX1
               KY2=KY1
               KZ2=KZ1

            ENDIF

C=======================================================================
C  CONNECTION DIRECTION
C=======================================================================

            DX=DBLE(GEOM(1,1,E2)-GEOM(1,1,E1))

            DY=DBLE(GEOM(2,1,E2)-GEOM(2,1,E1))

            DZ=DBLE(GEOM(3,1,E2)-GEOM(3,1,E1))

            DLEN=SQRT(DX*DX+DY*DY+DZ*DZ)

            IF (DLEN.GT.1.0D-20) THEN

               LX=DX/DLEN
               LY=DY/DLEN
               LZ=DZ/DLEN

C-------------- CFRP/CFRP interface average.
               IF (CFRPFLAG2.EQ.1) THEN

                  KX1=0.5D0*(KX1+KX2)

                  KY1=0.5D0*(KY1+KY2)

                  KZ1=0.5D0*(KZ1+KZ2)

               ENDIF

C-------------- Effective directional conductivity.
               KEFF=KX1*LX*LX

               KEFF=KEFF+KY1*LY*LY

               KEFF=KEFF+KZ1*LZ*LZ

C-------------- Virgin 30 C reference.
               KEFF0=CFRP_KVXY(30.0D0)*LX*LX

               KEFF0=KEFF0+CFRP_KVXY(30.0D0)*LY*LY

               KEFF0=KEFF0+CFRP_KVZ(30.0D0)*LZ*LZ

               IF (KEFF.GT.1.0D-20) THEN

                  SCALE=KEFF0/KEFF

C---------------- Original GG stored only once.
                  IF (GGBASE(CONDNO).EQ.0.0) THEN
                     GGBASE(CONDNO)=GG(CONDNO)
                  ENDIF

C---------------- Reconstruct from original GG.
                  GG(CONDNO)=REAL(DBLE(GGBASE(CONDNO))*SCALE)

               ENDIF

            ENDIF

  100       CONTINUE

         END DO

C=======================================================================
C  DIRECT RADIATIVE CONNECTIONS
C=======================================================================

         DO J=1,NUMBEL

            I2=BELLIST(J)

            IF (I2.LE.0) GOTO 200

C----------- Try documented conductance lookup.
            CONDNO=NOCOND(ICONV(N),ICONV(I2),1)

            IF (CONDNO.LE.0) THEN

               CONDNO=NOCOND(ICONV(N),ICONV(I2),6)

            ENDIF

            IF (CONDNO.GT.0) THEN

               CALL USER_QUANTITY('GET','CFRP_A1',
     +                            N,A1,IERR)

               IF (IERR.NE.0) A1=0.0D0

               CALL USER_QUANTITY('GET','CFRP_A2',
     +                            N,A2,IERR)

               IF (IERR.NE.0) A2=0.0D0

               ALPHA1=0.5540D0*A1

               ALPHA1=ALPHA1+0.9479D0*A2

               IF (ALPHA1.LT.0.0D0) ALPHA1=0.0D0

               IF (ALPHA1.GT.1.0D0) ALPHA1=1.0D0

C-------------- Current emissivity.
               EPSNEW=(1.0D0-ALPHA1)*0.85D0

               EPSNEW=EPSNEW+ALPHA1*0.95D0

               EPSBASE=0.85D0

               IF (GGBASE(CONDNO).EQ.0.0) THEN
                  GGBASE(CONDNO)=GG(CONDNO)
               ENDIF

               IF (RBASE(CONDNO).EQ.0.0) THEN
                  RBASE(CONDNO)=R(CONDNO)
               ENDIF

               IF (EPSNEW.GT.1.0D-12) THEN

C---------------- Radiation resistance.
                  SCALE=EPSBASE/EPSNEW

                  GG(CONDNO)=REAL(DBLE(GGBASE(CONDNO))*SCALE)

C---------------- Radiation conductance parameter.
                  SCALE=EPSNEW/EPSBASE

                  R(CONDNO)=REAL(DBLE(RBASE(CONDNO))*SCALE)

               ENDIF

            ENDIF

  200       CONTINUE

         END DO

      END DO

      RETURN
      END


C=======================================================================
C  SI UNIT CHECK
C=======================================================================

      LOGICAL FUNCTION CHECKUNITS()

      IMPLICIT NONE

      REAL U1,U2,U3,U4,U5,U6
      REAL TOL,X

      TOL=0.01

      CALL TUNITS(U1,U2,U3,U4,U5,U6)

      CHECKUNITS=.FALSE.

C----- Length
      X=ABS(U2-1.0)

      IF (X.GT.TOL) CHECKUNITS=.TRUE.

C----- Force
      X=ABS(U3-1.0)

      IF (X.GT.TOL) CHECKUNITS=.TRUE.

C----- Temperature scale
      X=ABS(U4-1.0)

      IF (X.GT.TOL) CHECKUNITS=.TRUE.

C----- Temperature offset
      X=ABS((U5+273.15)/273.15)

      IF (X.GT.TOL) CHECKUNITS=.TRUE.

C----- Time
      X=ABS(U6-1.0)

      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      RETURN
      END