param(
    [string]$BaseXML = "",
    [string]$TmgRoot = "C:\Program Files\Siemens\NX 11.0\NXCAE_EXTRAS\tmg",
    [double]$dt = 0.5,
    [double]$t_end = 200.0,
    [string]$Python = "python",
    [string]$DomainSet = "",
    [switch]$ResetState
)

$ErrorActionPreference = "Stop"

# ============================================================
# TMG / Python thermochemical coupling
# ============================================================
# Put this PS1 and coupling_update.py in the same folder.
#
# Workflow:
#   1. TMG runs the current interval.
#   2. Fresh binary TEMPF is copied and converted to ASCII.
#   3. Python reads only the physical 3-D element IDs from XML.
#      Extra TEMPF records are ignored.
#   4. Python advances a1/a2 with RK4 and calculates alpha and Q_dec.
#   5. Python writes 20 alpha-state materials and element state sets.
#   6. TMG runs the next interval using the previous binary TEMPF.
#
# Existing boundary collectors are not used as material-state collectors.
# ============================================================


# ============================================================
# USER SETTINGS
# ============================================================

$MainDir = $PSScriptRoot

# NX 11 / TMG installation.
# Change only if NX is installed elsewhere.
$TmgCandidates = @(
    (Join-Path $TmgRoot "com\tmg.exe"),
    (Join-Path $TmgRoot "com\tmg")
)

$TMG = $TmgCandidates |
    Where-Object { Test-Path -LiteralPath $_ } |
    Select-Object -First 1

if (-not $TMG) {
    throw "TMG executable not found. Checked: $($TmgCandidates -join ', ')"
}

$env:SDRC_TMG = $TmgRoot

# Base XML exported from NX.
if ([string]::IsNullOrWhiteSpace($BaseXML)) {
    $BaseXML = Join-Path $MainDir "solution_01.xml"
} elseif (-not [System.IO.Path]::IsPathRooted($BaseXML)) {
    $BaseXML = Join-Path $MainDir $BaseXML
}

# Coupling files.
$AsciiDir      = Join-Path $MainDir "ascii"
$TempFileDir   = Join-Path $MainDir "TEMP_FILE"
$MainTEMPF     = Join-Path $MainDir "TEMPF"
$BinaryTEMPF   = Join-Path $TempFileDir "TEMPF"
$AsciiTEMPF    = Join-Path $AsciiDir "TEMPF"
$StateFile     = Join-Path $AsciiDir "decomposition_state.npz"

$PythonScript  = Join-Path $MainDir "coupling.py"

# Coupling interval and final time are supplied by parameters above.

# ============================================================
# PREPARE
# ============================================================

New-Item -ItemType Directory -Force -Path $AsciiDir | Out-Null
New-Item -ItemType Directory -Force -Path $TempFileDir | Out-Null

if (-not (Test-Path -LiteralPath $BaseXML)) {
    throw "Base XML not found: $BaseXML"
}

if (-not (Test-Path -LiteralPath $PythonScript)) {
    throw "Python coupling script not found: $PythonScript"
}

if ($dt -le 0) {
    throw "dt must be > 0."
}

if ($t_end -le 0) {
    throw "t_end must be > 0."
}

if ($dt -gt $t_end) {
    throw "dt cannot be greater than t_end."
}


# ============================================================
# HELPERS
# ============================================================

function Set-XmlValue {
    param(
        [Parameter(Mandatory=$true)] [string]$XmlFile,
        [Parameter(Mandatory=$true)] [string]$PropertyName,
        [Parameter(Mandatory=$true)] [string]$Value
    )

    $doc = New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.Load($XmlFile)

    $nodes = $doc.SelectNodes("//Property[@name='$PropertyName']/Value")

    if ($nodes.Count -eq 0) {
        throw "XML property '$PropertyName' not found in $XmlFile"
    }

    foreach ($node in $nodes) {
        $node.InnerText = $Value
    }

    $doc.Save($XmlFile)
}


function Set-TimeInterval {
    param(
        [Parameter(Mandatory=$true)] [string]$XmlFile,
        [Parameter(Mandatory=$true)] [double]$StartTime,
        [Parameter(Mandatory=$true)] [double]$EndTime
    )

    if ($EndTime -le $StartTime) {
        throw "Invalid TMG interval: $StartTime -> $EndTime"
    }

    $startText = "{0:E7}" -f $StartTime
    $endText   = "{0:E7}" -f $EndTime

    Set-XmlValue -XmlFile $XmlFile -PropertyName "Start Time" -Value $startText
    Set-XmlValue -XmlFile $XmlFile -PropertyName "End Time"   -Value $endText
}


function Set-Previous-TEMPF {
    param(
        [Parameter(Mandatory=$true)] [string]$XmlFile
    )

    # TMG/NX restart mode used by this coupling chain.
    Set-XmlValue -XmlFile $XmlFile `
        -PropertyName "Thermal Initial Temperature" `
        -Value "3"

    Set-XmlValue -XmlFile $XmlFile `
        -PropertyName "TEMPF File" `
        -Value $BinaryTEMPF
}


function Run-TMG {
    param(
        [Parameter(Mandatory=$true)] [string]$XmlFile
    )

    if (-not (Test-Path -LiteralPath $XmlFile)) {
        throw "TMG input XML does not exist: $XmlFile"
    }

    # Remove old result so a failed run cannot accidentally use stale TEMPF.
    if (Test-Path -LiteralPath $MainTEMPF) {
        Remove-Item -LiteralPath $MainTEMPF -Force
    }

    Write-Host ""
    Write-Host "============================================================"
    Write-Host "TMG RUN"
    Write-Host "XML : $XmlFile"
    Write-Host "============================================================"

    Push-Location $MainDir
    try {
        & $TMG nx -inPath $XmlFile
        $exitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    if ($exitCode -ne 0) {
        throw "TMG failed with exit code $exitCode."
    }

    if (-not (Test-Path -LiteralPath $MainTEMPF)) {
        throw "TMG completed but TEMPF was not produced: $MainTEMPF"
    }

    $size = (Get-Item -LiteralPath $MainTEMPF).Length
    if ($size -le 0) {
        throw "TMG produced an empty TEMPF."
    }

    Write-Host "Fresh binary TEMPF : $MainTEMPF"
    Write-Host "Size                : $size bytes"
}


function Convert-Fresh-TEMPF {
    param(
        [Parameter(Mandatory=$true)] [string]$ArchiveName
    )

    if (-not (Test-Path -LiteralPath $MainTEMPF)) {
        throw "No fresh binary TEMPF to convert."
    }

    foreach ($path in @($BinaryTEMPF, $AsciiTEMPF)) {
        if (Test-Path -LiteralPath $path) {
            Remove-Item -LiteralPath $path -Force
        }
    }

    # Keep a binary copy for the NEXT TMG restart.
    Copy-Item -LiteralPath $MainTEMPF -Destination $BinaryTEMPF -Force

    # Make a separate copy for ASCII conversion.
    Copy-Item -LiteralPath $MainTEMPF -Destination $AsciiTEMPF -Force

    Write-Host "Converting fresh TEMPF to ASCII..."

    Push-Location $AsciiDir
    try {
        & $TMG as
        $exitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    if ($exitCode -ne 0) {
        throw "TMG ASCII conversion failed with exit code $exitCode."
    }

    if (-not (Test-Path -LiteralPath $AsciiTEMPF)) {
        throw "ASCII TEMPF was not produced: $AsciiTEMPF"
    }

    $size = (Get-Item -LiteralPath $AsciiTEMPF).Length
    if ($size -le 0) {
        throw "ASCII TEMPF is empty."
    }

    # Basic sanity check. Do not assume any particular element ID.
    $sample = Get-Content -LiteralPath $AsciiTEMPF -TotalCount 300
    $numericLine = $sample | Where-Object {
        $_ -match '^\s*\d+\s+[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?\s*$'
    } | Select-Object -First 1

    if (-not $numericLine) {
        throw "ASCII TEMPF does not contain recognizable EID/temperature records."
    }

    $archive = Join-Path $AsciiDir $ArchiveName
    Copy-Item -LiteralPath $AsciiTEMPF -Destination $archive -Force

    Write-Host "ASCII TEMPF         : $AsciiTEMPF"
    Write-Host "Binary restart copy : $BinaryTEMPF"
    Write-Host "ASCII archive       : $archive"
}


function Run-PythonCoupling {
    param(
        [Parameter(Mandatory=$true)] [string]$InputXML,
        [Parameter(Mandatory=$true)] [string]$OutputXML,
        [Parameter(Mandatory=$true)] [int]$Step
    )

    Write-Host ""
    Write-Host "============================================================"
    Write-Host "PYTHON COUPLING STEP $Step"
    Write-Host "Input XML : $InputXML"
    Write-Host "TEMPF     : $AsciiTEMPF"
    Write-Host "Output XML: $OutputXML"
    Write-Host "============================================================"

    $pythonArgs = @(
        $PythonScript,
        "--tempf", $AsciiTEMPF,
        "--xml", $InputXML,
        "--output", $OutputXML,
        "--state", $StateFile,
        "--dt", $dt
    )

    if (-not [string]::IsNullOrWhiteSpace($DomainSet)) {
        $pythonArgs += @("--domain-set", $DomainSet)
    }

    & $Python @pythonArgs

    $exitCode = $LASTEXITCODE

    if ($exitCode -ne 0) {
        throw "Python coupling failed at step $Step with exit code $exitCode."
    }

    if (-not (Test-Path -LiteralPath $OutputXML)) {
        throw "Python completed but did not create: $OutputXML"
    }
}


# ============================================================
# START CLEAN
# ============================================================

# State belongs to a specific physical EID set.
# Use -ResetState when starting a new mesh/model or a new physical run.
if ($ResetState -and (Test-Path -LiteralPath $StateFile)) {
    Remove-Item -LiteralPath $StateFile -Force
    Write-Host "Previous decomposition state removed."
}


# ============================================================
# INITIAL TMG RUN
# ============================================================

Write-Host ""
Write-Host "============================================================"
Write-Host "START COUPLING"
Write-Host "dt    = $dt s"
Write-Host "t_end = $t_end s"
Write-Host "TMG   = $TMG"
Write-Host "============================================================"

# Make an independent initial XML so the user's original base XML
# is never modified.
$InitialXML = Join-Path $MainDir "Solution_000.xml"
Copy-Item -LiteralPath $BaseXML -Destination $InitialXML -Force

# Force the first TMG calculation to cover 0 -> dt.
Set-TimeInterval -XmlFile $InitialXML -StartTime 0.0 -EndTime ([Math]::Min($dt,$t_end))

Run-TMG -XmlFile $InitialXML
Convert-Fresh-TEMPF -ArchiveName "TEMPF_0000.txt"


# ============================================================
# COUPLING LOOP
# ============================================================

$CurrentXML = $InitialXML
$CurrentTime = [Math]::Min($dt, $t_end)
$StepNumber = 1

while ($CurrentTime -lt ($t_end - 1.0e-12)) {

    $StartTime = $CurrentTime
    $EndTime = [Math]::Min($CurrentTime + $dt, $t_end)

    $OutputXML = Join-Path $MainDir ("Solution_{0:D3}.xml" -f $StepNumber)

    # Python uses the fresh TEMPF from the immediately preceding TMG run.
    Run-PythonCoupling `
        -InputXML $CurrentXML `
        -OutputXML $OutputXML `
        -Step $StepNumber

    # The generated XML starts from the temperature field just produced
    # by the preceding TMG interval.
    Set-TimeInterval `
        -XmlFile $OutputXML `
        -StartTime $StartTime `
        -EndTime $EndTime

    Set-Previous-TEMPF -XmlFile $OutputXML

    # TMG advances the model using the newly generated material states
    # and Q_dec loads.
    Run-TMG -XmlFile $OutputXML

    Convert-Fresh-TEMPF `
        -ArchiveName ("TEMPF_{0:D4}.txt" -f $StepNumber)

    $CurrentXML = $OutputXML
    $CurrentTime = $EndTime
    $StepNumber++

    Write-Host ""
    Write-Host "Completed interval $StartTime -> $EndTime s"
    Write-Host "Current XML: $CurrentXML"
}


# ============================================================
# COMPLETE
# ============================================================

Write-Host ""
Write-Host "============================================================"
Write-Host "COUPLING COMPLETE"
Write-Host "Final XML : $CurrentXML"
Write-Host "End time  : $CurrentTime s"
Write-Host "dt        : $dt s"
Write-Host "============================================================"
