C=======================================================================
C
C     USER1 : T700/M21 CFRP THERMOCHEMICAL DECOMPOSITION (NX11 / TMG)
C             CONDNOS2 group-conductance version, corrected
C
C     Base: USER1_T700_M21_CONDNOS2_DIAGFIX.f. The two-reaction
C     kinetics (adaptive RK4), Cp, density and decomposition heat are
C     UNCHANGED. Changes (each one is switchable, see PARAMETERs):
C
C      1. KZ: removed a stray "*" ( ALPHA*  *(...)  was ALPHA**(...) ).
C      2. Conductances with GG0 < 0 (negative-resistance links of the
C         CG method, 4 of the 15 links of every hexahedron) are now
C         scaled like the others (FIXNEG). They were skipped, which is
C         the 15000 mapped - 11000 updated = 4000 difference.
C      3. LINK DIRECTION. READPROP2 returns centroid=(0,0,0) and
C         ELPROP(1)=0 for the INTERIOR boundary elements, so every
C         direction derived from boundary-element coordinates (the
C         original mid-point rule, or E1->E2) is meaningless. The
C         conductance pattern itself is used instead: in each hexahedron
C         the top<->bottom link has a resistance 4 orders of magnitude
C         smaller than the 14 others (= kz*A/dz); it is scaled with kz,
C         all other links (every one contains a side face, and all are
C         multiples of kx*dy*dz/dx) are scaled with the in-plane k.
C      4. Heat capacity and Q_dec are applied to the BOUNDARY elements
C         (CAPBND / QONBND). TMG moves the capacitance and heat loads
C         of solid elements from the CG to the boundary elements before
C         USER1 is called (transient-analysis algorithm, CG method).
C      5. Runtime diagnostics: KODE sequence, link classification,
C         link audit table, GG persistence at KODE=2, 3 mm probe.
C
C     Documentation facts used (Maya HTT thermal-API pages):
C       GG(j) = RESISTANCE (1/conductance): R_new = R0 * (K0/K).
C       CONDNOS2: icondno(2,3,j) internal labels, icondno(4,j) = parent
C                 element; element CG method only.
C       READPROP2: elprop(1,j) = area of one side of a shell element or
C                 volume of a solid element; elgeom(3,4,*) centroid in
C                 elgeom(1:3,1,j).
C       Q(i) is the total heat load, re-set by TMG every step: ADD.
C
C     SI units are assumed (m, kg, s, W, degC).
C
C=======================================================================

      SUBROUTINE USER1(GG,T,C,Q,QD,R,TIME,DT,IT,KODE,NOCON,MAXNO,
     + ICONV,DUM1,DUM2,DTP,TF)

      IMPLICIT NONE

      DOUBLE PRECISION T(*)
      DOUBLE PRECISION TIME
      DOUBLE PRECISION DT
      REAL GG(*)
      REAL C(*)
      REAL Q(*)
      REAL QD(*)
      REAL R(*)
      REAL DUM1
      REAL DUM2
      REAL DTP
      REAL TF
      INTEGER IT
      INTEGER KODE
      INTEGER NOCON
      INTEGER MAXNO
      INTEGER ICONV(*)

C     ---- user switches ----------------------------------------------
      LOGICAL QONBND
      LOGICAL CAPBND
      LOGICAL QUANT
      LOGICAL FIXNEG
      DOUBLE PRECISION ZRATIO
      DOUBLE PRECISION DIAGINT
      DOUBLE PRECISION PRTINT
      DOUBLE PRECISION PROBE
C     QONBND : .TRUE. add Q_dec to the boundary elements (area
C              weighted). .FALSE. = original: Q(N)=QSTORE*VOL on the CG.
C     CAPBND : .TRUE. also scale the capacitance of the boundary
C              elements of the CFRP hexahedra (CG capacitance is always
C              scaled). Harmless if the capacitance sits on the CG.
C     QUANT  : .TRUE. snap alpha to 20 states like the Python script
C              (alpha=ceil(alpha/0.05)*0.05). .FALSE. = continuous.
C     FIXNEG : .TRUE. scale links with GG0<0 too (original skipped).
C     ZRATIO : a link is the top<->bottom (kz) link of its hexahedron
C              if |GG0| < ZRATIO * (second smallest |GG0|) of that hex.
C     DIAGINT: seconds between diagnostic summaries
C     PRTINT : seconds between through-thickness temperature profiles
C     PROBE  : probe depth [m] (3 mm)
      PARAMETER (QONBND=.TRUE.)
      PARAMETER (CAPBND=.TRUE.)
      PARAMETER (QUANT=.FALSE.)
      PARAMETER (FIXNEG=.TRUE.)
      PARAMETER (ZRATIO=0.05D0)
      PARAMETER (DIAGINT=10.0D0)
      PARAMETER (PRTINT=50.0D0)
      PARAMETER (PROBE=3.0D-3)

      INTEGER MAXELEM
      INTEGER MAXCOND
      INTEGER MAXBOUND
      INTEGER MAXCND
      INTEGER MAXNODE
      INTEGER MAXCOL
      INTEGER MAXSAMP
      INTEGER NGRCOND
      PARAMETER (MAXELEM=50000)
      PARAMETER (MAXCOND=100000)
      PARAMETER (MAXBOUND=MAXELEM)
      PARAMETER (MAXCND=MAXCOND)
      PARAMETER (MAXNODE=100000)
      PARAMETER (MAXCOL=500)
      PARAMETER (MAXSAMP=15)

      INTEGER ICNDGR(4,MAXCOND)
      INTEGER ICNDTMP(4,MAXCND)
      INTEGER BOUNDARYLIST(MAXBOUND)
      INTEGER NCTMP,NB_TMP,IB,NBMARK
      LOGICAL ISBOUND(MAXELEM)
      INTEGER GLIST(MAXELEM)
      INTEGER GNUMELEM
      INTEGER GID
      INTEGER GLENGTH
      CHARACTER*7 SNAME
      CHARACTER*80 LNAME

      REAL ELPROP(10,MAXELEM)
      REAL ELGEOM(3,4,MAXELEM)
      INTEGER NODES(8,1)
      REAL NODELIST(3,1)

      REAL C0(MAXELEM)
      REAL C0B(MAXELEM)
      REAL GG0(MAXCOND)
      DOUBLE PRECISION ALPHA1(MAXELEM)
      DOUBLE PRECISION ALPHA2(MAXELEM)
      DOUBLE PRECISION QSTORE(MAXELEM)
      DOUBLE PRECISION QWATT(MAXELEM)
      DOUBLE PRECISION VOLE(MAXELEM)
      DOUBLE PRECISION RR(MAXELEM)
      DOUBLE PRECISION SUMV(MAXELEM)
      DOUBLE PRECISION SUMVR(MAXELEM)
      LOGICAL UPDATED(MAXCOND)
      LOGICAL SEEN(MAXCOND)
      LOGICAL ISCFRP(MAXELEM)
      DOUBLE PRECISION KXEL(MAXELEM)
      DOUBLE PRECISION KYEL(MAXELEM)
      DOUBLE PRECISION KZEL(MAXELEM)

      INTEGER LCLS(MAXCOND)
      INTEGER ZF1(MAXELEM)
      INTEGER ZF2(MAXELEM)
      INTEGER MINID(MAXELEM)
      INTEGER NLNK(MAXELEM)
      DOUBLE PRECISION MINA(MAXELEM)
      DOUBLE PRECISION MIN2A(MAXELEM)
      INTEGER NZOK
      INTEGER NAMB
      INTEGER NCHK1
      INTEGER NCHK2
      INTEGER NCHK3
      INTEGER NQFALL
      INTEGER NVALID
      DOUBLE PRECISION DZG
      DOUBLE PRECISION DXG
      DOUBLE PRECISION WZ
      DOUBLE PRECISION WLAT
      DOUBLE PRECISION AZ
      DOUBLE PRECISION AL
      INTEGER NBND(MAXELEM)
      INTEGER BND(8,MAXELEM)
      INTEGER NADJ(MAXELEM)
      INTEGER ADJN(4,MAXELEM)
      INTEGER BLIST(MAXELEM)
      INTEGER NBLIST

      INTEGER COLN(MAXCOL)
      DOUBLE PRECISION COLZ(MAXCOL)
      INTEGER NCOL
      INTEGER SAMPID(MAXSAMP)
      INTEGER SAMPE1(MAXSAMP)
      INTEGER SAMPE2(MAXSAMP)
      REAL GGEXP(MAXSAMP)
      INTEGER NSAMP
      DOUBLE PRECISION SAMPT(4)
      INTEGER ISAMP
      INTEGER CNT(16)
      INTEGER NK(0:9)
      INTEGER NCALL

      DOUBLE PRECISION LASTTIME
      DOUBLE PRECISION TPRINT
      DOUBLE PRECISION NEXTPRT
      DOUBLE PRECISION T2NEXT
      LOGICAL FIRST
      LOGICAL DISABLED
      LOGICAL NEWTIME

      INTEGER N
      INTEGER J
      INTEGER K
      INTEGER B
      INTEGER NMOD
      INTEGER NEQ
      INTEGER NREV
      INTEGER NOTH
      DOUBLE PRECISION TC
      DOUBLE PRECISION TK
      DOUBLE PRECISION A1OLD
      DOUBLE PRECISION A2OLD
      DOUBLE PRECISION A1NEW
      DOUBLE PRECISION A2NEW
      DOUBLE PRECISION RATE1
      DOUBLE PRECISION RATE2
      DOUBLE PRECISION ALPHA
      DOUBLE PRECISION ALPHAP
      DOUBLE PRECISION STATEX
      INTEGER ISTATE
      DOUBLE PRECISION RHOEL
      DOUBLE PRECISION CPC
      DOUBLE PRECISION KX
      DOUBLE PRECISION KY
      DOUBLE PRECISION KZ
      DOUBLE PRECISION RHOCP
      DOUBLE PRECISION RHOCP0
      DOUBLE PRECISION RHOCPA
      DOUBLE PRECISION RHOCPM
      DOUBLE PRECISION SUMC0
      DOUBLE PRECISION SUMCB
      DOUBLE PRECISION SUMVOL
      DOUBLE PRECISION CNEW
      DOUBLE PRECISION VOL
      DOUBLE PRECISION QCHEM
      DOUBLE PRECISION RHOGDOT
      DOUBLE PRECISION HNOW
      DOUBLE PRECISION H0
      DOUBLE PRECISION DH
      DOUBLE PRECISION QDECOMP
      DOUBLE PRECISION QW
      DOUBLE PRECISION ASUM
      DOUBLE PRECISION STEPDT
      DOUBLE PRECISION X0
      DOUBLE PRECISION Y0
      DOUBLE PRECISION XMIN
      DOUBLE PRECISION XMAX
      DOUBLE PRECISION YMIN
      DOUBLE PRECISION YMAX
      DOUBLE PRECISION TOLXY
      DOUBLE PRECISION ZTMP
      INTEGER NTMP
      DOUBLE PRECISION KXMIN
      DOUBLE PRECISION KXMAX
      DOUBLE PRECISION KZMIN
      DOUBLE PRECISION KZMAX
      DOUBLE PRECISION AMAX
      DOUBLE PRECISION TMINC
      DOUBLE PRECISION TMAXC
      DOUBLE PRECISION DXL
      DOUBLE PRECISION DYL
      DOUBLE PRECISION DZL
      DOUBLE PRECISION DLL

      DOUBLE PRECISION GASR
      DOUBLE PRECISION AA1
      DOUBLE PRECISION AA2
      DOUBLE PRECISION EEA1
      DOUBLE PRECISION EEA2
      DOUBLE PRECISION NN1
      DOUBLE PRECISION NN2
      DOUBLE PRECISION KCAT2
      DOUBLE PRECISION FF1
      DOUBLE PRECISION FF2
      DOUBLE PRECISION QDEC1
      DOUBLE PRECISION QDEC2
      DOUBLE PRECISION RHOV
      DOUBLE PRECISION RHOE
      DOUBLE PRECISION DRHOT
      DOUBLE PRECISION STATEDA
      INTEGER NSTATE
      PARAMETER (GASR=8.31446261815324D0)
      PARAMETER (AA1=7.219381629371594D0)
      PARAMETER (AA2=5.330893422367024D8)
      PARAMETER (EEA1=5.871070000000000D4)
      PARAMETER (EEA2=1.466740000000000D5)
      PARAMETER (NN1=1.1125D0)
      PARAMETER (NN2=2.0825D0)
      PARAMETER (KCAT2=7.488589075216437D0)
      PARAMETER (FF1=0.5540D0)
      PARAMETER (FF2=0.9479D0)
      PARAMETER (QDEC1=2.59540D5)
      PARAMETER (QDEC2=-1.52220D5)
      PARAMETER (RHOV=1575.0D0)
      PARAMETER (RHOE=1165.0D0)
      PARAMETER (DRHOT=410.0D0)
      PARAMETER (STATEDA=0.05D0)
      PARAMETER (NSTATE=20)

      SAVE
      DATA FIRST /.TRUE./
      DATA DISABLED /.FALSE./
      DATA LASTTIME /-1.0D30/
      DATA TPRINT /-1.0D30/
      DATA NEXTPRT /0.0D0/
      DATA T2NEXT /0.0D0/
      DATA NCOL /0/
      DATA NSAMP /0/
      DATA NCALL /0/
      DATA ISAMP /1/
      DATA SAMPT /1.0D0,100.0D0,200.0D0,300.0D0/
      DATA NK /10*0/
      DATA CNT /16*0/

C=======================================================================
C     CALL LOG (which KODE values does TMG really send?)
C=======================================================================

      NCALL=NCALL+1
      IF (KODE .GE. 0 .AND. KODE .LE. 9) NK(KODE)=NK(KODE)+1
      IF (NCALL .LE. 12) THEN
         PRINT *,' USER1 CALL',NCALL,' KODE=',KODE,' TIME=',TIME,
     +           ' IT=',IT
      ENDIF

C=======================================================================
C     INITIALIZATION (first call with KODE = 1, GG is still original)
C=======================================================================

      IF (FIRST .AND. KODE .EQ. 1) THEN

         FIRST=.FALSE.

         PRINT *,' '
         PRINT *,'=============================================='
         PRINT *,' CFRP USER1 THERMOCHEMICAL MODEL ACTIVE'
         PRINT *,'=============================================='
         PRINT *,' MAXNO=',MAXNO,' NOCON=',NOCON

         IF (MAXNO .GT. MAXELEM) THEN
            PRINT *,' ERROR: MAXNO EXCEEDS MAXELEM: ',MAXNO,MAXELEM
            DISABLED=.TRUE.
         ENDIF
         IF (NOCON .GT. MAXCOND) THEN
            PRINT *,' ERROR: NOCON EXCEEDS MAXCOND: ',NOCON,MAXCOND
            DISABLED=.TRUE.
         ENDIF

         IF (.NOT. DISABLED) THEN
            LNAME='Plate_3D'
            SNAME='       '
            GID=0
            GLENGTH=0
            CALL LONGNAME(SNAME,LNAME,GID,GLENGTH,2)
            GNUMELEM=0
            CALL NAMAR(SNAME,GLIST,GNUMELEM)
            PRINT *,' CFRP GROUP = ',SNAME
            PRINT *,' CFRP ELEMENT COUNT = ',GNUMELEM
            IF (GNUMELEM .LE. 0) THEN
               PRINT *,' ERROR: CFRP GROUP NOT FOUND'
               DISABLED=.TRUE.
            ELSE IF (GNUMELEM .GT. MAXELEM) THEN
               PRINT *,' ERROR: CFRP GROUP TOO LARGE'
               DISABLED=.TRUE.
            ENDIF
         ENDIF

         IF (.NOT. DISABLED) THEN

C           Element properties and geometry only (no node data).
            CALL READPROP2(ELPROP,ELGEOM,NODES,NODELIST,
     +                     'Y','Y','N','N')

            DO J=1,MAXELEM
               ISCFRP(J)=.FALSE.
               ISBOUND(J)=.FALSE.
               NBND(J)=0
               NADJ(J)=0
               C0B(J)=0.0
            END DO
            NBLIST=0
            SUMC0=0.0D0
            SUMCB=0.0D0
            SUMVOL=0.0D0

            DO J=1,GNUMELEM
               N=GLIST(J)
               IF (N .LE. 0 .OR. N .GT. MAXELEM) THEN
                  PRINT *,' ERROR: INTERNAL ELEMENT OUT OF RANGE: ',N
                  DISABLED=.TRUE.
               ELSE
                  ISCFRP(N)=.TRUE.
                  KXEL(N)=3.005125D0
                  KYEL(N)=3.005125D0
                  KZEL(N)=0.647249D0
                  ALPHA1(N)=0.0D0
                  ALPHA2(N)=0.0D0
                  QSTORE(N)=0.0D0
                  QWATT(N)=0.0D0
                  C0(N)=C(N)
                  VOLE(N)=DBLE(ELPROP(1,N))
                  SUMC0=SUMC0+DBLE(C0(N))
                  SUMVOL=SUMVOL+VOLE(N)
               ENDIF
            END DO
         ENDIF

         IF (.NOT. DISABLED) THEN

C           Boundary elements of every hexahedron (CONDNOS) and the
C           reverse map boundary element -> adjacent hexahedra.
            NBMARK=0
            DO J=1,GNUMELEM
               N=GLIST(J)
               NCTMP=0
               NB_TMP=0
               CALL CONDNOS(N,ICNDTMP,NCTMP,BOUNDARYLIST,NB_TMP)
               IF (NB_TMP .GT. 8) THEN
                  PRINT *,' ERROR: MORE THAN 8 BOUNDARY ELEMENTS: ',
     +                    N,NB_TMP
                  DISABLED=.TRUE.
                  NB_TMP=8
               ENDIF
               NBND(N)=NB_TMP
               DO IB=1,NB_TMP
                  B=BOUNDARYLIST(IB)
                  BND(IB,N)=B
                  IF (B .GT. 0 .AND. B .LE. MAXELEM) THEN
                     IF (.NOT.ISBOUND(B)) THEN
                        ISBOUND(B)=.TRUE.
                        NBMARK=NBMARK+1
                        NBLIST=NBLIST+1
                        BLIST(NBLIST)=B
                        C0B(B)=C(B)
                        SUMCB=SUMCB+DBLE(C0B(B))
                     ENDIF
                     IF (NADJ(B) .LT. 4) THEN
                        NADJ(B)=NADJ(B)+1
                        ADJN(NADJ(B),B)=N
                     ENDIF
                  ENDIF
               END DO
            END DO
            PRINT *,' CFRP-ASSOCIATED BOUNDARY ELEMENTS = ',NBMARK

            DO J=1,NOCON
               GG0(J)=GG(J)
               UPDATED(J)=.FALSE.
               SEEN(J)=.FALSE.
            END DO

            NGRCOND=0
            CALL CONDNOS2(SNAME,ICNDGR,NGRCOND)
            PRINT *,' TMG GROUP CONDUCTANCE MAP COUNT = ',NGRCOND
            IF (NGRCOND .LE. 0) THEN
               PRINT *,' ERROR: CONDNOS2 RETURNED NO GROUP CONDUCTANCES'
               DISABLED=.TRUE.
            ELSE IF (NGRCOND .GT. MAXCOND) THEN
               PRINT *,' ERROR: CONDNOS2 COUNT EXCEEDS MAXCOND: ',
     +                 NGRCOND,MAXCOND
               DISABLED=.TRUE.
            ENDIF
         ENDIF

         IF (.NOT. DISABLED) THEN

C           ---- capacitance reference --------------------------------
            RHOCPA=RHOV*(2.8773D0*30.0D0+687.31D0)
            RHOCP0=RHOCPA
            RHOCPM=0.0D0
            IF (SUMVOL .GT. 0.0D0) RHOCPM=(SUMC0+SUMCB)/SUMVOL
            PRINT *,' CAPACITANCE ON CG (sum C0)        = ',SUMC0
            PRINT *,' CAPACITANCE ON BOUNDARY (sum C0B) = ',SUMCB
            PRINT *,' CFRP VOLUME (sum ELPROP(1,hex))   = ',SUMVOL
            PRINT *,' (C0+C0B)/VOLUME = ',RHOCPM,
     +              '  assumed rho*cp(30C) = ',RHOCPA
            IF (RHOCPM .GT. 0.8D0*RHOCPA .AND.
     +          RHOCPM .LT. 1.25D0*RHOCPA) THEN
               RHOCP0=RHOCPM
               PRINT *,' -> measured base rho*cp used as reference'
            ELSE
               PRINT *,' WARNING: base rho*cp is not the virgin CFRP',
     +                 ' value; assumed reference kept.'
            ENDIF
            IF (SUMC0 .LT. 0.2D0*(SUMC0+SUMCB)) THEN
               PRINT *,' NOTE: capacitance sits on the BOUNDARY',
     +                 ' elements (CG redistribution is active)'
            ENDIF

C           ---- which link is the top<->bottom (kz) link? ----------
            CALL CFRP_ZLINKS(NGRCOND,ICNDGR,GG0,NOCON,GLIST,GNUMELEM,
     +                       ISCFRP,MINA,MIN2A,MINID,NLNK,LCLS,ZF1,
     +                       ZF2,ZRATIO,NZOK,NAMB)
            CALL CFRP_ZCHECK(GLIST,GNUMELEM,ZF1,ZF2,NADJ,ADJN,ELGEOM,
     +                       NCHK1,NCHK2,NCHK3)
            CALL CFRP_CLASSIFY(NGRCOND,ICNDGR,GG0,NOCON,ISCFRP,
     +                         ISBOUND,SEEN,LCLS,SAMPID,SAMPE1,SAMPE2,
     +                         MAXSAMP,NSAMP,GLIST(1),NZOK,NAMB,NCHK1,
     +                         NCHK2,NCHK3)
            NVALID=0
            DO J=1,NBLIST
               IF (ELPROP(1,BLIST(J)) .GT. 0.0) NVALID=NVALID+1
            END DO
            PRINT *,' boundary elements with READPROP2 data (area>0):',
     +              NVALID,' of ',NBLIST
            IF (NVALID .LT. NBLIST) THEN
               PRINT *,' NOTE: interior boundary elements have NO',
     +                 ' geometry; link class comes from GG0 pattern.'
            ENDIF

C           ---- through-thickness column (3 mm probe) ----------------
            XMIN=1.0D30
            XMAX=-1.0D30
            YMIN=1.0D30
            YMAX=-1.0D30
            DO J=1,GNUMELEM
               N=GLIST(J)
               IF (DBLE(ELGEOM(1,1,N)) .LT. XMIN)
     +            XMIN=DBLE(ELGEOM(1,1,N))
               IF (DBLE(ELGEOM(1,1,N)) .GT. XMAX)
     +            XMAX=DBLE(ELGEOM(1,1,N))
               IF (DBLE(ELGEOM(2,1,N)) .LT. YMIN)
     +            YMIN=DBLE(ELGEOM(2,1,N))
               IF (DBLE(ELGEOM(2,1,N)) .GT. YMAX)
     +            YMAX=DBLE(ELGEOM(2,1,N))
            END DO
            TOLXY=1.0D-4*MAX(XMAX-XMIN,YMAX-YMIN)
            IF (TOLXY .LE. 0.0D0) TOLXY=1.0D-9
            X0=DBLE(ELGEOM(1,1,GLIST(1)))
            Y0=DBLE(ELGEOM(2,1,GLIST(1)))
            NCOL=0
            DO J=1,GNUMELEM
               N=GLIST(J)
               IF (ABS(DBLE(ELGEOM(1,1,N))-X0)
     +            +ABS(DBLE(ELGEOM(2,1,N))-Y0) .LE. TOLXY) THEN
                  IF (NCOL .LT. MAXCOL) THEN
                     NCOL=NCOL+1
                     COLN(NCOL)=N
                     COLZ(NCOL)=DBLE(ELGEOM(3,1,N))
                  ENDIF
               ENDIF
            END DO
            DO J=2,NCOL
               ZTMP=COLZ(J)
               NTMP=COLN(J)
               K=J-1
   10          IF (K .GE. 1) THEN
                  IF (COLZ(K) .GT. ZTMP) THEN
                     COLZ(K+1)=COLZ(K)
                     COLN(K+1)=COLN(K)
                     K=K-1
                     GOTO 10
                  ENDIF
               ENDIF
               COLZ(K+1)=ZTMP
               COLN(K+1)=NTMP
            END DO
            PRINT *,' PROFILE COLUMN under element',GLIST(1),
     +              ': x,y =',X0,Y0,' elements =',NCOL
            DO J=1,NCOL
               N=COLN(J)
               PRINT *,'   layer',J,' int',N,' ext',ICONV(N),
     +                 ' centroid',(ELGEOM(K,1,N),K=1,3)
            END DO

C           ---- heat-load weights (flat hexahedra: z faces carry
C                nearly all the boundary area) -------------------------
            WZ=0.5D0
            WLAT=0.0D0
            IF (NCOL .GT. 1 .AND. SUMVOL .GT. 0.0D0) THEN
               DZG=ABS(COLZ(2)-COLZ(1))
               IF (DZG .GT. 0.0D0) THEN
                  DXG=DSQRT((SUMVOL/DBLE(GNUMELEM))/DZG)
                  AZ=DXG*DXG
                  AL=DXG*DZG
                  WZ=AZ/(2.0D0*AZ+4.0D0*AL)
                  WLAT=AL/(2.0D0*AZ+4.0D0*AL)
               ENDIF
            ENDIF
            PRINT *,' Q_dec split per hex: each z face =',WZ,
     +              ' each side face =',WLAT
            NQFALL=0

C           ---- structure dump of two hexahedra ----------------------
            CALL CFRP_DUMP(GLIST(1),NGRCOND,ICNDGR,ICONV,ELGEOM,ELPROP,
     +                     C,GG0,LCLS,ZF1,ZF2)
            CALL CFRP_DUMP(GLIST(GNUMELEM/2),NGRCOND,ICNDGR,ICONV,
     +                     ELGEOM,ELPROP,C,GG0,LCLS,ZF1,ZF2)

            PRINT *,' FIRST CFRP INTERNAL = ',GLIST(1)
            PRINT *,' LAST CFRP INTERNAL  = ',GLIST(GNUMELEM)
            PRINT *,'=============================================='
            PRINT *,' CFRP INITIALIZATION COMPLETE'
            PRINT *,'=============================================='

         ENDIF

      ENDIF

      IF (DISABLED) RETURN
      IF (FIRST) RETURN

C=======================================================================
C     KODE = 2 : after the temperatures are calculated.
C     Did the GG values written at KODE = 1 survive the solve?
C=======================================================================

      IF (KODE .EQ. 2) THEN
         IF (NSAMP .GT. 0 .AND. TIME .GT. 1.0D0 .AND.
     +       TIME .GE. T2NEXT) THEN
            NEQ=0
            NREV=0
            NOTH=0
            DO J=1,NSAMP
               IF (ABS(GG(SAMPID(J))-GGEXP(J)) .LE.
     +             1.0E-5*ABS(GGEXP(J))) THEN
                  NEQ=NEQ+1
               ELSE IF (ABS(GG(SAMPID(J))-GG0(SAMPID(J))) .LE.
     +                  1.0E-5*ABS(GG0(SAMPID(J)))) THEN
                  NREV=NREV+1
               ELSE
                  NOTH=NOTH+1
               ENDIF
            END DO
            PRINT *,' GG PERSISTENCE at KODE=2, t=',TIME,
     +              ': kept=',NEQ,' reverted-to-GG0=',NREV,
     +              ' other=',NOTH,' of ',NSAMP
            T2NEXT=TIME+DIAGINT
         ENDIF
         RETURN
      ENDIF

C=======================================================================
C     KODE = 3 : end of run
C=======================================================================

      IF (KODE .EQ. 3) THEN
         PRINT *,' CFRP FINAL SUMMARY t=',TIME
         PRINT *,'   calls per KODE 0..9: ',(NK(K),K=0,9)
         PRINT *,'   last update: updated=',CNT(1)+CNT(2),
     +          ' skipped(GG0=0)=',CNT(3),' invalid=',CNT(4),
     +          ' degenerate=',CNT(5),' not-CFRP=',CNT(6),
     +          ' K<=0=',CNT(7),' duplicates=',CNT(11)
         CALL CFRP_SAMPLES(TIME,NSAMP,SAMPID,SAMPE1,SAMPE2,GG,GG0,
     +                     ICONV)
         IF (NCOL .GT. 0) CALL CFRP_PROFILE(TIME,T,NCOL,COLN,COLZ,
     +                                      PROBE,ICONV)
         RETURN
      ENDIF

      IF (KODE .NE. 1) RETURN

C=======================================================================
C     KODE = 1 : before the temperatures are calculated
C=======================================================================

      NEWTIME=.FALSE.
      IF (TIME .GT. LASTTIME+1.0D-12) THEN
         NEWTIME=.TRUE.
      ENDIF

      KXMIN=1.0D30
      KXMAX=-1.0D30
      KZMIN=1.0D30
      KZMAX=-1.0D30
      AMAX=0.0D0
      TMINC=1.0D30
      TMAXC=-1.0D30

      DO J=1,GNUMELEM
         N=GLIST(J)
         TC=T(N)
         TK=TC+273.15D0
         IF (TK .LT. 1.0D0) TK=1.0D0

C        ---- chemistry (UNCHANGED): once per new time value --------
         IF (NEWTIME .AND. TIME .GT. 1.0D-12) THEN
            A1OLD=ALPHA1(N)
            A2OLD=ALPHA2(N)
            IF (LASTTIME .LT. -1.0D20) THEN
               STEPDT=DT
            ELSE
               STEPDT=TIME-LASTTIME
            ENDIF
            IF (STEPDT .LE. 0.0D0) STEPDT=DT
            IF (STEPDT .GT. 0.0D0) THEN
               CALL CFRP_RK4(A1OLD,A2OLD,TK,STEPDT,
     +                       A1NEW,A2NEW)
               RATE1=(A1NEW-A1OLD)/STEPDT
               RATE2=(A2NEW-A2OLD)/STEPDT
            ELSE
               A1NEW=A1OLD
               A2NEW=A2OLD
               RATE1=0.0D0
               RATE2=0.0D0
            ENDIF
            ALPHA1(N)=A1NEW
            ALPHA2(N)=A2NEW
            QCHEM=
     +         FF1*QDEC1*DRHOT*RATE1
     +       + FF2*QDEC2*DRHOT*RATE2
            RHOGDOT=
     +         FF1*DRHOT*RATE1
     +       + FF2*DRHOT*RATE2
            HNOW=
     +         (3.5977D-7/4.0D0)*TC**4
     +       - (9.2485D-4/3.0D0)*TC**3
     +       + (1.0610D0/2.0D0)*TC**2
     +       + 1256.6D0*TC
            H0=
     +         (3.5977D-7/4.0D0)*30.0D0**4
     +       - (9.2485D-4/3.0D0)*30.0D0**3
     +       + (1.0610D0/2.0D0)*30.0D0**2
     +       + 1256.6D0*30.0D0
            DH=HNOW-H0
            IF (DH .LT. 0.0D0) DH=0.0D0
            QDECOMP=QCHEM-RHOGDOT*DH
            QSTORE(N)=QDECOMP
         ENDIF

C        ---- alpha for the properties (optionally 20-state binned) --
         ALPHA=
     +      FF1*ALPHA1(N)
     +    + FF2*ALPHA2(N)
         IF (ALPHA .LT. 0.0D0) ALPHA=0.0D0
         IF (ALPHA .GT. 1.0D0) ALPHA=1.0D0
         ALPHAP=ALPHA
         IF (QUANT) THEN
            STATEX=ALPHA/STATEDA
            ISTATE=INT(STATEX)
            IF (STATEX .GT. DBLE(ISTATE)) ISTATE=ISTATE+1
            IF (ISTATE .LT. 1) ISTATE=1
            IF (ISTATE .GT. NSTATE) ISTATE=NSTATE
            ALPHAP=DBLE(ISTATE)*STATEDA
         ENDIF

C        ---- properties (UNCHANGED except the KZ stray "*") ---------
         RHOEL=RHOV-DRHOT*ALPHAP
         IF (RHOEL .LT. RHOE) RHOEL=RHOE
         IF (RHOEL .GT. RHOV) RHOEL=RHOV
         CPC=
     +      (1.0D0-ALPHAP)
     +      *(2.8773D0*TC+687.31D0)
     +    + ALPHAP*
     +      (5.1327D-7*TC**3
     +      -2.0761D-3*TC**2
     +      +2.599D0*TC
     +      +662.53D0)
         KX=
     +      (1.0D0-ALPHAP)
     +      *(7.4675D-3*TC+2.7811D0)
     +    + ALPHAP*
     +      (-3.5481D-6*TC**2
     +      +6.4898D-3*TC
     +      +2.3005D0)
         KY=KX
C        FIX: the original had "ALPHA*" followed by a continuation line
C        starting with "*(" which the compiler reads as ALPHA**(...).
         KZ=
     +      (1.0D0-ALPHAP)
     +      *(1.1113D-3*TC+0.61391D0)
     +    + ALPHAP*
     +      (7.4228D-10*TC**3
     +      -4.1903D-7*TC**2
     +      +2.3397D-4*TC
     +      +7.7211D-2)
         IF (KX .LT. 1.0D-8) KX=1.0D-8
         IF (KY .LT. 1.0D-8) KY=1.0D-8
         IF (KZ .LT. 1.0D-8) KZ=1.0D-8

         RHOCP=RHOEL*CPC
         RR(N)=RHOCP/RHOCP0
         CNEW=DBLE(C0(N))*RR(N)
         C(N)=REAL(CNEW)

         QWATT(N)=QSTORE(N)*VOLE(N)
         IF (.NOT. QONBND) Q(N)=REAL(QWATT(N))

         KXEL(N)=KX
         KYEL(N)=KY
         KZEL(N)=KZ

         IF (KX .LT. KXMIN) KXMIN=KX
         IF (KX .GT. KXMAX) KXMAX=KX
         IF (KZ .LT. KZMIN) KZMIN=KZ
         IF (KZ .GT. KZMAX) KZMAX=KZ
         IF (ALPHA .GT. AMAX) AMAX=ALPHA
         IF (TC .LT. TMINC) TMINC=TC
         IF (TC .GT. TMAXC) TMAXC=TC
      END DO

C=======================================================================
C     BOUNDARY ELEMENTS: capacitance and decomposition heat
C=======================================================================

      IF (CAPBND) THEN
         DO J=1,NBLIST
            B=BLIST(J)
            SUMV(B)=0.0D0
            SUMVR(B)=0.0D0
         END DO
         DO J=1,GNUMELEM
            N=GLIST(J)
            DO K=1,NBND(N)
               B=BND(K,N)
               IF (B .GT. 0 .AND. B .LE. MAXELEM) THEN
                  SUMV(B)=SUMV(B)+VOLE(N)
                  SUMVR(B)=SUMVR(B)+VOLE(N)*RR(N)
               ENDIF
            END DO
         END DO
         DO J=1,NBLIST
            B=BLIST(J)
            IF (SUMV(B) .GT. 0.0D0) THEN
               C(B)=REAL(DBLE(C0B(B))*SUMVR(B)/SUMV(B))
            ENDIF
         END DO
      ENDIF

      IF (QONBND) THEN
         DO J=1,GNUMELEM
            N=GLIST(J)
            QW=QWATT(N)
            IF (QW .NE. 0.0D0) THEN
               IF (ZF1(N) .GT. 0 .AND. NBND(N) .GT. 2) THEN
C                 z faces (top/bottom) and the side faces
                  Q(ZF1(N))=Q(ZF1(N))+REAL(QW*WZ)
                  Q(ZF2(N))=Q(ZF2(N))+REAL(QW*WZ)
                  DO K=1,NBND(N)
                     B=BND(K,N)
                     IF (B .NE. ZF1(N) .AND. B .NE. ZF2(N)) THEN
                        Q(B)=Q(B)+REAL(QW*WLAT)
                     ENDIF
                  END DO
               ELSE
                  Q(N)=Q(N)+REAL(QW)
                  NQFALL=NQFALL+1
               ENDIF
            ENDIF
         END DO
      ENDIF

C=======================================================================
C     CONDUCTANCES (GG = resistance)
C=======================================================================

      DO J=1,NOCON
         UPDATED(J)=.FALSE.
      END DO
      DO J=1,16
         CNT(J)=0
      END DO
      NMOD=0
      CALL CFRP_UPDATE_GROUP(NGRCOND,ICNDGR,GG,GG0,UPDATED,
     +     NOCON,MAXCOND,ELGEOM,KXEL,KYEL,KZEL,ISCFRP,
     +     ISBOUND,MAXELEM,NMOD,FIXNEG,LCLS,CNT)

      DO J=1,NSAMP
         GGEXP(J)=GG(SAMPID(J))
      END DO

C=======================================================================
C     DIAGNOSTICS (bounded)
C=======================================================================

      IF (NEWTIME) THEN

         IF (TIME .GE. TPRINT+DIAGINT-1.0D-9) THEN
            PRINT *,' CFRP t=',TIME,' alphaMAX=',AMAX,
     +              ' Tmin/Tmax(CG)=',TMINC,TMAXC
            PRINT *,'      KX min/max=',KXMIN,KXMAX,
     +              ' KZ min/max=',KZMIN,KZMAX
            PRINT *,'      GG map=',NGRCOND,' updated=',NMOD,
     +              ' (via CFRP endpoint=',CNT(1),' via parent=',
     +              CNT(2),') negative-GG0 updated=',CNT(8)
            PRINT *,'      kz-class links=',CNT(9),' in-plane links=',
     +              CNT(10),' Q on CG fallback=',NQFALL,
     +              ' skipped: GG0=0:',CNT(3),' invalid:',CNT(4),
     +              ' degenerate:',CNT(5),' not-CFRP:',CNT(6),
     +              ' K<=0:',CNT(7),' duplicate-id:',CNT(11)
            PRINT *,'      calls per KODE 0..9: ',(NK(K),K=0,9)
            TPRINT=TIME
         ENDIF

         IF (ISAMP .LE. 4) THEN
            IF (TIME .GE. SAMPT(ISAMP)-1.0D-9) THEN
               CALL CFRP_SAMPLES(TIME,NSAMP,SAMPID,SAMPE1,SAMPE2,GG,
     +                           GG0,ICONV)
               ISAMP=ISAMP+1
            ENDIF
         ENDIF

         IF (NCOL .GT. 0 .AND. TIME .GE. NEXTPRT-1.0D-9) THEN
            CALL CFRP_PROFILE(TIME,T,NCOL,COLN,COLZ,PROBE,ICONV)
            NEXTPRT=NEXTPRT+PRTINT
         ENDIF

         LASTTIME=TIME

      ENDIF

      RETURN
      END

      SUBROUTINE CFRP_RK4(A1,A2,TK,DT,AN1,AN2)
      IMPLICIT NONE
      DOUBLE PRECISION A1,A2,TK,DT,AN1,AN2
      DOUBLE PRECISION K1A,K1B,K2A,K2B
      DOUBLE PRECISION K3A,K3B,K4A,K4B
      DOUBLE PRECISION X1,X2,H,TLEFT,RTOT,F1R,F2R
      DOUBLE PRECISION SCALE
      INTEGER NSUB
      INTEGER MAXSUB
      PARAMETER (MAXSUB=50000)
      AN1=MAX(0.0D0,MIN(1.0D0,A1))
      AN2=MAX(0.0D0,MIN(1.0D0,A2))
      IF (AN1+AN2 .GT. 1.0D0) THEN
         SCALE=1.0D0/(AN1+AN2)
         AN1=AN1*SCALE
         AN2=AN2*SCALE
      ENDIF
      IF (DT .LE. 0.0D0) RETURN
      TLEFT=DT
      NSUB=0
  10  CONTINUE
      IF (TLEFT .LE. MAX(1.0D-14,DT*1.0D-12)) GOTO 90
      CALL CFRP_RATE(AN1,AN2,TK,F1R,F2R)
      RTOT=F1R+F2R
      IF (RTOT .GT. 1.0D-20) THEN
         H=MIN(TLEFT,0.05D0/RTOT)
      ELSE
         H=TLEFT
      ENDIF
      IF (H .LE. 0.0D0) GOTO 90
      IF (NSUB .GE. MAXSUB) THEN
         IF (RTOT .GT. 1.0D-20) THEN
            SCALE=F1R/RTOT
            X1=1.0D0-AN1-AN2
            IF (X1 .LT. 0.0D0) X1=0.0D0
            AN1=AN1+X1*SCALE
            AN2=AN2+X1*(1.0D0-SCALE)
         ENDIF
         GOTO 90
      ENDIF
      CALL CFRP_RATE(AN1,AN2,TK,K1A,K1B)
      X1=AN1+0.5D0*H*K1A
      X2=AN2+0.5D0*H*K1B
      CALL CFRP_RATE(X1,X2,TK,K2A,K2B)
      X1=AN1+0.5D0*H*K2A
      X2=AN2+0.5D0*H*K2B
      CALL CFRP_RATE(X1,X2,TK,K3A,K3B)
      X1=AN1+H*K3A
      X2=AN2+H*K3B
      CALL CFRP_RATE(X1,X2,TK,K4A,K4B)
      X1=AN1+(H/6.0D0)*
     +   (K1A+2.0D0*K2A+2.0D0*K3A+K4A)
      X2=AN2+(H/6.0D0)*
     +   (K1B+2.0D0*K2B+2.0D0*K3B+K4B)
      AN1=MAX(0.0D0,MIN(1.0D0,X1))
      AN2=MAX(0.0D0,MIN(1.0D0,X2))
      IF (AN1+AN2 .GT. 1.0D0) THEN
         SCALE=1.0D0/(AN1+AN2)
         AN1=AN1*SCALE
         AN2=AN2*SCALE
      ENDIF
      TLEFT=TLEFT-H
      NSUB=NSUB+1
      GOTO 10
  90  CONTINUE
      RETURN
      END
      SUBROUTINE CFRP_RATE(A1,A2,TK,F1R,F2R)
      IMPLICIT NONE
      DOUBLE PRECISION A1
      DOUBLE PRECISION A2
      DOUBLE PRECISION TK
      DOUBLE PRECISION F1R
      DOUBLE PRECISION F2R
      DOUBLE PRECISION GASR
      DOUBLE PRECISION AA1
      DOUBLE PRECISION AA2
      DOUBLE PRECISION EEA1
      DOUBLE PRECISION EEA2
      DOUBLE PRECISION NN1
      DOUBLE PRECISION NN2
      DOUBLE PRECISION KCAT2
      DOUBLE PRECISION REM
      DOUBLE PRECISION EX1
      DOUBLE PRECISION EX2
      PARAMETER (GASR=8.31446261815324D0)
      PARAMETER (AA1=7.219381629371594D0)
      PARAMETER (AA2=5.330893422367024D8)
      PARAMETER (EEA1=5.871070000000000D4)
      PARAMETER (EEA2=1.466740000000000D5)
      PARAMETER (NN1=1.1125D0)
      PARAMETER (NN2=2.0825D0)
      PARAMETER (KCAT2=7.488589075216437D0)
      REM=1.0D0-A1-A2
      IF (REM .LT. 0.0D0) REM=0.0D0
      IF (REM .GT. 1.0D0) REM=1.0D0
      IF (TK .LE. 1.0D0) THEN
         F1R=0.0D0
         F2R=0.0D0
         RETURN
      ENDIF
      EX1=DEXP(-EEA1/(GASR*TK))
      F1R=AA1*REM**NN1*EX1
      EX2=DEXP(-EEA2/(GASR*TK))
      F2R=AA2*REM**NN2*EX2*
     +    (1.0D0+KCAT2*A2)
      IF (F1R .LT. 0.0D0) F1R=0.0D0
      IF (F2R .LT. 0.0D0) F2R=0.0D0
      RETURN
      END

C=======================================================================
C     WHICH LINK OF EACH HEXAHEDRON IS THE TOP<->BOTTOM (kz) LINK?
C
C     Observed in the model: the 15 face-to-face links of a flat hex
C     are  1 x 0.39 K/W (= kz*A/dz, top<->bottom), 8 x 2218.9 K/W,
C     4 x 13305 K/W and 2 x -4437.9 K/W (all = multiples of
C     kx*dy*dz/dx).  The top<->bottom link is therefore the one with
C     the smallest |GG0|, 4 orders of magnitude below the others.
C     No boundary-element geometry is needed (READPROP2 returns zeros
C     for interior boundary elements).
C=======================================================================

      SUBROUTINE CFRP_ZLINKS(NGRCOND,ICNDGR,GG0,NOCON,GLIST,GNUM,
     +     ISCFRP,MINA,MIN2A,MINID,NLNK,LCLS,ZF1,ZF2,ZRATIO,NZOK,NAMB)

      IMPLICIT NONE

      INTEGER NGRCOND,NOCON,GNUM,NZOK,NAMB
      INTEGER ICNDGR(4,*)
      REAL GG0(*)
      INTEGER GLIST(*)
      LOGICAL ISCFRP(*)
      DOUBLE PRECISION MINA(*),MIN2A(*),ZRATIO
      INTEGER MINID(*),NLNK(*),LCLS(*),ZF1(*),ZF2(*)

      INTEGER I,J,N,ID,PAR
      DOUBLE PRECISION G

      DO I=1,GNUM
         N=GLIST(I)
         MINA(N)=1.0D30
         MIN2A(N)=1.0D30
         MINID(N)=0
         NLNK(N)=0
         ZF1(N)=0
         ZF2(N)=0
      END DO

      DO J=1,NGRCOND
         LCLS(J)=0
         ID=ICNDGR(1,J)
         PAR=ICNDGR(4,J)
         IF (ID .GT. 0 .AND. ID .LE. NOCON .AND. PAR .GT. 0 .AND.
     +       PAR .LE. 50000) THEN
            IF (ISCFRP(PAR)) THEN
               G=ABS(DBLE(GG0(ID)))
               NLNK(PAR)=NLNK(PAR)+1
               IF (G .LT. MINA(PAR)) THEN
                  MIN2A(PAR)=MINA(PAR)
                  MINA(PAR)=G
                  MINID(PAR)=ID
               ELSE IF (G .LT. MIN2A(PAR)) THEN
                  MIN2A(PAR)=G
               ENDIF
            ENDIF
         ENDIF
      END DO

      NZOK=0
      NAMB=0
      DO I=1,GNUM
         N=GLIST(I)
         IF (NLNK(N) .GE. 2 .AND. MIN2A(N) .GT. 0.0D0 .AND.
     +       MINA(N) .LT. ZRATIO*MIN2A(N)) THEN
            NZOK=NZOK+1
         ELSE
            NAMB=NAMB+1
            MINID(N)=0
         ENDIF
      END DO

      DO J=1,NGRCOND
         ID=ICNDGR(1,J)
         PAR=ICNDGR(4,J)
         IF (PAR .GT. 0 .AND. PAR .LE. 50000) THEN
            IF (ISCFRP(PAR) .AND. ID .GT. 0) THEN
               IF (MINID(PAR) .EQ. ID) THEN
                  LCLS(J)=1
                  ZF1(PAR)=ICNDGR(2,J)
                  ZF2(PAR)=ICNDGR(3,J)
               ENDIF
            ENDIF
         ENDIF
      END DO

      RETURN
      END


C=======================================================================
C     CROSS-CHECK of the kz link with the hex-to-hex topology: a face
C     shared with another hexahedron must lie in the z direction.
C=======================================================================

      SUBROUTINE CFRP_ZCHECK(GLIST,GNUM,ZF1,ZF2,NADJ,ADJN,ELGEOM,
     +     NOK,NBAD,NUNK)

      IMPLICIT NONE

      INTEGER GLIST(*),GNUM,ZF1(*),ZF2(*),NADJ(*),ADJN(4,*)
      REAL ELGEOM(3,4,*)
      INTEGER NOK,NBAD,NUNK

      INTEGER I,F,N,B,M,K
      LOGICAL FOUND
      DOUBLE PRECISION DZV,DXY

      NOK=0
      NBAD=0
      NUNK=0
      DO I=1,GNUM
         N=GLIST(I)
         DO F=1,2
            IF (F .EQ. 1) THEN
               B=ZF1(N)
            ELSE
               B=ZF2(N)
            ENDIF
            IF (B .GT. 0 .AND. B .LE. 50000) THEN
               FOUND=.FALSE.
               DO K=1,NADJ(B)
                  M=ADJN(K,B)
                  IF (M .NE. N .AND. .NOT. FOUND) THEN
                     FOUND=.TRUE.
                     DZV=ABS(DBLE(ELGEOM(3,1,M))-DBLE(ELGEOM(3,1,N)))
                     DXY=DSQRT((DBLE(ELGEOM(1,1,M))
     +                         -DBLE(ELGEOM(1,1,N)))**2
     +                        +(DBLE(ELGEOM(2,1,M))
     +                         -DBLE(ELGEOM(2,1,N)))**2)
                     IF (DZV .GT. DXY) THEN
                        NOK=NOK+1
                     ELSE
                        NBAD=NBAD+1
                     ENDIF
                  ENDIF
               END DO
               IF (.NOT. FOUND) NUNK=NUNK+1
            ENDIF
         END DO
      END DO

      RETURN
      END


C=======================================================================
C     CONDUCTANCE UPDATE FOR THE WHOLE GROUP (GG = resistance)
C
C     R_new = R0 * K0/K ; K = kz for the top<->bottom link (LCLS=1),
C     in-plane k for every other link of the hexahedron.  The sign of
C     R0 is kept (negative-resistance links are scaled too).
C=======================================================================

      SUBROUTINE CFRP_UPDATE_GROUP(NGRCOND,ICNDGR,GG,GG0,
     +     UPDATED,NOCON,MAXCOND,ELGEOM,KXEL,KYEL,KZEL,
     +     ISCFRP,ISBOUND,MAXMODEL,NMOD,FIXNEG,LCLS,CNT)

      IMPLICIT NONE

      INTEGER NGRCOND,NOCON,MAXCOND,MAXMODEL,NMOD
      INTEGER ICNDGR(4,*)
      REAL GG(*),GG0(*)
      LOGICAL UPDATED(*),ISCFRP(*),ISBOUND(*)
      REAL ELGEOM(3,4,*)
      DOUBLE PRECISION KXEL(*),KYEL(*),KZEL(*)
      LOGICAL FIXNEG
      INTEGER LCLS(*)
      INTEGER CNT(*)

      INTEGER J,CONDNO,E1,E2,PARENT,BRANCH
      DOUBLE PRECISION G0,KDIR0,KDIR1,SCALE

      DO J=1,NGRCOND
         CONDNO=ICNDGR(1,J)
         E1=ICNDGR(2,J)
         E2=ICNDGR(3,J)
         PARENT=ICNDGR(4,J)
         BRANCH=0

         IF (CONDNO .LE. 0 .OR. CONDNO .GT. NOCON .OR.
     +       CONDNO .GT. MAXCOND) THEN
            CNT(4)=CNT(4)+1
            GOTO 100
         ENDIF
         IF (UPDATED(CONDNO)) THEN
            CNT(11)=CNT(11)+1
            GOTO 100
         ENDIF
         G0=DBLE(GG0(CONDNO))
         IF (G0 .EQ. 0.0D0) THEN
            CNT(3)=CNT(3)+1
            GOTO 100
         ENDIF
         IF (G0 .LT. 0.0D0 .AND. .NOT. FIXNEG) THEN
            CNT(3)=CNT(3)+1
            GOTO 100
         ENDIF
         IF (PARENT .LE. 0 .OR. PARENT .GT. MAXMODEL .OR.
     +       PARENT .GT. 50000) THEN
            CNT(4)=CNT(4)+1
            GOTO 100
         ENDIF
         IF (.NOT. ISCFRP(PARENT)) THEN
            CNT(6)=CNT(6)+1
            GOTO 100
         ENDIF

         IF (LCLS(J) .EQ. 1) THEN
            KDIR0=0.647249D0
            KDIR1=KZEL(PARENT)
         ELSE
            KDIR0=3.005125D0
            KDIR1=KXEL(PARENT)
         ENDIF
         IF (KDIR0 .LE. 1.0D-20 .OR. KDIR1 .LE. 1.0D-20) THEN
            CNT(7)=CNT(7)+1
            GOTO 100
         ENDIF
         SCALE=KDIR0/KDIR1
         GG(CONDNO)=REAL(G0*SCALE)
         UPDATED(CONDNO)=.TRUE.
         NMOD=NMOD+1
         CNT(2)=CNT(2)+1
         IF (G0 .LT. 0.0D0) CNT(8)=CNT(8)+1
         IF (LCLS(J) .EQ. 1) THEN
            CNT(9)=CNT(9)+1
         ELSE
            CNT(10)=CNT(10)+1
         ENDIF

  100    CONTINUE
      END DO

      RETURN
      END


C=======================================================================
C     ONE-TIME CLASSIFICATION OF THE CONDNOS2 MAP
C=======================================================================

      SUBROUTINE CFRP_CLASSIFY(NGRCOND,ICNDGR,GG0,NOCON,ISCFRP,
     +     ISBOUND,SEEN,LCLS,SAMPID,SAMPE1,SAMPE2,MAXSAMP,NSAMP,
     +     FIRSTHEX,NZOK,NAMB,NCHK1,NCHK2,NCHK3)

      IMPLICIT NONE

      INTEGER NGRCOND,NOCON,MAXSAMP,NSAMP,FIRSTHEX
      INTEGER NZOK,NAMB,NCHK1,NCHK2,NCHK3
      INTEGER ICNDGR(4,*)
      REAL GG0(*)
      LOGICAL ISCFRP(*),ISBOUND(*),SEEN(*)
      INTEGER LCLS(*)
      INTEGER SAMPID(*),SAMPE1(*),SAMPE2(*)

      INTEGER J,ID,E1,E2,PAR
      INTEGER NUNIQ,NDUP,NPOS,NNEG,NZERO,NINV
      INTEGER NBB,NCE,NOTH,NPCF,NZL,NIP

      NUNIQ=0
      NDUP=0
      NPOS=0
      NNEG=0
      NZERO=0
      NINV=0
      NBB=0
      NCE=0
      NOTH=0
      NPCF=0
      NZL=0
      NIP=0
      NSAMP=0

      DO J=1,NGRCOND
         ID=ICNDGR(1,J)
         E1=ICNDGR(2,J)
         E2=ICNDGR(3,J)
         PAR=ICNDGR(4,J)
         IF (ID .LE. 0 .OR. ID .GT. NOCON .OR. E1 .LE. 0 .OR.
     +       E2 .LE. 0 .OR. E1 .GT. 50000 .OR. E2 .GT. 50000) THEN
            NINV=NINV+1
            GOTO 100
         ENDIF
         IF (SEEN(ID)) THEN
            NDUP=NDUP+1
         ELSE
            SEEN(ID)=.TRUE.
            NUNIQ=NUNIQ+1
         ENDIF
         IF (GG0(ID) .GT. 0.0) THEN
            NPOS=NPOS+1
         ELSE IF (GG0(ID) .LT. 0.0) THEN
            NNEG=NNEG+1
         ELSE
            NZERO=NZERO+1
         ENDIF
         IF (ISCFRP(E1) .OR. ISCFRP(E2)) THEN
            NCE=NCE+1
         ELSE IF (ISBOUND(E1) .AND. ISBOUND(E2)) THEN
            NBB=NBB+1
         ELSE
            NOTH=NOTH+1
         ENDIF
         IF (PAR .GT. 0 .AND. PAR .LE. 50000) THEN
            IF (ISCFRP(PAR)) NPCF=NPCF+1
         ENDIF
         IF (LCLS(J) .EQ. 1) THEN
            NZL=NZL+1
         ELSE
            NIP=NIP+1
         ENDIF
         IF (PAR .EQ. FIRSTHEX .AND. NSAMP .LT. MAXSAMP) THEN
            NSAMP=NSAMP+1
            SAMPID(NSAMP)=ID
            SAMPE1(NSAMP)=E1
            SAMPE2(NSAMP)=E2
         ENDIF
  100    CONTINUE
      END DO

      PRINT *,' '
      PRINT *,'=== CONDNOS2 MAP CLASSIFICATION ==='
      PRINT *,' entries in map            = ',NGRCOND
      PRINT *,' unique conductance ids    = ',NUNIQ
      PRINT *,' duplicate ids in map      = ',NDUP
      PRINT *,' invalid entries           = ',NINV
      PRINT *,' GG0 > 0 / < 0 / = 0       = ',NPOS,NNEG,NZERO
      PRINT *,' one end is a CFRP CG      = ',NCE
      PRINT *,' both ends boundary elem.  = ',NBB
      PRINT *,' other                     = ',NOTH
      PRINT *,' parent element is CFRP    = ',NPCF
      PRINT *,' kz (top<->bottom) links   = ',NZL
      PRINT *,' in-plane links            = ',NIP
      PRINT *,' hexes with a clear kz link= ',NZOK,
     +        '  ambiguous = ',NAMB
      PRINT *,' topology cross-check of kz faces: ok/bad/outer = ',
     +        NCHK1,NCHK2,NCHK3
      PRINT *,' sample links (parent ',FIRSTHEX,') = ',NSAMP
      PRINT *,'====================================='
      PRINT *,' '

      RETURN
      END


C=======================================================================
C     LINK AUDIT TABLE (sample links of the first hexahedron)
C=======================================================================

      SUBROUTINE CFRP_SAMPLES(TIME,NSAMP,SAMPID,SAMPE1,SAMPE2,GG,GG0,
     +     ICONV)

      IMPLICIT NONE

      DOUBLE PRECISION TIME
      INTEGER NSAMP
      INTEGER SAMPID(*),SAMPE1(*),SAMPE2(*)
      REAL GG(*),GG0(*)
      INTEGER ICONV(*)
      INTEGER J
      REAL RATIO

      IF (NSAMP .LE. 0) RETURN
      PRINT *,' '
      PRINT *,' LINK AUDIT t=',TIME,
     +        ' (id, ext labels, GG0, GG, GG/GG0)'
      DO J=1,NSAMP
         RATIO=0.0
         IF (GG0(SAMPID(J)) .NE. 0.0) RATIO=GG(SAMPID(J))/
     +                                      GG0(SAMPID(J))
         PRINT *,'   id',SAMPID(J),' ext',ICONV(SAMPE1(J)),
     +           ICONV(SAMPE2(J)),' GG0=',GG0(SAMPID(J)),
     +           ' GG=',GG(SAMPID(J)),' ratio=',RATIO
      END DO
      PRINT *,' '

      RETURN
      END


C=======================================================================
C     THROUGH-THICKNESS TEMPERATURE PRINTOUT (CG temperatures of one
C     column of CFRP elements, sorted by z)
C=======================================================================

      SUBROUTINE CFRP_PROFILE(TIME,T,NCOL,COLN,COLZ,PROBE,ICONV)

      IMPLICIT NONE

      DOUBLE PRECISION TIME
      DOUBLE PRECISION T(*)
      INTEGER NCOL
      INTEGER COLN(*)
      DOUBLE PRECISION COLZ(*)
      DOUBLE PRECISION PROBE
      INTEGER ICONV(*)

      INTEGER I
      DOUBLE PRECISION DZ
      DOUBLE PRECISION ZTOP
      DOUBLE PRECISION ZBOT
      DOUBLE PRECISION D1
      DOUBLE PRECISION D2
      DOUBLE PRECISION W
      DOUBLE PRECISION TTOP
      DOUBLE PRECISION TBOT
      LOGICAL FTOP
      LOGICAL FBOT

      PRINT *,' '
      PRINT *,' CFRP PROFILE t=',TIME,' (z[m], T[C], low z first)'
      DO I=1,NCOL
         PRINT *,'    layer',I,' ext',ICONV(COLN(I)),' z=',COLZ(I),
     +           ' T=',T(COLN(I))
      END DO

      IF (NCOL .GT. 1) THEN
         DZ=(COLZ(NCOL)-COLZ(1))/DBLE(NCOL-1)
         ZTOP=COLZ(NCOL)+0.5D0*DZ
         ZBOT=COLZ(1)-0.5D0*DZ
         FTOP=.FALSE.
         FBOT=.FALSE.
         TTOP=0.0D0
         TBOT=0.0D0
         DO I=NCOL,2,-1
            D1=ZTOP-COLZ(I)
            D2=ZTOP-COLZ(I-1)
            IF (.NOT. FTOP .AND. PROBE .GE. D1 .AND. PROBE .LE. D2) THEN
               W=(PROBE-D1)/(D2-D1)
               TTOP=T(COLN(I))+W*(T(COLN(I-1))-T(COLN(I)))
               FTOP=.TRUE.
            ENDIF
         END DO
         DO I=1,NCOL-1
            D1=COLZ(I)-ZBOT
            D2=COLZ(I+1)-ZBOT
            IF (.NOT. FBOT .AND. PROBE .GE. D1 .AND. PROBE .LE. D2) THEN
               W=(PROBE-D1)/(D2-D1)
               TBOT=T(COLN(I))+W*(T(COLN(I+1))-T(COLN(I)))
               FBOT=.TRUE.
            ENDIF
         END DO
         PRINT *,'    layer thickness =',DZ
         IF (TIME .GT. 1.0D0) THEN
            IF (T(COLN(NCOL)) .GT. T(COLN(1))) THEN
               PRINT *,'    exposed (hotter) face = HIGH-z'
               IF (FTOP) PRINT *,'    >>> T at depth',PROBE,
     +            ' from the EXPOSED face =',TTOP
            ELSE
               PRINT *,'    exposed (hotter) face = LOW-z'
               IF (FBOT) PRINT *,'    >>> T at depth',PROBE,
     +            ' from the EXPOSED face =',TBOT
            ENDIF
         ENDIF
         IF (FTOP) THEN
            PRINT *,'    T at depth',PROBE,' from the HIGH-z face =',
     +              TTOP
         ENDIF
         IF (FBOT) THEN
            PRINT *,'    T at depth',PROBE,' from the LOW-z  face =',
     +              TBOT
         ENDIF
      ENDIF
      PRINT *,' '

      RETURN
      END


C=======================================================================
C     ONE-TIME STRUCTURE DUMP OF ONE HEXAHEDRON (diagnostic only)
C=======================================================================

      SUBROUTINE CFRP_DUMP(N,NGRCOND,ICNDGR,ICONV,ELGEOM,ELPROP,C,GG0,
     +     LCLS,ZF1,ZF2)

      IMPLICIT NONE

      INTEGER N,NGRCOND
      INTEGER ICNDGR(4,*)
      INTEGER ICONV(*)
      REAL ELGEOM(3,4,*)
      REAL ELPROP(10,*)
      REAL C(*)
      REAL GG0(*)
      INTEGER LCLS(*)
      INTEGER ZF1(*),ZF2(*)

      INTEGER MAXBOUND
      INTEGER MAXCND
      PARAMETER (MAXBOUND=100)
      PARAMETER (MAXCND=100)
      INTEGER ICND(4,MAXCND)
      INTEGER BELLIST(MAXBOUND)
      INTEGER NC,NUMBEL,B,BINT,J,K,NL

      NC=0
      NUMBEL=0
      CALL CONDNOS(N,ICND,NC,BELLIST,NUMBEL)

      PRINT *,' '
      PRINT *,'=== CFRP STRUCTURE DUMP: internal element ',N,
     +        ' external ',ICONV(N)
      PRINT *,' CG centroid  = ',(ELGEOM(K,1,N),K=1,3)
      PRINT *,' volume ELPROP(1,hex) = ',ELPROP(1,N),
     +        '  C(CG) = ',C(N)
      PRINT *,' boundary elements (CONDNOS) = ',NUMBEL
      DO B=1,NUMBEL
         BINT=BELLIST(B)
         IF (BINT .GT. 0) THEN
            PRINT *,'   bel',B,' int',BINT,' ext',ICONV(BINT),
     +              ' ELPROP(1)=',ELPROP(1,BINT),' C(bel)=',C(BINT)
            PRINT *,'        centroid',(ELGEOM(K,1,BINT),K=1,3)
         ENDIF
      END DO
      PRINT *,' kz-link faces (int) = ',ZF1(N),ZF2(N)
      NL=0
      DO J=1,NGRCOND
         IF (ICNDGR(4,J) .EQ. N .AND. NL .LT. 20) THEN
            NL=NL+1
            PRINT *,'   link id',ICNDGR(1,J),' ext',ICONV(ICNDGR(2,J)),
     +              ICONV(ICNDGR(3,J)),' GG0=',GG0(ICNDGR(1,J)),
     +              ' class=',LCLS(J)
         ENDIF
      END DO
      PRINT *,'=== END STRUCTURE DUMP'
      PRINT *,' '

      RETURN
      END
