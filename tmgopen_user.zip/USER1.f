C=======================================================================
C  USER1.f
C
C  Simcenter NX 11 / TMG  (Intel Fortran 16, fixed form, /f77rtl)
C  T700/M21 CFRP thermochemical decomposition coupling
C
C  Sources: Tranchard et al., Materials 2017, 10, 494 (Part I:
C  Tables 3 and 5, Eqs. 4-8) and Materials 2017, 10, 470 (Part II:
C  Table 1, Eqs. 5-8).
C
C  Kinetics (competitive nth-order + autocatalytic):
C    da1/dt = A1*rem**n1*exp(-Ea1/RT)
C    da2/dt = A2*rem**n2*exp(-Ea2/RT)*(1+Kcat*a2)
C    rem    = 1 - a1 - a2
C    alpha  = F1*a1 + F2*a2 = (rhov-rho)/(rhov-rhoe)
C    rho    = rhov - F1*drho*a1 - F2*drho*a2,  drho = rhov-rhoe
C
C  Energy source added to each CFRP element (Part II Eq. 6, term III):
C    q = sum_i Qdi*drho_i*rate_i  +  (hs - hg)*(-d rho/dt)   [W/m3]
C    positive q = heat INTO the solid.  Qd1=+259.54 kJ/kg is
C    EXOTHERMIC and Qd2=-152.22 kJ/kg is ENDOTHERMIC (Part I,
C    Sec. 4.3).  hg and hs are enthalpies relative to T0 = 30 C.
C
C  NOT in this routine (needs TMG boundary conditions / fluid terms):
C    - advective gas term  -m'g.grad(hg)           (Part II Eq. 6 IV)
C    - surface out-gassing and AEHC flux           (Part II Eq. 9)
C
C  State per element (USER_QUANTITY):
C    CFRP_A1/A2    current-level a1,a2 (read by conductance update)
C    CFRP_A1P/A2P  last committed time level a1,a2
C    CFRP_TCUR     time of current-level state
C    CFRP_TPRV     time of committed state
C    CFRP_QDEC     decomposition heat source, W/m3
C    CFRP_C0       original capacitance
C
C  Time handling: TIME is the level being solved.  A new level commits
C  the previous state.  Every call re-integrates from the committed
C  state to TIME with the latest temperature (ITERUPD), so iterations
C  and step retries are handled without drift.
C
C  Assumptions: SI model, Celsius, CFRP group "Plate_3D".
C=======================================================================

      SUBROUTINE USER1(GG,T,C,Q,QD,R,TIME,DT,IT,KODE,NOCON,MAXNO,
     + ICONV,DUM1,DUM2,DTP,TF)

      IMPLICIT NONE

C----- USER1 arguments
      DOUBLE PRECISION T(*),TIME,DT
      REAL GG(*),C(*),Q(*),QD(*),R(*)
      REAL DUM1,DUM2,DTP,TF
      INTEGER IT,KODE,NOCON,MAXNO,ICONV(*)

C----- TMG common blocks
      REAL TDMAX,PRTFLG,PARAMS(8000),GRAV,GV(3),TABS,RGAS
      REAL PSTD,TSTD,SIGMA
      INTEGER IRUN,IR(1),MAXN1,MAXN2

      COMMON/TDMAX/TDMAX
      COMMON/PRTFLG/PRTFLG
      COMMON/IRUN/IRUN,IR
      COMMON/MAXNOQ/MAXN1,MAXN2
      COMMON/PARAMS/PARAMS
      COMMON/GRAV/GRAV,GV,TABS,RGAS,PSTD,TSTD,SIGMA

      SAVE

C----- Array limits
      INTEGER MAXELEM,MAXGROUP,MAXNODE,MAXCOND
      PARAMETER (MAXELEM=25000)
      PARAMETER (MAXGROUP=5000)
      PARAMETER (MAXNODE=10000)
      PARAMETER (MAXCOND=64)

C----- Element data from READPROP2 and CFRP group
      REAL PROP(10,MAXELEM)
      REAL GEOM(3,4,MAXELEM)
      REAL NODELIST(3,MAXNODE)
      INTEGER NODES(8,MAXELEM)
      INTEGER GNUMELEM
      INTEGER GLIST(MAXGROUP)
      COMMON/CFRPDATA/PROP,GEOM,NODELIST,NODES,GLIST,GNUMELEM

      INTEGER GID,GLENGTH
      CHARACTER*7 SNAME

C----- Initialization
      LOGICAL FIRSTTIME
      DATA FIRSTTIME/.TRUE./

      INTEGER ERRCNT,I,N
      LOGICAL CHECKUNITS

C----- State/property variables
      DOUBLE PRECISION A1C,A2C,A1P,A2P,TCUR,TPRV
      DOUBLE PRECISION ALPHA,RHO,CP
      DOUBLE PRECISION R1AVG,R2AVG,QDEC
      DOUBLE PRECISION TCE,STEPDT,TLOCALK
      DOUBLE PRECISION INITFLAG,C0VAL,VOL
      INTEGER IERR
      LOGICAL DOADV,NEWLVL
      DOUBLE PRECISION CFRP_CP,CFRP_CPV,CFRP_ALPHA,CFRP_RHO

C----- Density limits (Part I Table 5) and tolerances
      DOUBLE PRECISION RHOV
      PARAMETER (RHOV=1575.0D0)

      DOUBLE PRECISION TIME_EPS
      PARAMETER (TIME_EPS=1.0D-10)

C----- .TRUE. : re-integrate every call with the latest temperature
C      .FALSE.: advance once per new time level only
      LOGICAL ITERUPD
      PARAMETER (ITERUPD=.TRUE.)

C=======================================================================
C  FIRST-TIME INITIALIZATION
C=======================================================================
      IF (FIRSTTIME) THEN

         ERRCNT=0

         IF (CHECKUNITS()) THEN
            PRINT *,'*** FATAL: USER1 requires SI units ***'
            ERRCNT=ERRCNT+1
         ENDIF

         IF (MAXNO.GT.MAXELEM) THEN
            PRINT *,'*** FATAL: MAXNO exceeds USER1 MAXELEM ***'
            PRINT *,' MAXNO = ',MAXNO
            ERRCNT=ERRCNT+1
         ENDIF

         CALL LONGNAME(SNAME,'Plate_3D',GID,GLENGTH,2)
         CALL NAMAR(SNAME,GLIST,GNUMELEM)

         IF (GNUMELEM.GT.MAXGROUP) THEN
            PRINT *,'*** FATAL: Plate_3D group too large ***'
            ERRCNT=ERRCNT+1
         ENDIF

         CALL READPROP2(PROP,GEOM,NODES,NODELIST,
     +                  'Y','Y','Y','Y')

         PRINT *,'=============================================='
         PRINT *,' CFRP USER1 THERMOCHEMICAL MODEL ACTIVE'
         PRINT *,' Plate_3D elements = ',GNUMELEM
         PRINT *,' MAXNO             = ',MAXNO
         PRINT *,' First call TIME   = ',TIME
         PRINT *,' First call DT     = ',DT
         PRINT *,'=============================================='

         FIRSTTIME=.FALSE.

         IF (ERRCNT.GT.0) STOP

      ENDIF

C=======================================================================
C  MAIN COUPLING
C=======================================================================
      IF (KODE.EQ.1) THEN

         DO I=1,GNUMELEM

            N=GLIST(I)
            TCE=T(ICONV(N))
            NEWLVL=.FALSE.

C----------- First visit of this element?
            INITFLAG=0.0D0
            CALL USER_QUANTITY('GET','CFRP_INIT',N,INITFLAG,IERR)

            IF (IERR.NE.0) THEN

               A1C=0.0D0
               A2C=0.0D0
               A1P=0.0D0
               A2P=0.0D0
               TPRV=MAX(0.0D0,TIME-DT)
               TCUR=TPRV
               QDEC=0.0D0

               C0VAL=DBLE(C(N))
               CALL USER_QUANTITY('SET','CFRP_C0',N,C0VAL,IERR)
               INITFLAG=1.0D0
               CALL USER_QUANTITY('SET','CFRP_INIT',N,INITFLAG,IERR)

            ELSE

               CALL USER_QUANTITY('GET','CFRP_A1',N,A1C,IERR)
               CALL USER_QUANTITY('GET','CFRP_A2',N,A2C,IERR)
               CALL USER_QUANTITY('GET','CFRP_A1P',N,A1P,IERR)
               CALL USER_QUANTITY('GET','CFRP_A2P',N,A2P,IERR)
               CALL USER_QUANTITY('GET','CFRP_TCUR',N,TCUR,IERR)
               CALL USER_QUANTITY('GET','CFRP_TPRV',N,TPRV,IERR)
               CALL USER_QUANTITY('GET','CFRP_QDEC',N,QDEC,IERR)

            ENDIF

C----------- Decide whether to integrate.
            IF (TIME.GT.TCUR+TIME_EPS) THEN
C              New time level: commit the previous state.
               A1P=A1C
               A2P=A2C
               TPRV=TCUR
               DOADV=.TRUE.
               NEWLVL=.TRUE.
            ELSEIF (TIME.LT.TCUR-TIME_EPS) THEN
C              Time moved backwards (step retry): recompute.
               DOADV=.TRUE.
            ELSE
C              Same level (iteration).
               DOADV=ITERUPD
            ENDIF

            IF (DOADV) THEN

               STEPDT=TIME-TPRV

               IF (STEPDT.GT.0.0D0) THEN

                  TLOCALK=MAX(1.0D0,TCE+273.15D0)

                  CALL CFRP_RK4(TLOCALK,STEPDT,A1P,A2P,A1C,A2C)

                  R1AVG=MAX(0.0D0,(A1C-A1P)/STEPDT)
                  R2AVG=MAX(0.0D0,(A2C-A2P)/STEPDT)

                  ALPHA=CFRP_ALPHA(A1C,A2C)
                  CALL CFRP_QDECOMP(TCE,ALPHA,R1AVG,R2AVG,QDEC)

               ELSE

                  A1C=A1P
                  A2C=A2P
                  QDEC=0.0D0

               ENDIF

               TCUR=TIME

            ENDIF

            CALL USER_QUANTITY('SET','CFRP_A1',N,A1C,IERR)
            CALL USER_QUANTITY('SET','CFRP_A2',N,A2C,IERR)
            CALL USER_QUANTITY('SET','CFRP_A1P',N,A1P,IERR)
            CALL USER_QUANTITY('SET','CFRP_A2P',N,A2P,IERR)
            CALL USER_QUANTITY('SET','CFRP_TCUR',N,TCUR,IERR)
            CALL USER_QUANTITY('SET','CFRP_TPRV',N,TPRV,IERR)
            CALL USER_QUANTITY('SET','CFRP_QDEC',N,QDEC,IERR)

C----------- Current properties
            ALPHA=CFRP_ALPHA(A1C,A2C)
            RHO=CFRP_RHO(A1C,A2C)
            CP=CFRP_CP(TCE,ALPHA)

C----------- Diagnostic for the first CFRP element, once per level.
            IF (NEWLVL .AND. N.EQ.GLIST(1)) THEN
               PRINT *,'-----------------------------------'
               PRINT *,'CFRP DIAG TIME = ',TIME
               PRINT *,'  step dt      = ',TIME-TPRV
               PRINT *,'  T (C)        = ',TCE
               PRINT *,'  A1, A2       = ',A1C,A2C
               PRINT *,'  ALPHA, RHO   = ',ALPHA,RHO
               PRINT *,'  CP           = ',CP
               PRINT *,'  QDEC (W/m3)  = ',QDEC
               PRINT *,'-----------------------------------'
            ENDIF

C----------- qdec is W/m^3; TMG Q is total W for the element.
            VOL=DBLE(PROP(1,N))
            Q(N)=REAL(QDEC*VOL)

C----------- Scale total capacitance from the virgin 30 C state.
            CALL USER_QUANTITY('GET','CFRP_C0',N,C0VAL,IERR)

            IF (C0VAL.GT.0.0D0) THEN
               C(N)=REAL(C0VAL*(RHO*CP)/
     +                  (RHOV*CFRP_CPV(30.0D0)))
            ENDIF

         END DO

C        Conductance-network update.
         CALL CFRP_UPDATE_CONDUCTANCES(GG,T,R,Q,NOCON,MAXNO,ICONV)

      ENDIF

      RETURN
      END

C=======================================================================
C  Decomposition degree and density (single source of truth).
C  Part II Eq. 5 and Table 1.
C=======================================================================
      DOUBLE PRECISION FUNCTION CFRP_ALPHA(A1,A2)

      IMPLICIT NONE
      DOUBLE PRECISION A1,A2

      CFRP_ALPHA=0.5540D0*A1+0.9479D0*A2
      CFRP_ALPHA=MAX(0.0D0,MIN(1.0D0,CFRP_ALPHA))

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_RHO(A1,A2)

      IMPLICIT NONE
      DOUBLE PRECISION A1,A2

C     rhov = 1575, rhoe = 1165 kg/m3 (Part I, Table 5)
      CFRP_RHO=1575.0D0-0.5540D0*410.0D0*A1-0.9479D0*410.0D0*A2
      CFRP_RHO=MAX(1165.0D0,MIN(1575.0D0,CFRP_RHO))

      RETURN
      END

C=======================================================================
C  RK4 at fixed temperature over one coupling interval, with
C  substeps (the autocatalytic step is stiff at high temperature).
C  Constants: Part I Table 3 (log A, Ea, n, fraction, log Kcat).
C=======================================================================
      SUBROUTINE CFRP_RK4(TK,DTIN,A1,A2,A1OUT,A2OUT)

      IMPLICIT NONE

      DOUBLE PRECISION TK,DTIN,A1,A2,A1OUT,A2OUT

      DOUBLE PRECISION HMAX
      PARAMETER (HMAX=0.05D0)
      INTEGER NSUBMAX
      PARAMETER (NSUBMAX=4000)

      INTEGER NSUB,ISUB
      DOUBLE PRECISION H,B1,B2,X1
      DOUBLE PRECISION K1A,K1B,K2A,K2B,K3A,K3B,K4A,K4B
      DOUBLE PRECISION RG,AK1,AK2,PRE1,PRE2,KCAT,E1,E2
      LOGICAL KINIT
      DATA KINIT/.TRUE./
      SAVE

      IF (KINIT) THEN
         PRE1=10.0D0**0.8585D0
         PRE2=10.0D0**8.7268D0
         KCAT=10.0D0**0.8744D0
         E1=58.7107D3
         E2=146.6740D3
         RG=8.31446261815324D0
         KINIT=.FALSE.
      ENDIF

      AK1=PRE1*EXP(-E1/(RG*MAX(1.0D0,TK)))
      AK2=PRE2*EXP(-E2/(RG*MAX(1.0D0,TK)))

      A1OUT=A1
      A2OUT=A2

C     Skip cold elements: total change over the interval is negligible.
      IF ((AK1+AK2*(1.0D0+KCAT))*DTIN.LT.1.0D-12) RETURN

      NSUB=MIN(NSUBMAX,INT(DTIN/HMAX)+1)
      H=DTIN/DBLE(NSUB)

      B1=A1
      B2=A2

      DO ISUB=1,NSUB

         CALL CFRP_RHS(AK1,AK2,KCAT,B1,B2,K1A,K1B)

         CALL CFRP_RHS(AK1,AK2,KCAT,
     +                 B1+0.5D0*H*K1A,
     +                 B2+0.5D0*H*K1B,
     +                 K2A,K2B)

         CALL CFRP_RHS(AK1,AK2,KCAT,
     +                 B1+0.5D0*H*K2A,
     +                 B2+0.5D0*H*K2B,
     +                 K3A,K3B)

         CALL CFRP_RHS(AK1,AK2,KCAT,
     +                 B1+H*K3A,
     +                 B2+H*K3B,
     +                 K4A,K4B)

         B1=B1+(H/6.0D0)*(K1A+2.0D0*K2A+2.0D0*K3A+K4A)
         B2=B2+(H/6.0D0)*(K1B+2.0D0*K2B+2.0D0*K3B+K4B)

         B1=MAX(0.0D0,MIN(1.0D0,B1))
         B2=MAX(0.0D0,MIN(1.0D0,B2))

C        Keep a1+a2 <= 1 by proportional scaling.
         X1=B1+B2
         IF (X1.GT.1.0D0) THEN
            B1=B1/X1
            B2=B2/X1
         ENDIF

      END DO

      A1OUT=B1
      A2OUT=B2

      RETURN
      END

C=======================================================================
C  Kinetic right-hand side with precomputed Arrhenius rate constants.
C  Part II Table 1.
C=======================================================================
      SUBROUTINE CFRP_RHS(AK1,AK2,KCAT,A1,A2,R1,R2)

      IMPLICIT NONE

      DOUBLE PRECISION AK1,AK2,KCAT,A1,A2,R1,R2
      DOUBLE PRECISION REM

      REM=1.0D0-A1-A2
      REM=MAX(0.0D0,MIN(1.0D0,REM))

      IF (REM.LE.0.0D0) THEN
         R1=0.0D0
         R2=0.0D0
         RETURN
      ENDIF

      R1=AK1*REM**1.1125D0
      R2=AK2*REM**2.0825D0*(1.0D0+KCAT*A2)

      RETURN
      END

C=======================================================================
C  Specific heats (Part I Table 5, T in Celsius).
C  Virgin Cp is a linear fit.  The paper gives its range as 20-200 C
C  (text) and 20-300 C (Table 5); it is held constant above TCL.
C=======================================================================
      DOUBLE PRECISION FUNCTION CFRP_CPV(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,TCC,TCL
      PARAMETER (TCL=200.0D0)

      TCC=MIN(TC,TCL)

      CFRP_CPV=2.8773D0*TCC+687.31D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_CPE(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC

      CFRP_CPE=5.1327D-7*TC**3
     +         -2.0761D-3*TC**2
     +         +2.599D0*TC
     +         +662.53D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_CP(TC,ALPHA)

      IMPLICIT NONE
      DOUBLE PRECISION TC,ALPHA,CV,CE
      DOUBLE PRECISION CFRP_CPV,CFRP_CPE

      CV=CFRP_CPV(TC)
      CE=CFRP_CPE(TC)

      CFRP_CP=(1.0D0-ALPHA)*CV+ALPHA*CE

      RETURN
      END

C=======================================================================
C  Enthalpies relative to T0 = 30 C (integrals of Cp), J/kg.
C  Part II Eqs. 7 and 8 (without the Qd term, added in QDECOMP).
C=======================================================================
      DOUBLE PRECISION FUNCTION CFRP_HG(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,T0,F1,F0
      PARAMETER (T0=30.0D0)

C     Gas Cp = 3.5977e-7 T^3 - 9.2485e-4 T^2 + 1.0610 T + 1256.6
      F1=(3.5977D-7/4.0D0)*TC**4
     +  -(9.2485D-4/3.0D0)*TC**3
     +  +(1.0610D0/2.0D0)*TC**2
     +  +1256.6D0*TC

      F0=(3.5977D-7/4.0D0)*T0**4
     +  -(9.2485D-4/3.0D0)*T0**3
     +  +(1.0610D0/2.0D0)*T0**2
     +  +1256.6D0*T0

      CFRP_HG=F1-F0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_HSV(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,T0,TCL,TCC
      DOUBLE PRECISION CFRP_CPV
      PARAMETER (T0=30.0D0)
      PARAMETER (TCL=200.0D0)

      TCC=MIN(TC,TCL)

      CFRP_HSV=(2.8773D0/2.0D0)*(TCC**2-T0**2)
     +        +687.31D0*(TCC-T0)

      IF (TC.GT.TCL) THEN
         CFRP_HSV=CFRP_HSV+CFRP_CPV(TCL)*(TC-TCL)
      ENDIF

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_HSE(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,T0,F1,F0
      PARAMETER (T0=30.0D0)

      F1=(5.1327D-7/4.0D0)*TC**4
     +  -(2.0761D-3/3.0D0)*TC**3
     +  +(2.599D0/2.0D0)*TC**2
     +  +662.53D0*TC

      F0=(5.1327D-7/4.0D0)*T0**4
     +  -(2.0761D-3/3.0D0)*T0**3
     +  +(2.599D0/2.0D0)*T0**2
     +  +662.53D0*T0

      CFRP_HSE=F1-F0

      RETURN
      END

C=======================================================================
C  Conductivity correlations (Part I Table 5, T in Celsius, W/m.K).
C  KV* are valid 20-150 C and are held constant above.
C=======================================================================
      DOUBLE PRECISION FUNCTION CFRP_KVXY(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,TCC

      TCC=MIN(TC,150.0D0)

      CFRP_KVXY=7.4675D-3*TCC+2.7811D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_KVZ(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,TCC

      TCC=MIN(TC,150.0D0)

      CFRP_KVZ=1.1113D-3*TCC+0.61391D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_KEXY(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC

      CFRP_KEXY=-3.5481D-6*TC**2
     +          +6.4898D-3*TC
     +          +2.3005D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_KEZ(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC

      CFRP_KEZ=7.4228D-10*TC**3
     +         -4.1903D-7*TC**2
     +         +2.3397D-4*TC
     +         +7.7211D-2

      RETURN
      END

C=======================================================================
C  Decomposition heat source, W/m3 (Part II Eq. 6, term III).
C
C    q = sum_i Qdi*drho_i*rate_i + (hs - hg)*rhodot
C
C  rhodot = -d(rho)/dt >= 0.  Positive q heats the solid.
C  HSOLID = .TRUE. follows the paper (h = Qd + int Cp dT).
C  HSOLID = .FALSE. drops the solid sensible term (older Python script).
C=======================================================================
      SUBROUTINE CFRP_QDECOMP(TC,ALPHA,R1,R2,QDEC)

      IMPLICIT NONE

      DOUBLE PRECISION TC,ALPHA,R1,R2,QDEC
      DOUBLE PRECISION QCHEM,RHOGDOT,HS,HG
      DOUBLE PRECISION CFRP_HG,CFRP_HSV,CFRP_HSE

      LOGICAL HSOLID
      PARAMETER (HSOLID=.TRUE.)

C     Qd1 = +259.54 kJ/kg (exothermic), Qd2 = -152.22 kJ/kg (endo)
      QCHEM=0.5540D0*259.54D3*410.0D0*R1
     +     +0.9479D0*(-152.22D3)*410.0D0*R2

      RHOGDOT=0.5540D0*410.0D0*R1
     +       +0.9479D0*410.0D0*R2

      HG=CFRP_HG(TC)

      IF (HSOLID) THEN
         HS=(1.0D0-ALPHA)*CFRP_HSV(TC)+ALPHA*CFRP_HSE(TC)
      ELSE
         HS=0.0D0
      ENDIF

      QDEC=QCHEM+RHOGDOT*(HS-HG)

      RETURN
      END

C=======================================================================
C  Conductance-network update.
C
C  Conductive:  k_eff = kx*lx^2 + ky*ly^2 + kz*lz^2 (centroid direction)
C               s     = k_eff / k_eff0   (k_eff0 = virgin at 30 C)
C  Radiative:   s     = eps(alpha) / eps_virgin  (Part II Eq. 10)
C
C  Conductance is proportional to s.  If GG holds the INVERSE
C  (resistance-like) quantity in this TMG build, set GGISRES=.TRUE.:
C  GG is then divided by s.  R (radiation parameter) is always
C  multiplied by s.  Scaling always starts from the stored base values.
C  Verify GGISRES once: print a CFRP-CFRP GG before/after.
C=======================================================================
      SUBROUTINE CFRP_UPDATE_CONDUCTANCES(GG,T,R,Q,NOCON,MAXNO,ICONV)

      IMPLICIT NONE

      REAL GG(*),R(*),Q(*)
      DOUBLE PRECISION T(*)
      INTEGER NOCON,MAXNO,ICONV(*)
      INTEGER KCONV,NOCOND

      INTEGER MAXELEM,MAXGROUP,MAXNODE,MAXCOND,MAXCG
      PARAMETER (MAXELEM=25000)
      PARAMETER (MAXGROUP=5000)
      PARAMETER (MAXNODE=10000)
      PARAMETER (MAXCOND=64)
      PARAMETER (MAXCG=30000)

      REAL PROP(10,MAXELEM)
      REAL GEOM(3,4,MAXELEM)
      REAL NODELIST(3,MAXNODE)
      INTEGER NODES(8,MAXELEM)
      INTEGER GNUMELEM
      INTEGER GLIST(MAXGROUP)
      COMMON/CFRPDATA/PROP,GEOM,NODELIST,NODES,GLIST,GNUMELEM

      INTEGER ICOND(4,MAXCOND)
      INTEGER BELLIST(MAXCOND)
      INTEGER NC,NUMBEL

      INTEGER I,J,K,N,CONDNO
      INTEGER E1,E2,I2
      INTEGER CFRPFLAG1,CFRPFLAG2
      INTEGER IERR

      DOUBLE PRECISION A1,A2,ALPHA1,ALPHA2
      DOUBLE PRECISION TC1,TC2
      DOUBLE PRECISION KX1,KY1,KZ1,KX2,KY2,KZ2
      DOUBLE PRECISION KEFF,KEFF0
      DOUBLE PRECISION DX,DY,DZ,DLEN,LX,LY,LZ
      DOUBLE PRECISION SDIR
      DOUBLE PRECISION EPSNEW,EPSBASE,EPSE

C     Emissivities are model assumptions (not given in the papers).
      PARAMETER (EPSBASE=0.85D0)
      PARAMETER (EPSE=0.95D0)

      LOGICAL GGISRES
      PARAMETER (GGISRES=.TRUE.)

      REAL GGB(MAXCG),RBASE(MAXCG)
      LOGICAL GGINIT
      DATA GGINIT/.TRUE./
      SAVE GGB,RBASE,GGINIT

      DOUBLE PRECISION CFRP_KVXY,CFRP_KVZ
      DOUBLE PRECISION CFRP_KEXY,CFRP_KEZ
      DOUBLE PRECISION CFRP_ALPHA

C----- Store the original TMG conductance data once.
      IF (GGINIT) THEN

         IF (NOCON.GT.MAXCG) THEN
            PRINT *,'*** FATAL: NOCON exceeds MAXCG ***'
            PRINT *,' NOCON = ',NOCON
            STOP
         ENDIF

         DO I=1,NOCON
            GGB(I)=GG(I)
            RBASE(I)=R(I)
         END DO

         GGINIT=.FALSE.

      ENDIF

C=======================================================================
C  Conductive connections
C=======================================================================
      DO I=1,GNUMELEM

         N=GLIST(I)

         CALL CONDNOS(N,ICOND,NC,BELLIST,NUMBEL)

         IF (NC.GT.MAXCOND) NC=MAXCOND

         DO J=1,NC

            CONDNO=ICOND(1,J)

            E1=KCONV(ICOND(2,J))
            E2=KCONV(ICOND(3,J))

            IF (E1.LE.0 .OR. E2.LE.0) GOTO 100

C----------- Process each shared connection once.
            IF (E1.GT.E2) GOTO 100
            IF (N.NE.E1) GOTO 100

            CFRPFLAG1=0
            CFRPFLAG2=0

            DO K=1,GNUMELEM
               IF (GLIST(K).EQ.E1) CFRPFLAG1=1
               IF (GLIST(K).EQ.E2) CFRPFLAG2=1
            END DO

            IF (CFRPFLAG1.EQ.0 .AND. CFRPFLAG2.EQ.0)
     +         GOTO 100

C----------- Endpoint 1 state.
            CALL USER_QUANTITY('GET','CFRP_A1',E1,A1,IERR)
            CALL USER_QUANTITY('GET','CFRP_A2',E1,A2,IERR)

            IF (IERR.NE.0) THEN
               A1=0.0D0
               A2=0.0D0
            ENDIF

            ALPHA1=CFRP_ALPHA(A1,A2)

            TC1=T(ICONV(E1))

            KX1=(1.0D0-ALPHA1)*CFRP_KVXY(TC1)
     +          +ALPHA1*CFRP_KEXY(TC1)
            KY1=KX1

            KZ1=(1.0D0-ALPHA1)*CFRP_KVZ(TC1)
     +          +ALPHA1*CFRP_KEZ(TC1)

C----------- Endpoint 2 state, otherwise use endpoint 1.
            IF (CFRPFLAG2.EQ.1) THEN

               CALL USER_QUANTITY('GET','CFRP_A1',E2,A1,IERR)
               CALL USER_QUANTITY('GET','CFRP_A2',E2,A2,IERR)

               IF (IERR.NE.0) THEN
                  A1=0.0D0
                  A2=0.0D0
               ENDIF

               ALPHA2=CFRP_ALPHA(A1,A2)

               TC2=T(ICONV(E2))

               KX2=(1.0D0-ALPHA2)*CFRP_KVXY(TC2)
     +             +ALPHA2*CFRP_KEXY(TC2)
               KY2=KX2

               KZ2=(1.0D0-ALPHA2)*CFRP_KVZ(TC2)
     +             +ALPHA2*CFRP_KEZ(TC2)

            ELSE

               KX2=KX1
               KY2=KY1
               KZ2=KZ1

            ENDIF

C----------- Direction between calculation centroids.
            DX=DBLE(GEOM(1,1,E2)-GEOM(1,1,E1))
            DY=DBLE(GEOM(2,1,E2)-GEOM(2,1,E1))
            DZ=DBLE(GEOM(3,1,E2)-GEOM(3,1,E1))

            DLEN=SQRT(DX*DX+DY*DY+DZ*DZ)

            IF (DLEN.GT.1.0D-20) THEN

               LX=DX/DLEN
               LY=DY/DLEN
               LZ=DZ/DLEN

               IF (CFRPFLAG2.EQ.1) THEN
                  KX1=0.5D0*(KX1+KX2)
                  KY1=0.5D0*(KY1+KY2)
                  KZ1=0.5D0*(KZ1+KZ2)
               ENDIF

               KEFF=KX1*LX*LX+KY1*LY*LY+KZ1*LZ*LZ

               KEFF0=CFRP_KVXY(30.0D0)*LX*LX
     +              +CFRP_KVXY(30.0D0)*LY*LY
     +              +CFRP_KVZ(30.0D0)*LZ*LZ

               IF (KEFF.GT.1.0D-20 .AND.
     +             KEFF0.GT.1.0D-20) THEN

                  SDIR=KEFF/KEFF0

                  IF (GGISRES) THEN
                     GG(CONDNO)=REAL(DBLE(GGB(CONDNO))/SDIR)
                  ELSE
                     GG(CONDNO)=REAL(DBLE(GGB(CONDNO))*SDIR)
                  ENDIF

               ENDIF

            ENDIF

  100       CONTINUE
         END DO

C=======================================================================
C  Radiation connected to boundary elements of this CFRP element.
C=======================================================================
         DO J=1,NUMBEL

            I2=BELLIST(J)

            IF (I2.LE.0) GOTO 200

            CONDNO=NOCOND(ICONV(N),ICONV(I2),1)

            IF (CONDNO.LE.0) THEN
               CONDNO=NOCOND(ICONV(N),ICONV(I2),6)
            ENDIF

            IF (CONDNO.GT.0 .AND. CONDNO.LE.NOCON) THEN

               CALL USER_QUANTITY('GET','CFRP_A1',N,A1,IERR)
               CALL USER_QUANTITY('GET','CFRP_A2',N,A2,IERR)

               IF (IERR.NE.0) THEN
                  A1=0.0D0
                  A2=0.0D0
               ENDIF

               ALPHA1=CFRP_ALPHA(A1,A2)

C              Part II Eq. 10: eps = (1-alpha)*eps_v + alpha*eps_e
               EPSNEW=(1.0D0-ALPHA1)*EPSBASE+ALPHA1*EPSE

               IF (EPSBASE.GT.1.0D-12) THEN

                  SDIR=EPSNEW/EPSBASE

                  IF (GGISRES) THEN
                     GG(CONDNO)=REAL(DBLE(GGB(CONDNO))/SDIR)
                  ELSE
                     GG(CONDNO)=REAL(DBLE(GGB(CONDNO))*SDIR)
                  ENDIF

                  R(CONDNO)=REAL(DBLE(RBASE(CONDNO))*SDIR)

               ENDIF

            ENDIF

  200       CONTINUE
         END DO

      END DO

      RETURN
      END

C=======================================================================
C  Unit checker. Correlations are SI / Celsius.
C=======================================================================
      LOGICAL FUNCTION CHECKUNITS()

      IMPLICIT NONE

      REAL U1,U2,U3,U4,U5,U6
      REAL TOL,X

      TOL=0.01

      CALL TUNITS(U1,U2,U3,U4,U5,U6)

C     U2 = model length units per metre
C     U3 = model force units per Newton
C     U4 = Celsius temperature scale
C     U5 = absolute zero in model temperature units (-273.15 for C)
C     U6 = seconds per model time unit

      CHECKUNITS=.FALSE.

      X=ABS(U2-1.0)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      X=ABS(U3-1.0)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      X=ABS(U4-1.0)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      X=ABS((U5+273.15)/273.15)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      X=ABS(U6-1.0)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      RETURN
      END
