C=======================================================================
C  USER1.f
C
C  Simcenter NX 11 / TMG
C  Native T700/M21 CFRP thermochemical coupling
C
C  This ports the kinetics/mathematics from the previously working
C  Python coupling script into native TMG USER1.
C
C  dA1/dt = A1 * remaining**n1 * exp(-Ea1/(R*T))
C  dA2/dt = A2 * remaining**n2 * exp(-Ea2/(R*T))
C           * (1 + KCAT2*A2)
C  remaining = 1 - A1 - A2
C
C  alpha = F1*A1 + F2*A2
C  rho   = RHO_V - F1*DRHO*A1 - F2*DRHO*A2
C
C  KODE=1:
C    1) advance kinetics once per TMG time level
C    2) update capacitance
C    3) re-apply decomposition heat load
C    4) update CG conductive conductances
C    5) update directly connected radiative conductances
C
C  USER_QUANTITY stores A1, A2, last time, Qdec and original C
C  so repeated USER1 calls at the same TIME do not advance chemistry.
C
C  Assumption: SI model and physical CFRP group name "Plate_3D".
C=======================================================================

      SUBROUTINE USER1(GG,T,C,Q,QD,R,TIME,DT,IT,KODE,NOCON,MAXNO,
     + ICONV,DUM1,DUM2,DTP,TF)

      IMPLICIT NONE

C----- USER1 arguments
      DOUBLE PRECISION T(*),TIME,DT
      REAL GG(*),C(*),Q(*),QD(*),R(*)
      REAL DUM1,DUM2,DTP,TF
      INTEGER IT,KODE,NOCON,MAXNO,ICONV(*)

C----- TMG common blocks
      REAL TDMAX,PRTFLG,PARAMS(8000),GRAV,GV(3),TABS,RGAS
      REAL PSTD,TSTD,SIGMA
      INTEGER IRUN,IR(1),MAXN1,MAXN2

      COMMON/TDMAX/TDMAX
      COMMON/PRTFLG/PRTFLG
      COMMON/IRUN/IRUN,IR
      COMMON/MAXNOQ/MAXN1,MAXN2
      COMMON/PARAMS/PARAMS
      COMMON/GRAV/GRAV,GV,TABS,RGAS,PSTD,TSTD,SIGMA

      SAVE

C----- Array limits
      INTEGER MAXELEM,MAXGROUP,MAXNODE,MAXCOND
      PARAMETER (MAXELEM=25000)
      PARAMETER (MAXGROUP=5000)
      PARAMETER (MAXNODE=10000)
      PARAMETER (MAXCOND=64)

C----- Element data from READPROP2 and CFRP group
      REAL PROP(10,MAXELEM)
      REAL GEOM(3,4,MAXELEM)
      REAL NODELIST(3,MAXNODE)
      INTEGER NODES(8,MAXELEM)
      INTEGER GNUMELEM
      INTEGER GLIST(MAXGROUP)
      COMMON/CFRPDATA/PROP,GEOM,NODELIST,NODES,GLIST,GNUMELEM

      INTEGER GID,GLENGTH
      CHARACTER*7 SNAME

C----- Initialization
      LOGICAL FIRSTTIME
      DATA FIRSTTIME/.TRUE./

      INTEGER ERRCNT,I,N
      LOGICAL CHECKUNITS

C----- State/property variables
      DOUBLE PRECISION A1OLD,A2OLD,A1NEW,A2NEW
      DOUBLE PRECISION ALPHA,RHO,CP
      DOUBLE PRECISION R1AVG,R2AVG,QDEC,QSTORE
      DOUBLE PRECISION TCE,STEPDT,TLOCALK,LASTTIME
      DOUBLE PRECISION INITFLAG,C0VAL,VOL
      INTEGER IERR
      DOUBLE PRECISION CFRP_CP,CFRP_CPV

C----- Constants: exact values from the working Python coupling script
      DOUBLE PRECISION RGAS_D
      DOUBLE PRECISION A1PAR,A2PAR,EA1PAR,EA2PAR
      DOUBLE PRECISION N1PAR,N2PAR,KCAT2PAR
      DOUBLE PRECISION F1PAR,F2PAR
      DOUBLE PRECISION Q1PAR,Q2PAR
      DOUBLE PRECISION RHOV,RHOE,DRHO
      DOUBLE PRECISION EPSV,EPSE

      PARAMETER (RGAS_D=8.31446261815324D0)
      PARAMETER (A1PAR=10.0D0**0.8585D0)
      PARAMETER (A2PAR=10.0D0**8.7268D0)
      PARAMETER (EA1PAR=58.7107D3)
      PARAMETER (EA2PAR=146.6740D3)
      PARAMETER (N1PAR=1.1125D0)
      PARAMETER (N2PAR=2.0825D0)
      PARAMETER (KCAT2PAR=10.0D0**0.8744D0)
      PARAMETER (F1PAR=0.5540D0)
      PARAMETER (F2PAR=0.9479D0)
      PARAMETER (Q1PAR=259.54D3)
      PARAMETER (Q2PAR=-152.22D3)
      PARAMETER (RHOV=1575.0D0)
      PARAMETER (RHOE=1165.0D0)
      PARAMETER (DRHO=410.0D0)
      PARAMETER (EPSV=0.85D0)
      PARAMETER (EPSE=0.95D0)

      DOUBLE PRECISION TIME_EPS
      PARAMETER (TIME_EPS=1.0D-10)

C=======================================================================
C  FIRST-TIME INITIALIZATION
C=======================================================================
      IF (FIRSTTIME) THEN

         ERRCNT=0

         IF (CHECKUNITS()) THEN
            PRINT *,'*** FATAL: USER1 requires SI units ***'
            ERRCNT=ERRCNT+1
         ENDIF

         IF (MAXNO.GT.MAXELEM) THEN
            PRINT *,'*** FATAL: MAXNO exceeds USER1 MAXELEM ***'
            PRINT *,' MAXNO = ',MAXNO
            ERRCNT=ERRCNT+1
         ENDIF

C        Physical CFRP group in the user's current XML/model.
         CALL LONGNAME(SNAME,'Plate_3D',GID,GLENGTH,2)
         CALL NAMAR(SNAME,GLIST,GNUMELEM)

         IF (GNUMELEM.GT.MAXGROUP) THEN
            PRINT *,'*** FATAL: Plate_3D group too large ***'
            ERRCNT=ERRCNT+1
         ENDIF

         CALL READPROP2(PROP,GEOM,NODES,NODELIST,
     +                  'Y','Y','Y','Y')

         PRINT *,'=============================================='
         PRINT *,' CFRP USER1 THERMOCHEMICAL MODEL ACTIVE'
         PRINT *,' Plate_3D elements = ',GNUMELEM
         PRINT *,' MAXNO             = ',MAXNO
         PRINT *,' Exact Python kinetics/math = ACTIVE'
         PRINT *,' Native continuous alpha = ACTIVE'
         PRINT *,'=============================================='

         FIRSTTIME=.FALSE.

         IF (ERRCNT.GT.0) STOP

      ENDIF

C=======================================================================
C  MAIN COUPLING
C=======================================================================
      IF (KODE.EQ.1) THEN

         DO I=1,GNUMELEM

            N=GLIST(I)

C----------- Is this the first visit of this element?
            INITFLAG=0.0D0
            CALL USER_QUANTITY('GET','CFRP_INIT',N,INITFLAG,IERR)

            IF (IERR.NE.0) THEN

               A1OLD=0.0D0
               A2OLD=0.0D0
               LASTTIME=TIME
               INITFLAG=1.0D0

               CALL USER_QUANTITY('SET','CFRP_A1',N,A1OLD,IERR)
               CALL USER_QUANTITY('SET','CFRP_A2',N,A2OLD,IERR)
               CALL USER_QUANTITY('SET','CFRP_LAST',N,LASTTIME,IERR)
               CALL USER_QUANTITY('SET','CFRP_QDEC',N,0.0D0,IERR)
               CALL USER_QUANTITY('SET','CFRP_C0',N,
     +                            DBLE(C(N)),IERR)
               CALL USER_QUANTITY('SET','CFRP_INIT',N,INITFLAG,IERR)

C-------------- First coupling interval: t=0 -> t=DT
               STEPDT=DT

               IF (STEPDT.GT.0.0D0) THEN

                  TLOCALK=MAX(1.0D0,T(N)+273.15D0)

                  CALL CFRP_RK4(TLOCALK,STEPDT,A1OLD,A2OLD,
     +                          A1NEW,A2NEW)

                  R1AVG=MAX(0.0D0,(A1NEW-A1OLD)/STEPDT)
                  R2AVG=MAX(0.0D0,(A2NEW-A2OLD)/STEPDT)

                  TCE=T(N)
                  CALL CFRP_QDECOMP(TCE,R1AVG,R2AVG,QDEC)

                  CALL USER_QUANTITY('SET','CFRP_A1',N,A1NEW,IERR)
                  CALL USER_QUANTITY('SET','CFRP_A2',N,A2NEW,IERR)
C                 Keep LAST at the TMG start time. The chemistry just
C                 advanced over this interval; the next TMG time level
C                 will then trigger exactly one more advance.
                  CALL USER_QUANTITY('SET','CFRP_LAST',N,
     +                               TIME,IERR)
                  CALL USER_QUANTITY('SET','CFRP_QDEC',N,QDEC,IERR)

               ENDIF

            ELSE

               CALL USER_QUANTITY('GET','CFRP_A1',N,A1OLD,IERR)
               CALL USER_QUANTITY('GET','CFRP_A2',N,A2OLD,IERR)
               CALL USER_QUANTITY('GET','CFRP_LAST',N,LASTTIME,IERR)
               CALL USER_QUANTITY('GET','CFRP_QDEC',N,QSTORE,IERR)

C-------------- Advance only when TMG reaches a new time level.
               IF (TIME.GT.LASTTIME+TIME_EPS) THEN

                  STEPDT=TIME-LASTTIME
                  IF (STEPDT.LE.0.0D0) STEPDT=DT

                  TLOCALK=MAX(1.0D0,T(N)+273.15D0)

                  CALL CFRP_RK4(TLOCALK,STEPDT,A1OLD,A2OLD,
     +                          A1NEW,A2NEW)

                  R1AVG=MAX(0.0D0,(A1NEW-A1OLD)/STEPDT)
                  R2AVG=MAX(0.0D0,(A2NEW-A2OLD)/STEPDT)

                  TCE=T(N)
                  CALL CFRP_QDECOMP(TCE,R1AVG,R2AVG,QDEC)

                  CALL USER_QUANTITY('SET','CFRP_A1',N,A1NEW,IERR)
                  CALL USER_QUANTITY('SET','CFRP_A2',N,A2NEW,IERR)
                  CALL USER_QUANTITY('SET','CFRP_LAST',N,TIME,IERR)
                  CALL USER_QUANTITY('SET','CFRP_QDEC',N,QDEC,IERR)

                  QSTORE=QDEC

               ENDIF

               QDEC=QSTORE

            ENDIF

C----------- Get current decomposition state.
            CALL USER_QUANTITY('GET','CFRP_A1',N,A1NEW,IERR)
            CALL USER_QUANTITY('GET','CFRP_A2',N,A2NEW,IERR)

C----------- Exact working-script alpha.
            ALPHA=F1PAR*A1NEW+F2PAR*A2NEW
            ALPHA=MAX(0.0D0,MIN(1.0D0,ALPHA))

C----------- Exact working-script density.
            RHO=RHOV-F1PAR*DRHO*A1NEW-F2PAR*DRHO*A2NEW
            RHO=MAX(RHOE,MIN(RHOV,RHO))

C----------- Exact working-script Cp.
            CP=CFRP_CP(T(N),ALPHA)

C----------- qdec is W/m^3; TMG Q is total W.
            VOL=DBLE(PROP(1,N))
            Q(N)=REAL(QDEC*VOL)

C----------- Scale total element capacitance from virgin 30 C state.
            CALL USER_QUANTITY('GET','CFRP_C0',N,C0VAL,IERR)

            IF (C0VAL.GT.0.0D0) THEN
               C(N)=REAL(C0VAL*(RHO*CP)/
     +                  (RHOV*CFRP_CPV(30.0D0)))
            ENDIF

         END DO

C        Conductance-network update.
         CALL CFRP_UPDATE_CONDUCTANCES(GG,T,R,Q,NOCON,MAXNO,ICONV)

      ENDIF

      RETURN
      END

C=======================================================================
C  RK4: fixed-temperature integration over the TMG coupling interval.
C=======================================================================
      SUBROUTINE CFRP_RK4(TK,DTIN,A1,A2,A1OUT,A2OUT)

      IMPLICIT NONE

      DOUBLE PRECISION TK,DTIN,A1,A2,A1OUT,A2OUT
      DOUBLE PRECISION H
      DOUBLE PRECISION K1A,K1B,K2A,K2B,K3A,K3B,K4A,K4B
      DOUBLE PRECISION X1

      H=DTIN

      CALL CFRP_RHS(TK,A1,A2,K1A,K1B)

      CALL CFRP_RHS(TK,
     +              A1+0.5D0*H*K1A,
     +              A2+0.5D0*H*K1B,
     +              K2A,K2B)

      CALL CFRP_RHS(TK,
     +              A1+0.5D0*H*K2A,
     +              A2+0.5D0*H*K2B,
     +              K3A,K3B)

      CALL CFRP_RHS(TK,
     +              A1+H*K3A,
     +              A2+H*K3B,
     +              K4A,K4B)

      A1OUT=A1+(H/6.0D0)*
     +       (K1A+2.0D0*K2A+2.0D0*K3A+K4A)

      A2OUT=A2+(H/6.0D0)*
     +       (K1B+2.0D0*K2B+2.0D0*K3B+K4B)

      A1OUT=MAX(0.0D0,MIN(1.0D0,A1OUT))
      A2OUT=MAX(0.0D0,MIN(1.0D0,A2OUT))

C----- Exact working-script constraint: if A1+A2 > 1,
C      scale both proportionally.
      X1=A1OUT+A2OUT

      IF (X1.GT.1.0D0) THEN
         A1OUT=A1OUT/X1
         A2OUT=A2OUT/X1
      ENDIF

      RETURN
      END

C=======================================================================
C  Exact working-script kinetic RHS.
C=======================================================================
      SUBROUTINE CFRP_RHS(TK,A1,A2,R1,R2)

      IMPLICIT NONE

      DOUBLE PRECISION TK,A1,A2,R1,R2
      DOUBLE PRECISION R,REMAINING,EX1,EX2

      R=8.31446261815324D0

      REMAINING=1.0D0-A1-A2
      REMAINING=MAX(0.0D0,MIN(1.0D0,REMAINING))

      IF (REMAINING.LE.0.0D0) THEN
         R1=0.0D0
         R2=0.0D0
         RETURN
      ENDIF

      EX1=-58.7107D3/(R*MAX(1.0D0,TK))
      EX2=-146.6740D3/(R*MAX(1.0D0,TK))

      R1=(10.0D0**0.8585D0)*
     +   REMAINING**1.1125D0*
     +   EXP(EX1)

      R2=(10.0D0**8.7268D0)*
     +   REMAINING**2.0825D0*
     +   EXP(EX2)*
     +   (1.0D0+(10.0D0**0.8744D0)*A2)

      RETURN
      END

C=======================================================================
C  Exact working-script Cp.
C=======================================================================
      DOUBLE PRECISION FUNCTION CFRP_CPV(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,TCC

      TCC=TC
      IF (TCC.GT.200.0D0) TCC=200.0D0

      CFRP_CPV=2.8773D0*TCC+687.31D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_CPE(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC

      CFRP_CPE=5.1327D-7*TC**3
     +         -2.0761D-3*TC**2
     +         +2.599D0*TC
     +         +662.53D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_CP(TC,ALPHA)

      IMPLICIT NONE
      DOUBLE PRECISION TC,ALPHA,CV,CE
      DOUBLE PRECISION CFRP_CPV,CFRP_CPE

      CV=CFRP_CPV(TC)
      CE=CFRP_CPE(TC)

      CFRP_CP=(1.0D0-ALPHA)*CV+ALPHA*CE

      RETURN
      END

C=======================================================================
C  Exact working-script conductivity correlations.
C=======================================================================
      DOUBLE PRECISION FUNCTION CFRP_KVXY(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,TCC

      TCC=TC
      IF (TCC.GT.150.0D0) TCC=150.0D0

      CFRP_KVXY=7.4675D-3*TCC+2.7811D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_KVZ(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC,TCC

      TCC=TC
      IF (TCC.GT.150.0D0) TCC=150.0D0

      CFRP_KVZ=1.1113D-3*TCC+0.61391D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_KEXY(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC

      CFRP_KEXY=-3.5481D-6*TC**2
     +          +6.4898D-3*TC
     +          +2.3005D0

      RETURN
      END

      DOUBLE PRECISION FUNCTION CFRP_KEZ(TC)

      IMPLICIT NONE
      DOUBLE PRECISION TC

      CFRP_KEZ=7.4228D-10*TC**3
     +         -4.1903D-7*TC**2
     +         +2.3397D-4*TC
     +         +7.7211D-2

      RETURN
      END

C=======================================================================
C  Exact working-script decomposition heat and gas enthalpy correction.
C=======================================================================
      SUBROUTINE CFRP_QDECOMP(TC,R1,R2,QDEC)

      IMPLICIT NONE

      DOUBLE PRECISION TC,R1,R2,QDEC
      DOUBLE PRECISION QCHEM,RHOGDOT,HNOW,H0,DELTAH

      QCHEM=0.5540D0*259.54D3*410.0D0*R1
     +      +0.9479D0*(-152.22D3)*410.0D0*R2

      RHOGDOT=0.5540D0*410.0D0*R1
     +        +0.9479D0*410.0D0*R2

      HNOW=(3.5977D-7/4.0D0)*TC**4
     +    -(9.2485D-4/3.0D0)*TC**3
     +    +(1.0610D0/2.0D0)*TC**2
     +    +1256.6D0*TC

      H0=(3.5977D-7/4.0D0)*30.0D0**4
     +  -(9.2485D-4/3.0D0)*30.0D0**3
     +  +(1.0610D0/2.0D0)*30.0D0**2
     +  +1256.6D0*30.0D0

      DELTAH=HNOW-H0

      QDEC=QCHEM-RHOGDOT*DELTAH

      RETURN
      END

C=======================================================================
C  Conductance-network update.
C
C  CONDNOS is used only for CG conductive conductances, as documented
C  by Maya HTT. The conductive scaling is:
C
C    k_eff  = kx*lx^2 + ky*ly^2 + kz*lz^2
C    GG_new = GG_current * k_eff0/k_eff
C
C  where k_eff0 is the virgin 30 C directional conductivity.
C
C  Radiation is adjusted for directly connected boundary conductances:
C
C    GG_new = GG_current * epsilon_virgin/epsilon_current
C
C  The original TMG geometry/network is therefore preserved.
C=======================================================================
      SUBROUTINE CFRP_UPDATE_CONDUCTANCES(GG,T,R,Q,NOCON,MAXNO,ICONV)

      IMPLICIT NONE

      REAL GG(*),R(*),Q(*)
      DOUBLE PRECISION T(*)
      INTEGER NOCON,MAXNO,ICONV(*)
      INTEGER KCONV,NOCOND

      INTEGER MAXELEM,MAXGROUP,MAXNODE,MAXCOND
      PARAMETER (MAXELEM=25000)
      PARAMETER (MAXGROUP=5000)
      PARAMETER (MAXNODE=10000)
      PARAMETER (MAXCOND=64)

      REAL PROP(10,MAXELEM)
      REAL GEOM(3,4,MAXELEM)
      REAL NODELIST(3,MAXNODE)
      INTEGER NODES(8,MAXELEM)
      INTEGER GNUMELEM
      INTEGER GLIST(MAXGROUP)
      COMMON/CFRPDATA/PROP,GEOM,NODELIST,NODES,GLIST,GNUMELEM

      INTEGER ICOND(4,MAXCOND)
      INTEGER BELLIST(MAXCOND)
      INTEGER NC,NUMBEL

      INTEGER I,J,K,N,CONDNO
      INTEGER E1,E2,I2
      INTEGER CFRPFLAG1,CFRPFLAG2
      INTEGER IERR

      DOUBLE PRECISION A1,A2,ALPHA1,ALPHA2
      DOUBLE PRECISION TC1,TC2
      DOUBLE PRECISION KX1,KY1,KZ1,KX2,KY2,KZ2
      DOUBLE PRECISION KEFF,KEFF0
      DOUBLE PRECISION DX,DY,DZ,DLEN,LX,LY,LZ
      DOUBLE PRECISION SCALE
      DOUBLE PRECISION EPSNEW,EPSBASE

      DOUBLE PRECISION CFRP_KVXY,CFRP_KVZ
      DOUBLE PRECISION CFRP_KEXY,CFRP_KEZ

      LOGICAL FIRSTCONDUCTANCECALL
      DATA FIRSTCONDUCTANCECALL/.TRUE./
      SAVE FIRSTCONDUCTANCECALL

      IF (FIRSTCONDUCTANCECALL) THEN
         FIRSTCONDUCTANCECALL=.FALSE.
      ENDIF

C=======================================================================
C  Conductive connections
C=======================================================================
      DO I=1,GNUMELEM

         N=GLIST(I)

         CALL CONDNOS(N,ICOND,NC,BELLIST,NUMBEL)

         IF (NC.GT.MAXCOND) NC=MAXCOND

         DO J=1,NC

            CONDNO=ICOND(1,J)

C----------- CONDNOS returns external element labels in columns 2/3.
            E1=KCONV(ICOND(2,J))
            E2=KCONV(ICOND(3,J))

            IF (E1.LE.0 .OR. E2.LE.0) GOTO 100

C----------- Process a shared CFRP-CFRP connection once.
            IF (E1.GT.E2) GOTO 100
            IF (N.NE.E1) GOTO 100

            CFRPFLAG1=0
            CFRPFLAG2=0

            DO K=1,GNUMELEM
               IF (GLIST(K).EQ.E1) CFRPFLAG1=1
               IF (GLIST(K).EQ.E2) CFRPFLAG2=1
            END DO

            IF (CFRPFLAG1.EQ.0 .AND. CFRPFLAG2.EQ.0)
     +         GOTO 100

C----------- Endpoint 1 CFRP state.
            CALL USER_QUANTITY('GET','CFRP_A1',E1,A1,IERR)
            CALL USER_QUANTITY('GET','CFRP_A2',E1,A2,IERR)

            IF (IERR.NE.0) THEN
               A1=0.0D0
               A2=0.0D0
            ENDIF

            ALPHA1=0.5540D0*A1+0.9479D0*A2
            ALPHA1=MAX(0.0D0,MIN(1.0D0,ALPHA1))

            TC1=T(E1)

            KX1=(1.0D0-ALPHA1)*CFRP_KVXY(TC1)
     +          +ALPHA1*CFRP_KEXY(TC1)
            KY1=KX1

            KZ1=(1.0D0-ALPHA1)*CFRP_KVZ(TC1)
     +          +ALPHA1*CFRP_KEZ(TC1)

C----------- Endpoint 2 CFRP state, otherwise use endpoint 1.
            IF (CFRPFLAG2.EQ.1) THEN

               CALL USER_QUANTITY('GET','CFRP_A1',E2,A1,IERR)
               CALL USER_QUANTITY('GET','CFRP_A2',E2,A2,IERR)

               IF (IERR.NE.0) THEN
                  A1=0.0D0
                  A2=0.0D0
               ENDIF

               ALPHA2=0.5540D0*A1+0.9479D0*A2
               ALPHA2=MAX(0.0D0,MIN(1.0D0,ALPHA2))

               TC2=T(E2)

               KX2=(1.0D0-ALPHA2)*CFRP_KVXY(TC2)
     +             +ALPHA2*CFRP_KEXY(TC2)
               KY2=KX2

               KZ2=(1.0D0-ALPHA2)*CFRP_KVZ(TC2)
     +             +ALPHA2*CFRP_KEZ(TC2)

            ELSE

               KX2=KX1
               KY2=KY1
               KZ2=KZ1

            ENDIF

C----------- Direction between calculation centroids.
            DX=DBLE(GEOM(1,1,E2)-GEOM(1,1,E1))
            DY=DBLE(GEOM(2,1,E2)-GEOM(2,1,E1))
            DZ=DBLE(GEOM(3,1,E2)-GEOM(3,1,E1))

            DLEN=SQRT(DX*DX+DY*DY+DZ*DZ)

            IF (DLEN.GT.1.0D-20) THEN

               LX=DX/DLEN
               LY=DY/DLEN
               LZ=DZ/DLEN

               IF (CFRPFLAG2.EQ.1) THEN
                  KX1=0.5D0*(KX1+KX2)
                  KY1=0.5D0*(KY1+KY2)
                  KZ1=0.5D0*(KZ1+KZ2)
               ENDIF

               KEFF=KX1*LX*LX+KY1*LY*LY+KZ1*LZ*LZ

               KEFF0=CFRP_KVXY(30.0D0)*LX*LX
     +              +CFRP_KVXY(30.0D0)*LY*LY
     +              +CFRP_KVZ(30.0D0)*LZ*LZ

               IF (KEFF.GT.1.0D-20 .AND.
     +             KEFF0.GT.1.0D-20) THEN

                  SCALE=KEFF0/KEFF
                  GG(CONDNO)=REAL(DBLE(GG(CONDNO))*SCALE)

               ENDIF

            ENDIF

  100       CONTINUE
         END DO

C=======================================================================
C  Radiation connected to boundary elements of this CFRP element.
C=======================================================================
         DO J=1,NUMBEL

            I2=BELLIST(J)

            IF (I2.LE.0) GOTO 200

            CONDNO=NOCOND(ICONV(N),ICONV(I2),1)

            IF (CONDNO.LE.0) THEN
               CONDNO=NOCOND(ICONV(N),ICONV(I2),6)
            ENDIF

            IF (CONDNO.GT.0) THEN

               CALL USER_QUANTITY('GET','CFRP_A1',N,A1,IERR)
               CALL USER_QUANTITY('GET','CFRP_A2',N,A2,IERR)

               IF (IERR.NE.0) THEN
                  A1=0.0D0
                  A2=0.0D0
               ENDIF

               ALPHA1=0.5540D0*A1+0.9479D0*A2
               ALPHA1=MAX(0.0D0,MIN(1.0D0,ALPHA1))

               EPSNEW=(1.0D0-ALPHA1)*0.85D0
     +               +ALPHA1*0.95D0

               EPSBASE=0.85D0

               IF (EPSNEW.GT.1.0D-12) THEN
                  SCALE=EPSBASE/EPSNEW
                  GG(CONDNO)=REAL(DBLE(GG(CONDNO))*SCALE)
               ENDIF

            ENDIF

  200       CONTINUE
         END DO

      END DO

      RETURN
      END

C=======================================================================
C  Unit checker. Exact correlations are SI.
C=======================================================================
      LOGICAL FUNCTION CHECKUNITS()

      IMPLICIT NONE

      REAL U1,U2,U3,U4,U5,U6
      REAL TOL,X

      TOL=0.01

      CALL TUNITS(U1,U2,U3,U4,U5,U6)

C     U2 = model length units per metre
C     U3 = model force units per Newton
C     U4 = Celsius temperature scale
C     U5 = temperature offset from absolute zero
C     U6 = seconds per model time unit

      CHECKUNITS=.FALSE.

      X=ABS(U2-1.0)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      X=ABS(U3-1.0)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      X=ABS(U4-1.0)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      X=ABS((U5+273.15)/273.15)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      X=ABS(U6-1.0)
      IF (X.GT.TOL) CHECKUNITS=.TRUE.

      RETURN
      END

