$ErrorActionPreference = "Stop"

# ============================================================
# USER SETTINGS
# ============================================================

$MainDir = $PSScriptRoot

# NX 11 / TMG installation
$env:SDRC_TMG = "C:\Program Files\Siemens\NX 11.0\NXCAE_EXTRAS\tmg"
$TMG = Join-Path $env:SDRC_TMG "com\tmg"

# Input solution XML exported from NX.
$BaseXML = Join-Path $MainDir "solution_01.xml"

# Coupling folders/files.
$AsciiDir      = Join-Path $MainDir "ascii"
$TempFileDir   = Join-Path $MainDir "TEMP_FILE"
$MainTEMPF     = Join-Path $MainDir "TEMPF"
$TempFileTEMPF = Join-Path $TempFileDir "TEMPF"
$AsciiTEMPF    = Join-Path $AsciiDir "TEMPF"
$StateFile     = Join-Path $AsciiDir "decomposition_state.npz"

# Time settings.
$dt    = 0.5
$t_end = 200.0

# Python executable. Change this only if `python` is not on PATH.
$Python = "python"

# ============================================================
# PREPARE DIRECTORIES
# ============================================================

New-Item -ItemType Directory -Force -Path $AsciiDir | Out-Null
New-Item -ItemType Directory -Force -Path $TempFileDir | Out-Null

if (-not (Test-Path -LiteralPath $BaseXML)) {
    throw "Base XML not found: $BaseXML"
}

if (-not (Test-Path -LiteralPath $TMG)) {
    throw "TMG executable not found: $TMG"
}

# ============================================================
# HELPERS
# ============================================================

function Run-TMG {
    param(
        [Parameter(Mandatory=$true)]
        [string]$XmlFile
    )

    if (-not (Test-Path -LiteralPath $XmlFile)) {
        throw "TMG input XML does not exist: $XmlFile"
    }

    # Remove the previous main TEMPF so a failed/new run cannot accidentally
    # make the coupling use an old result file.
    if (Test-Path -LiteralPath $MainTEMPF) {
        Remove-Item -LiteralPath $MainTEMPF -Force
    }

    Write-Host ""
    Write-Host "============================================================"
    Write-Host "TMG RUN"
    Write-Host "XML : $XmlFile"
    Write-Host "============================================================"

    Push-Location $MainDir
    try {
        & $TMG nx -inPath $XmlFile
        $ExitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    if ($ExitCode -ne 0) {
        throw "TMG failed with exit code $ExitCode."
    }

    if (-not (Test-Path -LiteralPath $MainTEMPF)) {
        throw "TMG completed but did not generate TEMPF: $MainTEMPF"
    }

    $size = (Get-Item -LiteralPath $MainTEMPF).Length
    if ($size -le 0) {
        throw "TMG generated an empty TEMPF: $MainTEMPF"
    }

    Write-Host "TMG TEMPF     : $MainTEMPF"
    Write-Host "TEMPF size    : $size bytes"
}

function Convert-TEMPF {
    # Keep two copies:
    #   TEMP_FILE\TEMPF = binary TMG result used as the next run's initial
    #                     result source in the XML.
    #   ascii\TEMPF     = ASCII copy consumed by Python.

    if (-not (Test-Path -LiteralPath $MainTEMPF)) {
        throw "Cannot copy TEMPF because it does not exist: $MainTEMPF"
    }

    # Delete old files first. This prevents a stale ASCII file from surviving
    # a failed/partial TMG conversion.
    foreach ($path in @($TempFileTEMPF, $AsciiTEMPF)) {
        if (Test-Path -LiteralPath $path) {
            Remove-Item -LiteralPath $path -Force
        }
    }

    Copy-Item -LiteralPath $MainTEMPF -Destination $TempFileTEMPF -Force
    Copy-Item -LiteralPath $MainTEMPF -Destination $AsciiTEMPF -Force

    Write-Host ""
    Write-Host "Converting fresh TEMPF to ASCII..."

    Push-Location $AsciiDir
    try {
        & $TMG as
        $ExitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    if ($ExitCode -ne 0) {
        throw "TMG TEMPF ASCII conversion failed with exit code $ExitCode."
    }

    if (-not (Test-Path -LiteralPath $AsciiTEMPF)) {
        throw "ASCII TEMPF was not produced: $AsciiTEMPF"
    }

    $size = (Get-Item -LiteralPath $AsciiTEMPF).Length
    if ($size -le 0) {
        throw "Converted ASCII TEMPF is empty: $AsciiTEMPF"
    }

    # Basic sanity check: an ASCII TEMPF must contain numeric data lines.
    # We deliberately do not hard-code element ID 1 or 3600 here because the
    # Python side is responsible for the actual XML/TEMPF ID validation.
    $sample = Get-Content -LiteralPath $AsciiTEMPF -TotalCount 200 -ErrorAction Stop
    $numericLine = $sample | Where-Object {
        $_ -match '^\s*\d+\s+[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?\s*$'
    } | Select-Object -First 1

    if (-not $numericLine) {
        throw "TEMPF conversion did not produce recognizable ASCII element-temperature records."
    }

    Write-Host "ASCII TEMPF   : $AsciiTEMPF"
    Write-Host "ASCII size     : $size bytes"
}

function Set-XmlValue {
    param(
        [Parameter(Mandatory=$true)] [string]$XmlFile,
        [Parameter(Mandatory=$true)] [string]$PropertyName,
        [Parameter(Mandatory=$true)] [string]$Value
    )

    $doc = New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.Load($XmlFile)

    $nodes = $doc.SelectNodes("//Property[@name='$PropertyName']/Value")
    if ($nodes.Count -eq 0) {
        throw "XML property '$PropertyName' was not found in $XmlFile"
    }

    # TMG solution XML should contain one instance of these properties.
    foreach ($node in $nodes) {
        $node.InnerText = $Value
    }

    $doc.Save($XmlFile)
}

function Update-TMG-TimeAndInitialCondition {
    param(
        [Parameter(Mandatory=$true)] [string]$XmlFile,
        [Parameter(Mandatory=$true)] [double]$StartTime,
        [Parameter(Mandatory=$true)] [double]$EndTime
    )

    # Scientific notation with a format understood cleanly by NX/TMG.
    $startText = "{0:E7}" -f $StartTime
    $endText   = "{0:E7}" -f $EndTime

    Set-XmlValue -XmlFile $XmlFile -PropertyName "Start Time" -Value $startText
    Set-XmlValue -XmlFile $XmlFile -PropertyName "End Time" -Value $endText

    # TMG/NX mode used by the existing coupling workflow:
    # use the previous result/TEMPF as the initial thermal condition.
    Set-XmlValue -XmlFile $XmlFile -PropertyName "Thermal Initial Temperature" -Value "3"
    Set-XmlValue -XmlFile $XmlFile -PropertyName "TEMPF File" -Value $TempFileTEMPF
}

function Run-PythonCoupling {
    param(
        [Parameter(Mandatory=$true)] [string]$InputXML,
        [Parameter(Mandatory=$true)] [string]$OutputXML,
        [Parameter(Mandatory=$true)] [int]$Step
    )

    Write-Host ""
    Write-Host "============================================================"
    Write-Host "PYTHON COUPLING STEP $Step"
    Write-Host "Input XML  : $InputXML"
    Write-Host "TEMPF      : $AsciiTEMPF"
    Write-Host "Output XML : $OutputXML"
    Write-Host "============================================================"

    & $Python $script:PythonScript `
        --tempf $AsciiTEMPF `
        --xml $InputXML `
        --output $OutputXML `
        --state $StateFile `
        --dt $dt

    $ExitCode = $LASTEXITCODE
    if ($ExitCode -ne 0) {
        throw "Python coupling failed at step $Step with exit code $ExitCode."
    }

    if (-not (Test-Path -LiteralPath $OutputXML)) {
        throw "Python completed but did not create: $OutputXML"
    }
}

# Absolute path to this final Python script. Put it beside this PS1.
$script:PythonScript = Join-Path $MainDir "coupling_update.py"
if (-not (Test-Path -LiteralPath $script:PythonScript)) {
    throw "Python coupling script not found: $script:PythonScript"
}

# ============================================================
# INITIAL TMG RUN
# ============================================================

Write-Host ""
Write-Host "============================================================"
Write-Host "INITIAL TMG RUN : 0 -> $dt s"
Write-Host "============================================================"

Run-TMG -XmlFile $BaseXML
Convert-TEMPF

# Archive the initial ASCII result separately.
$InitialArchive = Join-Path $AsciiDir "TEMPF_initial_000.txt"
Copy-Item -LiteralPath $AsciiTEMPF -Destination $InitialArchive -Force

# ============================================================
# COUPLING LOOP
# ============================================================

$CurrentXML = $BaseXML
$StepNumber = 1

# The initial TMG run already covers 0 -> dt.  Therefore the first
# thermochemical coupling interval is dt -> 2*dt.
while (($StepNumber * $dt) -lt ($t_end - 1.0e-12)) {
    $StartTime = $StepNumber * $dt
    $EndTime   = [Math]::Min(($StepNumber + 1) * $dt, $t_end)

    $OutputXML = Join-Path $MainDir ("Solution_{0:D3}.xml" -f $StepNumber)

    # --------------------------------------------------------
    # Python reads the TEMPF generated by the immediately
    # preceding TMG run and the CURRENT XML state.
    # --------------------------------------------------------
    Run-PythonCoupling `
        -InputXML $CurrentXML `
        -OutputXML $OutputXML `
        -Step $StepNumber

    # --------------------------------------------------------
    # Update the generated XML for the next TMG interval.
    # The next run uses the binary TEMPF from the immediately
    # preceding TMG run as its initial thermal result.
    # --------------------------------------------------------
    Update-TMG-TimeAndInitialCondition `
        -XmlFile $OutputXML `
        -StartTime $StartTime `
        -EndTime $EndTime

    # --------------------------------------------------------
    # TMG runs the newly coupled XML.
    # --------------------------------------------------------
    Run-TMG -XmlFile $OutputXML
    Convert-TEMPF

    # Archive each fresh ASCII TEMPF after conversion.
    $Archive = Join-Path $AsciiDir ("TEMPF_{0:D4}.txt" -f $StepNumber)
    Copy-Item -LiteralPath $AsciiTEMPF -Destination $Archive -Force

    # IMPORTANT: sequential chain.
    # Next Python call uses this generated XML, not solution_01.xml again.
    $CurrentXML = $OutputXML
    $StepNumber++

    Write-Host ""
    Write-Host "Completed coupling interval $StartTime -> $EndTime s"
    Write-Host "Current XML : $CurrentXML"
}

Write-Host ""
Write-Host "============================================================"
Write-Host "COUPLING COMPLETE"
Write-Host "Final XML : $CurrentXML"
Write-Host "End time  : $t_end s"
Write-Host "dt        : $dt s"
Write-Host "============================================================"
