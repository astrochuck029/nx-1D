"""
plot_element_temp.py
--------------------
Scans all files matching a glob pattern (default: result_*) in the current
directory, parses the NX-TMG / Simcenter result format, and plots temperature
vs. time for the requested element IDs.

File format expected:
    -99999  <time_value>      ← start of a time-step block
    <elem_id>  <temperature>
    <elem_id>  <temperature>
    ...
    -99999  <next_time>       ← next block, and so on
"""

import csv
import glob
import os
import re
import sys
from collections import defaultdict

import matplotlib.pyplot as plt

# ── Configuration ─────────────────────────────────────────────────────────────
FILE_PATTERN   = "result_*"          # glob pattern relative to cwd
ELEMENT_IDS    = [41, 42]            # element IDs to plot
SENTINEL_ID    = -99999              # marks a new time-step block
# ──────────────────────────────────────────────────────────────────────────────


def natural_sort_key(path: str):
    """Sort filenames so result_2 < result_10 (numeric, not lexicographic)."""
    parts = re.split(r"(\d+)", os.path.basename(path))
    return [int(p) if p.isdigit() else p.lower() for p in parts]


def parse_files(pattern: str, target_ids: set) -> dict[int, list[tuple[float, float]]]:
    """
    Parse all matching files and return
    {elem_id: [(time, temperature), ...]} sorted by time.
    Duplicate (time, elem_id) entries are kept (last-write wins per block).
    """
    files = sorted(glob.glob(pattern), key=natural_sort_key)
    if not files:
        sys.exit(f"No files matched pattern '{pattern}' in {os.getcwd()!r}")

    print(f"Found {len(files)} file(s): {[os.path.basename(f) for f in files]}")

    data: dict[int, list[tuple[float, float]]] = defaultdict(list)
    seen_times: set[float] = set()          # avoid double-counting overlapping blocks

    for fpath in files:
        current_time = None
        block_data: dict[int, float] = {}   # elem_id → temp within this block

        with open(fpath, "r") as fh:
            for line in fh:
                cols = line.split()
                if len(cols) != 2:
                    continue
                try:
                    elem_id = int(cols[0])
                    value   = float(cols[1])
                except ValueError:
                    continue

                if elem_id == SENTINEL_ID:
                    # flush previous block first
                    if current_time is not None and current_time not in seen_times:
                        seen_times.add(current_time)
                        for eid, temp in block_data.items():
                            data[eid].append((current_time, temp))
                    current_time = value
                    block_data = {}
                elif current_time is not None and elem_id in target_ids:
                    block_data[elem_id] = value

        # flush last block in file
        if current_time is not None and current_time not in seen_times:
            seen_times.add(current_time)
            for eid, temp in block_data.items():
                data[eid].append((current_time, temp))

    # sort each element's series by time
    for eid in data:
        data[eid].sort(key=lambda x: x[0])

    return data


def export_csv(data: dict[int, list[tuple[float, float]]], element_ids: list[int]):
    """
    Export a wide-format CSV:  time | elem_41 | elem_42 | ...
    Rows are sorted by time; missing values are left blank.
    """
    # Collect all unique time points across all elements
    all_times = sorted({t for eid in element_ids if eid in data
                          for t, _ in data[eid]})

    # Build lookup: {eid: {time: temp}}
    lookup: dict[int, dict[float, float]] = {
        eid: dict(data[eid]) for eid in element_ids if eid in data
    }

    out = "element_temp.csv"
    with open(out, "w", newline="") as f:
        headers = ["time"] + [f"element_{eid}_temp" for eid in element_ids]
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for t in all_times:
            row = {"time": t}
            for eid in element_ids:
                row[f"element_{eid}_temp"] = lookup.get(eid, {}).get(t, "")
            writer.writerow(row)

    print(f"CSV  saved → {out}")


def plot(data: dict[int, list[tuple[float, float]]], element_ids: list[int]):
    missing = [eid for eid in element_ids if eid not in data or not data[eid]]
    if missing:
        print(f"Warning: no data found for element ID(s): {missing}")

    fig, ax = plt.subplots(figsize=(9, 5))

    markers = ["o", "s", "^", "D", "v", "P"]
    for i, eid in enumerate(element_ids):
        if eid not in data or not data[eid]:
            continue
        times, temps = zip(*data[eid])
        ax.plot(
            times, temps,
            marker=markers[i % len(markers)],
            linewidth=2,
            markersize=6,
            label=f"Element {eid}",
        )

    ax.set_xlabel("Time (s)", fontsize=12)
    ax.set_ylabel("Temperature (°C / K)", fontsize=12)
    ax.set_title("Element Temperature vs. Time", fontsize=13)
    ax.legend(fontsize=11)
    ax.grid(True, linestyle="--", alpha=0.5)
    fig.tight_layout()

    out = "element_temp_plot.png"
    fig.savefig(out, dpi=150)
    print(f"Plot saved → {out}")
    plt.show()


if __name__ == "__main__":
    # Optional CLI overrides:  python plot_element_temp.py [pattern] [id1 id2 ...]
    # e.g.  python plot_element_temp.py "result_*" 41 42 55
    if len(sys.argv) > 1:
        FILE_PATTERN = sys.argv[1]
    if len(sys.argv) > 2:
        ELEMENT_IDS = [int(a) for a in sys.argv[2:]]

    print(f"Pattern : {FILE_PATTERN}")
    print(f"Elements: {ELEMENT_IDS}")

    data = parse_files(FILE_PATTERN, set(ELEMENT_IDS))
    plot(data, ELEMENT_IDS)

    export_csv(data, ELEMENT_IDS)

    # Print a quick summary table
    print("\n── Data summary ─────────────────────────────")
    for eid in ELEMENT_IDS:
        if eid in data:
            times, temps = zip(*data[eid])
            print(f"  Element {eid}: {len(times)} time points  "
                  f"T_min={min(temps):.2f}  T_max={max(temps):.2f}")
        else:
            print(f"  Element {eid}: NO DATA")
