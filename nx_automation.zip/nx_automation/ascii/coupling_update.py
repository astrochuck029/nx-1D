import os
import re
import copy
import argparse
import numpy as np
import xml.etree.ElementTree as ET


N_REAL_ELEMENTS = 40
TMG_HEATED_ELEMENT = 41
TMG_REAR_ELEMENT = 42
N_STATES = 20
DT = 0.5


R_GAS = 8.314

RHO_V = 1143.7
RHO_E = 884.76
DRHO = RHO_V - RHO_E

KV_CONST = 0.907
KC_CONST = 0.695

CPV_CONST = 1058.5
CPC_CONST = 721.44

F1 = 0.848
F2 = 0.152

A1 = 2.79e10
Ea1 = 162000.0
n1 = 4.0
Q_DEC1 = -822000.0

A2 = 2.08e7
Ea2 = 181000.0
n2 = 1.28
Q_DEC2 = -422000.0


def rates(T, a1, a2):
    T = np.maximum(T, 250.0)

    k1 = (
        A1
        * np.clip(1.0 - a1, 0.0, 1.0) ** n1
        * np.exp(-Ea1 / (R_GAS * T))
    )

    k2 = (
        A2
        * np.clip(a1 - a2, 0.0, 1.0) ** n2
        * np.exp(-Ea2 / (R_GAS * T))
    )

    return k1, k2


def derivatives(T, a1, a2):
    k1, k2 = rates(T, a1, a2)
    return k1, k2


def rk4_step(T, a1, a2, dt):

    def f(temp, x1, x2):
        return derivatives(temp, x1, x2)

    k1a, k1b = f(T, a1, a2)

    k2a, k2b = f(
        T,
        a1 + 0.5 * dt * k1a,
        a2 + 0.5 * dt * k1b
    )

    k3a, k3b = f(
        T,
        a1 + 0.5 * dt * k2a,
        a2 + 0.5 * dt * k2b
    )

    k4a, k4b = f(
        T,
        a1 + dt * k3a,
        a2 + dt * k3b
    )

    na1 = a1 + dt / 6.0 * (
        k1a + 2 * k2a + 2 * k3a + k4a
    )

    na2 = a2 + dt / 6.0 * (
        k1b + 2 * k2b + 2 * k3b + k4b
    )

    na1 = np.clip(na1, 0.0, 1.0)
    na2 = np.clip(na2, 0.0, na1)

    return na1, na2


def alpha_total(a1, a2):
    return (
        F1 * np.clip(a1, 0.0, 1.0)
        + F2 * np.clip(a2, 0.0, 1.0)
    )


def q_decomposition(T, a1, a2):
    k1, k2 = rates(T, a1, a2)

    return (
        F1 * Q_DEC1 * DRHO * k1
        + F2 * Q_DEC2 * DRHO * k2
    )


# ============================================================
# Convert calculated alpha to state using CEILING.
#
# State 01 -> alpha = 0.05
# State 02 -> alpha = 0.10
# ...
# State 20 -> alpha = 1.00
# ============================================================

def alpha_to_state(alpha):

    alpha = np.clip(alpha, 0.0, 1.0)

    state = np.ceil(alpha / 0.05).astype(int)

    state = np.maximum(state, 1)

    return np.clip(state, 1, N_STATES)


def material_properties(alpha):

    rho = RHO_V - DRHO * alpha

    cp = (
        (1.0 - alpha) * CPV_CONST
        + alpha * CPC_CONST
    )

    k = (
        (1.0 - alpha) * KV_CONST
        + alpha * KC_CONST
    )

    return rho, cp, k


def read_tempf_ascii(filename):

    temperatures = {}

    with open(filename, "r", errors="ignore") as f:

        for line in f:

            line = line.strip()

            if not line:
                continue

            tokens = re.findall(
                r"[-+]?(?:\d+\.\d*|\.\d+|\d+)"
                r"(?:[Ee][-+]?\d+)?",
                line
            )

            if len(tokens) < 2:
                continue

            for i in range(len(tokens) - 1):

                try:
                    eid_float = float(tokens[i])
                    temp = float(tokens[i + 1])
                except ValueError:
                    continue

                eid = int(round(eid_float))

                if (
                    abs(eid_float - eid) < 1e-10
                    and 1 <= eid <= N_REAL_ELEMENTS
                ):
                    temperatures[eid] = temp
                    break

    missing = [
        eid
        for eid in range(1, N_REAL_ELEMENTS + 1)
        if eid not in temperatures
    ]

    if missing:
        raise RuntimeError(
            "TEMPF is missing temperatures for elements: "
            + ", ".join(map(str, missing))
        )

    # return np.array(
    #     [
    #         temperatures[eid]
    #         for eid in range(1, N_REAL_ELEMENTS + 1)
    #     ],
    #     dtype=float
    # )

    return np.array(
        [temperatures[eid] for eid in range(1, N_REAL_ELEMENTS + 1)],
        dtype=float
    ) + 273.15


def load_decomposition_state(filename):

    if not os.path.exists(filename):

        a1 = np.zeros(N_REAL_ELEMENTS)
        a2 = np.zeros(N_REAL_ELEMENTS)

        print("No previous decomposition state found.")
        print("Starting with alpha = 0 for all 40 elements.")

        return a1, a2

    data = np.load(filename)

    a1 = np.asarray(data["a1"], dtype=float)
    a2 = np.asarray(data["a2"], dtype=float)

    if len(a1) != N_REAL_ELEMENTS:
        raise RuntimeError(
            "a1 state does not contain 40 elements."
        )

    if len(a2) != N_REAL_ELEMENTS:
        raise RuntimeError(
            "a2 state does not contain 40 elements."
        )

    return a1, a2


def save_decomposition_state(filename, a1, a2):
    np.savez(
        filename,
        a1=a1,
        a2=a2
    )


def find_property(parent, property_name):

    for p in parent.findall(".//Property"):

        if p.get("name") == property_name:
            return p

    return None


def set_property_value(parent, property_name, value):

    p = find_property(parent, property_name)

    if p is None:
        raise RuntimeError(
            f'Could not find XML property "{property_name}"'
        )

    value_node = p.find("Value")

    if value_node is None:
        value_node = ET.SubElement(p, "Value")

    value_node.text = value


def fmt(value):
    return f"{value: .7E}"


def create_material(
    uid,
    state_number,
    alpha_rep,
    rho_value,
    cp_value,
    k_value
):

    material = ET.Element(
        "Material",
        {
            "uid": str(uid),
            "uname": f"Alpha_State_{state_number:02d}",
            "type": "ISO"
        }
    )

    p = ET.SubElement(
        material,
        "Property",
        {
            "name": "Mass Density",
            "type": "Constant"
        }
    )

    ET.SubElement(p, "Value").text = fmt(rho_value)

    p = ET.SubElement(
        material,
        "Property",
        {
            "name": "Specific Heat",
            "type": "Constant"
        }
    )

    ET.SubElement(p, "Value").text = fmt(cp_value)

    p = ET.SubElement(
        material,
        "Property",
        {
            "name": "Thermal Conductivity",
            "type": "Constant"
        }
    )

    ET.SubElement(p, "Value").text = fmt(k_value)

    extra_properties = [
        (
            "Phase Change",
            "Constant",
            "0.0000000E+000"
        ),
        (
            "Phase Temperature Range",
            "Constant",
            "0.0000000E+000"
        ),
        (
            "Phase Specific Heat",
            "Constant",
            "0.0000000E+000"
        ),
        (
            "IR Scattering",
            "Constant",
            "0.0000000E+000"
        )
    ]

    for name, typ, value in extra_properties:

        p = ET.SubElement(
            material,
            "Property",
            {
                "name": name,
                "type": typ
            }
        )

        ET.SubElement(p, "Value").text = value

    return material


def get_element_list(root):

    element_list = root.find("ElementList")

    if element_list is None:
        raise RuntimeError(
            "Could not find <ElementList> in XML."
        )

    return element_list


def get_real_mesh_set(element_list):

    for s in element_list.findall("Set"):

        if s.get("uname") == "3d_mesh(1)":
            return s

    raise RuntimeError(
        'Could not find <Set uname="3d_mesh(1)">'
    )


def build_state_element_sets(
    root,
    element_states,
    material_base_uid=101
):

    element_list = get_element_list(root)

    original_mesh = get_real_mesh_set(element_list)

    element_data = {}

    for e in original_mesh.findall("E"):

        values = e.text.split()
        eid = int(values[0])

        if 1 <= eid <= N_REAL_ELEMENTS:
            element_data[eid] = values

    if len(element_data) != N_REAL_ELEMENTS:

        raise RuntimeError(
            "Could not read all 40 solid elements "
            "from 3d_mesh(1)."
        )

    element_list.remove(original_mesh)

    for state in range(1, N_STATES + 1):

        material_uid = material_base_uid + state - 1

        s = ET.Element(
            "Set",
            {
                "uname": f"3d_mesh_state_{state:02d}",
                "elementType": "HEXA8",
                "material": str(material_uid),
                "opticalProperty": "0"
            }
        )

        for eid in range(1, N_REAL_ELEMENTS + 1):

            if element_states[eid - 1] != state:
                continue

            values = element_data[eid]

            e = ET.SubElement(s, "E")
            e.text = " ".join(values)

        if len(s.findall("E")) > 0:

            element_list.insert(0, s)


def build_material_states(root):

    material_list = root.find("MaterialList")

    if material_list is None:
        raise RuntimeError(
            "Could not find <MaterialList>."
        )

    material_base_uid = 101

    old_generated = []

    for material in material_list.findall("Material"):

        uname = material.get("uname", "")

        if uname.startswith("Alpha_State_"):
            old_generated.append(material)

    for material in old_generated:
        material_list.remove(material)

    # State alpha values:
    # 0.05, 0.10, 0.15, ..., 1.00

    alpha_rep = np.arange(
        1,
        N_STATES + 1
    ) * 0.05

    for i in range(N_STATES):

        state_number = i + 1

        alpha_value = alpha_rep[i]

        rho_value, cp_value, k_value = material_properties(
            alpha_value
        )

        material = create_material(
            uid=material_base_uid + i,
            state_number=state_number,
            alpha_rep=alpha_value,
            rho_value=rho_value,
            cp_value=cp_value,
            k_value=k_value
        )

        material_list.append(material)


def create_qdec_load(
    uid,
    element_id,
    q_value
):

    load = ET.Element(
        "ThermalLoad",
        {
            "uid": str(uid),
            "uname": f"Q_dec_E{element_id:03d}",
            "type": "Heat Generation"
        }
    )

    ET.SubElement(load, "Description")

    p = ET.SubElement(
        load,
        "Property",
        {
            "name": "Heat Generation"
        }
    )

    ET.SubElement(p, "Value").text = fmt(q_value)

    properties = [
        ("Control Heater", "0"),
        ("Thermostat", "-1"),
        ("Specify Layer to Apply to", "0"),
        ("Apply to", "0"),
        ("Layer Number", "1")
    ]

    for name, value in properties:

        p = ET.SubElement(
            load,
            "Property",
            {
                "name": name
            }
        )

        ET.SubElement(p, "Value").text = value

    selection = ET.SubElement(
        load,
        "Selection",
        {
            "step": "1",
            "groupName": "Block"
        }
    )

    ET.SubElement(selection, "el").text = str(element_id)

    return load


def update_qdec_loads(root, qdec):

    thermal_load_list = root.find(
        "./Loads/ThermalLoadList"
    )

    if thermal_load_list is None:
        raise RuntimeError(
            "Could not find ThermalLoadList."
        )

    remove_list = []

    for load in thermal_load_list.findall("ThermalLoad"):

        if (
            load.get("uname") == "Q_dec"
            or load.get("uname", "").startswith("Q_dec_E")
        ):
            remove_list.append(load)

    for load in remove_list:
        thermal_load_list.remove(load)

    UID_START = 100

    for i in range(N_REAL_ELEMENTS):

        element_id = i + 1

        load = create_qdec_load(
            uid=UID_START + i,
            element_id=element_id,
            q_value=qdec[i]
        )

        thermal_load_list.append(load)


def indent_xml(elem, level=0):

    i = "\n" + level * "  "
    j = "\n" + (level - 1) * "  "

    if len(elem):

        if not elem.text or not elem.text.strip():
            elem.text = i + "  "

        for child in elem:
            indent_xml(child, level + 1)

        if (
            not elem[-1].tail
            or not elem[-1].tail.strip()
        ):
            elem[-1].tail = i

    if level and (
        not elem.tail
        or not elem.tail.strip()
    ):
        elem.tail = j


def main():

    parser = argparse.ArgumentParser(
        description=(
            "Read TMG ASCII TEMPF, update decomposition, "
            "and generate a new TMG XML."
        )
    )

    parser.add_argument(
        "--tempf",
        required=True,
        help="ASCII TEMPF file from TMG"
    )

    parser.add_argument(
        "--xml",
        required=True,
        help="XML template to modify"
    )

    parser.add_argument(
        "--output",
        required=True,
        help="Output XML"
    )

    parser.add_argument(
        "--state",
        default="decomposition_state.npz",
        help="Python decomposition state file"
    )

    parser.add_argument(
        "--dt",
        type=float,
        default=DT,
        help="Time interval between TMG runs [s]"
    )

    args = parser.parse_args()

    T = read_tempf_ascii(args.tempf)

    a1, a2 = load_decomposition_state(
        args.state
    )

    a1_new, a2_new = rk4_step(
        T,
        a1,
        a2,
        args.dt
    )

    alpha = alpha_total(
        a1_new,
        a2_new
    )

    qdec = q_decomposition(
        T,
        a1_new,
        a2_new
    )

    # Round calculated alpha UP to the nearest
    # 0.05 state.

    states = alpha_to_state(alpha)

    tree = ET.parse(args.xml)
    root = tree.getroot()

    build_material_states(root)

    build_state_element_sets(
        root,
        states,
        material_base_uid=101
    )

    update_qdec_loads(
        root,
        qdec
    )

    save_decomposition_state(
        args.state,
        a1_new,
        a2_new
    )

    indent_xml(root)

    tree.write(
        args.output,
        encoding="utf-8",
        xml_declaration=False
    )


if __name__ == "__main__":
    main()