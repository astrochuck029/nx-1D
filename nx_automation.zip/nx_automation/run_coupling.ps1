$ErrorActionPreference = "Stop"

# ============================================================
# PATHS
# ============================================================

$env:SDRC_TMG = "C:\Program Files\Siemens\NX 11.0\NXCAE_EXTRAS\tmg"

$TMG = "C:\Program Files\Siemens\NX 11.0\NXCAE_EXTRAS\tmg\com\tmg"

$MainDir = $PSScriptRoot

$AsciiDir    = Join-Path $MainDir "ascii"
$TempFileDir = Join-Path $MainDir "TEMP_FILE"

$BaseXML = Join-Path $MainDir "solution_01.xml"

$MainTEMPF     = Join-Path $MainDir "TEMPF"
$TempFileTEMPF = Join-Path $TempFileDir "TEMPF"
$AsciiTEMPF    = Join-Path $AsciiDir "TEMPF"

$StateFile = Join-Path $AsciiDir "decomposition_state.npz"


# ============================================================
# SETTINGS
# ============================================================

$dt = 0.5
$t_end = 200.0


# ============================================================
# FUNCTION: RUN TMG
# ============================================================

function Run-TMG {
    param (
        [string]$XmlFile
    )

    if (Test-Path $MainTEMPF) {
        Remove-Item $MainTEMPF -Force
    }

    Push-Location $MainDir

    try {
        & $TMG nx -inPath $XmlFile
        $ExitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    if ($ExitCode -ne 0) {
        throw "TMG failed."
    }

    if (-not (Test-Path $MainTEMPF)) {
        throw "TMG did not generate TEMPF."
    }
}


# ============================================================
# FUNCTION: COPY TEMPF
# ============================================================

function Copy-TEMPF {

    Copy-Item `
        $MainTEMPF `
        $TempFileTEMPF `
        -Force

    Copy-Item `
        $MainTEMPF `
        $AsciiTEMPF `
        -Force
}


# ============================================================
# FUNCTION: CONVERT TEMPF TO ASCII
# ============================================================

function Convert-TEMPF {

    Push-Location $AsciiDir

    try {
        & $TMG as
        $ExitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    if ($ExitCode -ne 0) {
        throw "TEMPF ASCII conversion failed."
    }
}


# ============================================================
# FUNCTION: RUN PYTHON COUPLING
# ============================================================

function Run-Python {

    param (
        [int]$Step
    )

    $OutputXML = "Solution_{0:D3}.xml" -f $Step

    Push-Location $AsciiDir

    try {

        & python coupling_update.py `
            --tempf TEMPF `
            --xml "solution_01.xml" `
            --output $OutputXML `
            --state decomposition_state.npz `
            --dt $dt | Out-Host

        $ExitCode = $LASTEXITCODE

    }
    finally {
        Pop-Location
    }

    if ($ExitCode -ne 0) {
        throw "Python coupling failed."
    }

    return [string]$OutputXML
}


# ============================================================
# FUNCTION: UPDATE XML
# ============================================================

function Update-XML {

    param (
        [string]$XmlFile,
        [double]$StartTime,
        [double]$EndTime
    )

    $Content = Get-Content $XmlFile -Raw

    # Start Time
    $Content = [regex]::Replace(
        $Content,
        '(?s)(<Property\s+name="Start Time">\s*<Value>\s*)[^<]+(\s*</Value>)',
        '${1}' + ("{0:E7}" -f $StartTime) + '${2}',
        1
    )

    # End Time
    $Content = [regex]::Replace(
        $Content,
        '(?s)(<Property\s+name="End Time">\s*<Value>\s*)[^<]+(\s*</Value>)',
        '${1}' + ("{0:E7}" -f $EndTime) + '${2}',
        1
    )

    # Thermal Initial Temperature = 3
    $Content = [regex]::Replace(
        $Content,
        '(?s)(<Property\s+name="Thermal Initial Temperature">\s*<Value>\s*)[^<]+(\s*</Value>)',
        '${1}3${2}',
        1
    )

    # TEMPF File
    $Content = [regex]::Replace(
        $Content,
        '(?s)(<Property\s+name="TEMPF File">\s*<Value>\s*)[^<]+(\s*</Value>)',
        '${1}' + $TempFileTEMPF + '${2}',
        1
    )

    [System.IO.File]::WriteAllText(
        $XmlFile,
        $Content,
        (New-Object System.Text.UTF8Encoding($false))
    )
}


# ============================================================
# INITIAL RUN
# 0.0 -> 0.5 s
# ============================================================

Write-Host ""
Write-Host "Initial TMG run: 0 -> 0.5 s"

Run-TMG $BaseXML

Copy-TEMPF

Convert-TEMPF


# ============================================================
# COUPLING LOOP
# ============================================================

for ($Step = 1; $Step -lt ($t_end / $dt); $Step++) {

    $StartTime = $Step * $dt
    $EndTime   = ($Step + 1) * $dt

    Write-Host ""
    Write-Host "Coupling step $Step : $StartTime -> $EndTime s"

    # --------------------------------------------------------
    # Python generates Solution_XXX.xml in ASCII directory
    # --------------------------------------------------------

    $NewXML = Run-Python $Step

    $AsciiXML = Join-Path $AsciiDir $NewXML
    $MainXML  = Join-Path $MainDir $NewXML


    # --------------------------------------------------------
    # COPY PYTHON XML TO NX WORKING DIRECTORY
    # --------------------------------------------------------

    Copy-Item `
        $AsciiXML `
        $MainXML `
        -Force


    # --------------------------------------------------------
    # ARCHIVE ASCII TEMPF
    # ascii\TEMPF -> ascii\1, ascii\2, ...
    # --------------------------------------------------------

    $ArchiveTEMPF = Join-Path $AsciiDir ([string]$Step)

    if (Test-Path $ArchiveTEMPF) {
        Remove-Item $ArchiveTEMPF -Force
    }

    Move-Item `
        $AsciiTEMPF `
        $ArchiveTEMPF `
        -Force


    # --------------------------------------------------------
    # UPDATE XML IN NX WORKING DIRECTORY
    # --------------------------------------------------------

    Update-XML `
        $MainXML `
        $StartTime `
        $EndTime


    # --------------------------------------------------------
    # RUN TMG
    # --------------------------------------------------------

    Run-TMG $MainXML


    # --------------------------------------------------------
    # COPY NEW TMG TEMPF
    # --------------------------------------------------------

    Copy-TEMPF


    # --------------------------------------------------------
    # CONVERT NEW TEMPF TO ASCII
    # --------------------------------------------------------

    Convert-TEMPF
}


Write-Host ""
Write-Host "============================================"
Write-Host "SIMULATION COMPLETED"
Write-Host "============================================"